package ch14_writing_clean_code.example._03_magic_number_secret_$;


import java.util.Scanner;

public class Secret
{
  public static void main(String[] args)
  {
    int rsn = 0; // rsn = random secret number
    int gsn = 0; // gsn = guess number
    int[] arraySecret = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    
    rsn = RandomElement.getRandom(arraySecret);
    // uncomment the following line to display the secret number
    // System.out.println("\nRandom secret number: " + rsn);
    Scanner input = new Scanner(System.in);
    System.out.print("\nEnter a guess number from 1 to 10: ");
    int i = 0;
    
    // Check if next input is int
    while (input.hasNextInt())
    {
      i++;
      gsn = input.nextInt();
      
      if(gsn == rsn)
      {
        System.out.println("Guess  " + gsn + " is correct.");
        break;
      }
      
      if(i >= 3)
      {
        System.out.println("Max attempts secret nr: " + rsn);
        break;
      }
      System.out.print("Incorrect, please try again: ");
    }
    System.out.print("Application is closed");
    input.close();
  }
}
