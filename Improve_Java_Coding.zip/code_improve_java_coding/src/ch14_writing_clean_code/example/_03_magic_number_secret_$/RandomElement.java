package ch14_writing_clean_code.example._03_magic_number_secret_$;

import java.util.Random;

public class RandomElement
{
  int[] arraySecret = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
  
  static int[] intArray = { 1, 2 };
  
  public static int getRandom(int[] array)
  {
    int rnd = new Random().nextInt(array.length);
    return array[rnd];
  }
}
