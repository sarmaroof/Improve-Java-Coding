package ch14_writing_clean_code.example._02a_reusable_method_$;


public class Vehicle
{
  private String brand;
  private String color;
  private String fuel;
  
  public Vehicle(String brand, String color, String fuel)
  {
    this.brand = brand;
    this.color = color;
    this.fuel = fuel;
  }
  public void display()
  {
    System.out.println("\n****************************");
    System.out.println("           Vehicle            ");
    System.out.println("****************************");
    System.out.println("Brand: ............... " + brand);
    System.out.println("Color: ............... " + color);
    System.out.println("Fuel: ................ " + fuel);
  }
  public static void main(String[] args)
  {
    Vehicle vh = new Vehicle("BMW", "Brown", "Gasoline");
    vh.display();
  }
}
