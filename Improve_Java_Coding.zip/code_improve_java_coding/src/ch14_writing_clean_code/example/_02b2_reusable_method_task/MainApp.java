package ch14_writing_clean_code.example._02b2_reusable_method_task;

public class MainApp
{
  public static void main(String[] args)
  {
    Car car = new Car("BMW", "Brown", "Gasoline", 5);
    Truck truck = new Truck("Volvo", "Green", "Gasoline", 12000);

    car.display();
    truck.display();
  }
}


/*
to run the application for the changes in DataPrinter.
Just point to DataPrinter2 from the Vehicle class, because that is the only class
that directly use it.


*/