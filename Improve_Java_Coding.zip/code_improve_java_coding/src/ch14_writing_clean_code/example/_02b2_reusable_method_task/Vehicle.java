package ch14_writing_clean_code.example._02b2_reusable_method_task;


public class Vehicle
{
  protected String brand;
  protected String color;
  protected String fuel;
  protected DataPrinter dP;
  
  public Vehicle(String brand, String color, String fuel)
  {
    this.brand = brand;
    this.color = color;
    this.fuel = fuel;
    this.dP = new DataPrinter();
    this.dP.addData("Brand", brand);
    this.dP.addData("Color", color);
    this.dP.addData("Fuel", fuel);
    //System.out.println("VH brand: " +this.brand);
  }
  public void display()
  {
    dP.display();
  }
}
