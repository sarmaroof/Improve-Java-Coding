package ch14_writing_clean_code.example._02b_reusable_method;


import java.util.LinkedHashMap;
import java.util.Map;

public class DataPrinter
{
  /*
   *  CH = Char, SD = Side, TL = Title
   *  NR = Number, CL = Column, LN = Length 
   */
  final static int NR_TL_CH = 28;
  final static String TL_CH = "*";
  final static String TL_SD_CH = " ";
  final static int CL_LN = 20;
  final static String CH = ".";
  
  Map<String, String> displayMap;
  
  public DataPrinter()
  {
    this.displayMap = new LinkedHashMap<String, String>();
  }
  public void addData(String key, String value)
  {
    displayMap.put(key, value);
  }
  public void display(String title)
  {
    int halfTitleLength = (title.length() / 2);
    int halfCoulmnLength = NR_TL_CH / 2;
    int nrSideTitleChars = halfCoulmnLength - halfTitleLength;
    String charsNeeded = TL_CH.repeat(NR_TL_CH);
    String chTLSd = TL_SD_CH.repeat(nrSideTitleChars);
    System.out.println("\n" + charsNeeded);
    System.out.println(chTLSd+" "+title + " "+chTLSd);
    System.out.println(charsNeeded);
  }
  public void display()
  {
    for (Map.Entry<String, String> e : displayMap.entrySet())
    {
      int keyLength = e.getKey().length();
      int nrChBeKey = CL_LN - keyLength; // nr chars next to key
      String chBeKey = CH.repeat(nrChBeKey); // chars next to key
      System.out.println(e.getKey()+": "+chBeKey+" "+e.getValue());
    }
  }
}
