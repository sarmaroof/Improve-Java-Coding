package ch14_writing_clean_code.example._02b_reusable_method;


public class Truck extends Vehicle
{
  private int maxLoad; // in kg
  
  public Truck(String brand, String color, String fuel, int maxLoad)
  {
    super(brand, color, fuel);
    this.maxLoad = maxLoad;
    super.dP.addData("Max load in kg", String.valueOf(maxLoad));
  }
  public void display()
  {
    dP.display("TRUCK");
    dP.display();
  }
}