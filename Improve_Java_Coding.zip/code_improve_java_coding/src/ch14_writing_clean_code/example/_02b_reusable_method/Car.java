package ch14_writing_clean_code.example._02b_reusable_method;

public class Car extends Vehicle
{
  private int maxP; // max number passengers
  public Car(String brand, String color, String fuel, int maxP)
  {
    super(brand, color, fuel);
    this.maxP = maxP;
    super.dP.addData("Nr Passengers", String.valueOf(maxP));
  }
  public void display()
  {
    dP.display("CAR");
    dP.display();
  }
}
