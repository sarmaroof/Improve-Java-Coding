package ch14_writing_clean_code.example._01a_method_srp;

import java.util.ArrayList;

public class Company
{
  private String name;
  private String logo;
  private Contact contact;
  private ArrayList<String> products;
  
  public Company()
  {
    this.name = "Microsystem";
    this.contact = new Contact();
    this.products = new ArrayList<String>();
    products.add("Software");
    products.add("Database");
  }
  public void getCompanyInfo()
  {
    System.out.println("");
    System.out.println("...........LOGO..........");
    System.out.println("");
    System.out.println(".. Company: " + name + " ..");
    System.out.println("");
    System.out.println(".. Contact Information ..");
    System.out.println("Streer: ........... " + contact.street);
    System.out.println("Appartment: ....... " + contact.houseNr);
    System.out.println("City: ............. " + contact.city);
    System.out.println("Zip code: ......... " + contact.zipCode);
    System.out.println("Country: .......... " + contact.country);
    System.out.println("Phone: ............ " + contact.phone);
    System.out.println("");
    int i = 0;
    System.out.println("");
    System.out.println(".. " + name + " Products ..");
    System.out.println("");
    
    for (String product : products)
    {
      i++;
      System.out.println("Product" + i + ": ......... " + product);
    }
  }
  public static void main(String[] args)
  {
    Company comp = new Company();
    comp.getCompanyInfo();
  }
}
