package ch14_writing_clean_code.example._05_author_book;

public class MainApp
{
  public static void main(String[] args)
  {
    Book book = new Book("Subconcious mind", "George Smith");
    System.out.println();
  }
}
