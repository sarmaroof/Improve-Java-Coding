package ch14_writing_clean_code.example._05_author_book;

public class Book
{
  String title;
  String author;
  
  Book(String title, String author)
  {
    this.title = title;
    this.author = author;
  }
}
/*
Thinking about future expands. The class book uses a string type for the author
This is not a good idea for future expands.


*/