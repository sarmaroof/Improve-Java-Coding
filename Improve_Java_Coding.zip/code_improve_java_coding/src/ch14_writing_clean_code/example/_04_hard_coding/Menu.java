package ch14_writing_clean_code.example._04_hard_coding;

public class Menu
{
  public void printMenu(String accessType)
  {
    System.out.print("\n\n Menu "+"\n .. Insert a letter .. \n");
    System.out.print(" D " + "Display |");
    System.out.print(" S " + "Save |");
    System.out.print(" X" + " Exit |");
    
    if(accessType == "admin")
    {
      System.out.print(" A " + "Add |");
      System.out.print(" R " + "Remove |");
    }
    else if(accessType == "editor")
    {
      System.out.print(" U " + "Update |");
    }
  }
  public static void main(String[] args)
  {
    Menu menu = new Menu();
    menu.printMenu("admin");
    menu.printMenu("editor");
    menu.printMenu("basic");
  }
}
