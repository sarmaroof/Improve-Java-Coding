package ch14_writing_clean_code.example._01b_method_srp;

import java.util.ArrayList;

public class Company
{
  private String name;
  private String logo;
  private Contact contact;
  private ArrayList<String> products;
  
  public Company()
  {
    this.name = "Microsystem";
    this.contact = new Contact();
    this.products = new ArrayList<String>();
    products.add("Software");
    products.add("Database");
  }
  public void getCompanyLogo()
  {
    System.out.println("");
    System.out.println("...........LOGO..........");
  }
  public void getCompanyName()
  {
    System.out.println("");
    System.out.println(".. Company: " + name + " ..");
  }
  public void getCompanyContact()
  {
    System.out.println("");
    System.out.println("Streer: ........... " + contact.street);
    System.out.println("Appartment: ....... " + contact.houseNr);
    System.out.println("City: ............. " + contact.city);
    System.out.println("Zip code: ......... " + contact.zipCode);
    System.out.println("Country: .......... " + contact.country);
    System.out.println("Phone: ............ " + contact.phone);
  }
  public void getCompanyProducts()
  {
    System.out.println("");
    int i = 0;
    System.out.println("");
    System.out.println(".. " + name + " Products ..");
    System.out.println("");
    
    for (String product : products)
    {
      i++;
      System.out.println("Product" + i + ": ......... " + product);
    }
  }
  public void getCompanyInfo()
  {
    getCompanyLogo();
    getCompanyName();
    getCompanyContact();
    getCompanyProducts();
  }
}
