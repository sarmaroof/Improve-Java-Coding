package ch14_writing_clean_code.example._01b_method_srp;

public class Contact
{
  String street;
  String houseNr;
  String zipCode;
  String city;
  String country;
  String phone;
  
  public Contact()
  {
    this.street = "495 party street";
    this.houseNr = "34A";
    this.zipCode = "NY 10014";
    this.city = "New York";
    this.country = "USA";
    this.phone = "0322-38877290";
  }
}
