package ch14_writing_clean_code.example._01b_method_srp;

public class CompanyApp
{
  public static void main(String[] args)
  {
    Company comp = new Company();
    comp.getCompanyInfo();
  }
}
