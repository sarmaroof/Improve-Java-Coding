package ch14_writing_clean_code.exercise._01_reusable_method_enginecode;

public class Vehicle
{
  protected String brand;
  protected String color;
  protected String fuel;
  protected String eCode; // engine code
  protected DataPrinter dP;
  
  public Vehicle(String brand, String color, String fuel, String eCode)
  {
    this.brand = brand;
    this.color = color;
    this.fuel = fuel;
    this.dP = new DataPrinter();
    this.dP.addData("Brand", brand);
    this.dP.addData("Color", color);
    this.dP.addData("Fuel", fuel);
    this.dP.addData("Engine code", eCode);
    //System.out.println("VH brand: " +this.brand);
  }
  public void display()
  {
    dP.display();
  }
}
