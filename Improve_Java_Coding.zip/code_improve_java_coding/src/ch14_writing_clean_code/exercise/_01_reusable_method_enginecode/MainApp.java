package ch14_writing_clean_code.exercise._01_reusable_method_enginecode;

public class MainApp
{
  public static void main(String[] args)
  {
    Vehicle vh = new Vehicle("Cadilac", "Red", "Gasoline", "EC59494");
    Car car = new Car("BMW", "Brown", "Gasoline", "ECAR3445", 5);
    Truck truck = new Truck("Volvo", "Green", "Gasoline", "ETRU988", 12000);
    car.display();
    truck.display();
  }
}


/*
to run the application for the changes in DataPrinter.
Just point to DataPrinter2 from the Vehicle class, because that is the only class
that directly use it.


*/