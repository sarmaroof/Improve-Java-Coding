package ch14_writing_clean_code.exercise._04_bookshop;

public class Book
{
  String title;
  Author author;
  
  Book(String title, Author author)
  {
    this.title = title;
    this.author = author;
  }
}
