package ch14_writing_clean_code.exercise._04_bookshop;

public class MainApp
{
  public static void main(String[] args)
  {
    Author author = new Author("George", 43);
    Book book = new Book("Subconcious mind", author);
    System.out.println("\nTitle: " + book.title);
    System.out.println("Author name: " + author.name);
    System.out.println("Author age: " + author.age);
  }
}
