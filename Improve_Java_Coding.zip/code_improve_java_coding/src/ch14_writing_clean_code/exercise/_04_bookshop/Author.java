package ch14_writing_clean_code.exercise._04_bookshop;

public class Author
{
  String name;
  String biography;
  int age;
  
  public Author(String name, int age)
  {
    this.name = name;
    this.age = age;
  }
}
