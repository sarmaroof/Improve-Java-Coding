package ch14_writing_clean_code.exercise._03_hard_coding;


// MenuItemEnum = MenuIE
public enum MenuIE
{
  ACCESS_TYPE("ADMIN", "Adiministrator"), 
  SELECT("\n\n Menu ", "\n ... Insert a letter ... \n"),
  ACCESS("\n\n Menu ", "\n ... You cannot access the application ... \n"), 
  ADD(" A ", "Add |"), // access admin
  DISPLAY(" D ", "Display |"), // access admin, editor and basic
  SAVE(" S ", "Save |"), // access admin, editor
  REMOVE(" R ", "Remove |"), // access admin, editor
  UPDATE(" U ", "Update |"), // access admin, editor
  EXIT(" X", " Exit |"); // // access admin, editor and basic
  private String code;
  private String name;
  
  MenuIE(String code, String name)
  {
    this.code = code;
    this.name = name;
  }
  public String getCode()
  {
    return code;
  }
  public String getName()
  {
    return name;
  }
}
