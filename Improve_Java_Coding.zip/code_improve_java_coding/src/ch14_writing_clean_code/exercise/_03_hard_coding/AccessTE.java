package ch14_writing_clean_code.exercise._03_hard_coding;


// AccessType Enum = AccessTE
public enum AccessTE
{
  ADMIN, EDITOR, BASIC;
}
