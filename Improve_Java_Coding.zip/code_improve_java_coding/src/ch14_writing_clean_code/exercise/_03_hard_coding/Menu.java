package ch14_writing_clean_code.exercise._03_hard_coding;


public class Menu
{
  public void printMenu(AccessTE accessTE)
  {
    System.out.print(MenuIE.SELECT.getCode() + MenuIE.SELECT.getName());
    System.out.print(MenuIE.DISPLAY.getCode() + MenuIE.DISPLAY.getName());
    System.out.print(MenuIE.SAVE.getCode() + MenuIE.SAVE.getName());
    System.out.print(MenuIE.EXIT.getCode() + MenuIE.EXIT.getName());
    
    if(accessTE == AccessTE.ADMIN)
    {
      System.out.print(MenuIE.ADD.getCode() + MenuIE.ADD.getName());
      System.out.print(MenuIE.REMOVE.getCode() + MenuIE.REMOVE.getName());
    }
    else if(accessTE == AccessTE.EDITOR)
    {
      System.out.print(MenuIE.UPDATE.getCode() + MenuIE.UPDATE.getName());
    }
  }
  public static void main(String[] args)
  {
    Menu menu = new Menu();
    menu.printMenu(AccessTE.ADMIN);
    menu.printMenu(AccessTE.EDITOR);
    menu.printMenu(AccessTE.BASIC);
  }
}
/*
Menu 
 ... Insert the letter to access the feature ... 
 D Display | S Save | X Exit | A Add | R Remove |

 Menu 
 ... Insert the letter to access the feature ... 
 D Display | S Save | X Exit | U Update |

 Menu 
 ... Insert the letter to access the feature ... 
 D Display | S Save | X Exit |

 */