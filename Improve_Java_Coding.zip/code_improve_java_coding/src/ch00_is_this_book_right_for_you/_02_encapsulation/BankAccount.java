package ch00_is_this_book_right_for_you._02_encapsulation;

public class BankAccount
{
  double balance = 3500.00;
}
