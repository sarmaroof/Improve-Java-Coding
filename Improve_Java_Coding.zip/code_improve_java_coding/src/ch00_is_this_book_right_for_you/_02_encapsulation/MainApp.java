package ch00_is_this_book_right_for_you._02_encapsulation;
// ch 7 encapsulation exercise 1
import java.util.Scanner;

public class MainApp
{
  public static void main(String[] args)
  {
    BankAccount bAccount = new BankAccount();
    System.out.printf("\nBalance is: %.2f", bAccount.balance);
    Scanner scanner = new Scanner(System.in);
    
    System.out.print("\nEnter a positive amount: ");
    double amount = scanner.nextDouble();
    
    bAccount.balance -= amount;
    System.out.printf("Balance is: %.2f ", bAccount.balance);
    scanner.close();
  }
}
