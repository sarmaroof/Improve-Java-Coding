package ch00_is_this_book_right_for_you._05_garbage_collection;

public class Computer
{
  String brand = "DELL";
}
