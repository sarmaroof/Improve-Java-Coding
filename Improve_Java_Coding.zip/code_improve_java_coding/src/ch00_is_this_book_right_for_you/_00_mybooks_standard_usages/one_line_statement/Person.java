package ch00_is_this_book_right_for_you._00_mybooks_standard_usages.one_line_statement;

public class Person
{
  public void setData() {
    
  }
}
