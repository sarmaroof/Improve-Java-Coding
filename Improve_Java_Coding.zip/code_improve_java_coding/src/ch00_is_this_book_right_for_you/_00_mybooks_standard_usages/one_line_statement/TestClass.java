package ch00_is_this_book_right_for_you._00_mybooks_standard_usages.one_line_statement;

public class TestClass
{
  
  public static void main(String[] args)
  {
    
//this(title, runnigTime);
//this(title, runnigTime);
    
Person p = new Person();
p.setData();
    
    String name = "";
    String mobile = "";
    
    System.out.println("Name: " + name);
    System.out.println("Mobile: " + mobile);
  }
}
