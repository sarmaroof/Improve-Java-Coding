package ch00_is_this_book_right_for_you._00_mybooks_standard_usages.one_line_statement;

public class Movie
{
  //the attributes(variables) 
  String title;
  int runnigTime; // in minutes
  double price;
  //the main method to execute the code
  public static void main(String[] args)
  {
    // more code
  }
}
/*
this code example I use as a standard by general explanation and code style in the book


*/