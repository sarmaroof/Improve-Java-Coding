package ch00_is_this_book_right_for_you._03_initializer;
// ch 13 memory quiz 1

public class Bird
{
  int age1 = getAge(2);
  
  Bird()
  {
    int age2 = getAge(4);
  }
  static
  {
    System.out.print(getAge(6));
  }
  
  static int age4 = getAge(8);
  int age5 = getAge(20);
  
  public static int getAge(int age)
  {
    System.out.print(age);
    return age;
  }
  public static void main(String[] args)
  {
  }
}
/*
Select the correct answer.
a. This code writes "668" to the standard output. 
 b. This code writes "68" to the standard output. 
 c. This code writes "6" to the standard output. 
 d. This code writes "8" to the standard output. 
 e. This code writes "null" to the standard output. 
 f. This code writes nothing to the standard output.
*/