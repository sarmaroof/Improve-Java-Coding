package ch00_is_this_book_right_for_you._04_varargs;

// ch 5 example 4 varargs


public class Table
{
  final String SIGN = "*";
  final String SPACE = "   ";
  
  public void display(String title1, String title2, String title3)
  {
    String titleText = "";
    String underTitle = "";
    String newLine = "\n";
   
    titleText += title1 + SPACE;;
    underTitle += SIGN.repeat(title1.length()) + SPACE;

    titleText += title2 + SPACE;;
    underTitle += SIGN.repeat(title2.length()) + SPACE;
    
    titleText += title3 + SPACE;;
    underTitle += SIGN.repeat(title3.length()) + SPACE;
    
    System.out.print(titleText + SPACE + newLine);
    System.out.print(underTitle);
  }
  public static void main(String[] args)
  {
    Table tb = new Table();
    System.out.println("\n.... Three arguments ....\n");
    tb.display("Product", "Brand", "Price");
  }
}
