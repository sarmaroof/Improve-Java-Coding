package ch00_is_this_book_right_for_you._04_varargs.ans;

// ch 5 exercise 4

public class Table
{
  final String SIGN = "*";
  final String SPACE = "   ";
  
  public void display(String... titles)
  {
    String titleText = "";
    String underTitle = "";
    String newLine = "\n";
    
    for (String title : titles)
    {
      titleText += title + SPACE;;
      underTitle += SIGN.repeat(title.length()) + SPACE;
    }
    System.out.print(titleText + SPACE + newLine);
    System.out.print(underTitle);
  }
  public static void main(String[] args)
  {
    Table tb = new Table();
    System.out.println("\n.... Three arguments ....\n");
    tb.display("Product", "Brand", "Price");
  }
}
