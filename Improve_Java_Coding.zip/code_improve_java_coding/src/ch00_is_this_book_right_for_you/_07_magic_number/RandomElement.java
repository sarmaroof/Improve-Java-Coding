package ch00_is_this_book_right_for_you._07_magic_number;
// ch 14 clean code example 3
import java.util.Random;

public class RandomElement
{
  int[] arraySecret = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
  
  static int[] intArray = { 1, 2 };
  
  public static int getRandom(int[] array)
  {
    int rnd = new Random().nextInt(array.length);
    return array[rnd];
  }
}
