package ch00_is_this_book_right_for_you._06_overriding;
// ch 9 Polymorphism quiz 2
public class Freelancer extends Person
{
  String name = "Emma ";
  
  void printName()
  {
    System.out.print(name);
  }
  public static void main(String[] args)
  {
    Freelancer freelancer = new Freelancer();
  }
}
/*
Quiz 1: Overriding methods

published on DZone on: 28-09-2017

What happens when you try to compile and run the following program?
 
Select the correct answer.
a. This code writes "Robert" to the standard output.
b. This code writes "Emma" to the standard output.
c. This code writes "Emma Robert" to the standard output.
d. This code writes "Robert Emma" to the standard output.
e. This code writes nothing to the standard output.
f. This code writes "null" to the standard output.

The right answer is: f. the code writes "null" to the standard output.

-------------------------

Answer Quiz 1: Overriding methods

1. By creating the object of MySub, the constructor of the superclass MySuper is called.
2. The constructor of MySuper invokes the method myMethod.
3. The method myMethod is overridden in the subclass MySub.
4. The method myMethod writes the value of str2 to the standard output.
5. A superclass doesn't have access to the variables inside its subclass. 
   Therefore the program writes null instead of "y" to the standard output. 
   If you have any other explanation or opinion, share it please in the comments!

*/
/*
Reaction on Dzone
Ivan Karamazov  

Your explanation of the first quiz is wrong. The reason for seeing null is not an "access issue", 
str2 simply has null value(it's initializer was not called yet, it will be called after superclass constructor). 
One can easily check that by adding final modifier to str2, making it constant variable. 
That way str2 is initialized to its target value before any constructor calls, leading to "y" being printed.

*/
