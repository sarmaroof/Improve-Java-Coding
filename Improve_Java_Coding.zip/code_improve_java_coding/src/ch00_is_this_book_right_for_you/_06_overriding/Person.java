package ch00_is_this_book_right_for_you._06_overriding;

public class Person
{
  String name = "Robert ";
  
  public Person()
  {
    printName();
  }
  void printName()
  {
    System.out.print(name);
  }
}
