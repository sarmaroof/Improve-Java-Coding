package ch00_is_this_book_right_for_you._00_how_to_use_this_book;


import java.util.Scanner;

public class MainApp
{
  public static void main(String[] args)
  {
    System.out.println("------Input------");
    Scanner input = new Scanner(System.in);
    System.out.print("Enter your name: ");
    String name = input.nextLine();
    System.out.print("Enter your age: ");
    int age = input.nextInt();
   
    System.out.println("\n------Output------");
    // print the data
    System.out.println("Name:      " + name);
    System.out.println("Age:       " + age);
    input.close();
  }
}
