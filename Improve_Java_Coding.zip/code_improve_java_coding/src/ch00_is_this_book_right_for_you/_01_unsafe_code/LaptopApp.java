package ch00_is_this_book_right_for_you._01_unsafe_code;
// chap 7 encapsulation exercise 3

public class LaptopApp
{
  public static void main(String[] args)
  {
    Laptop laptop = new Laptop();
    laptop.getListLaptops().add("Acer");
    laptop.getListLaptops().remove(2);
    System.out.print("\n"+laptop.getListLaptops());
  }
}
