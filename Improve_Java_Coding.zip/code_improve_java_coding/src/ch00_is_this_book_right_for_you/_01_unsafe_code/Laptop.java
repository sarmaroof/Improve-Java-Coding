package ch00_is_this_book_right_for_you._01_unsafe_code;

import java.util.ArrayList;

public class Laptop
{
  private ArrayList<String> laptops;
  {
    laptops = new ArrayList<>();
    laptops.add("Dell");
    laptops.add("IBM");
    laptops.add("HP");
    laptops.add("Lenovo");
  }
  public ArrayList<String> getListLaptops()
  {
    return laptops;
  }
}
/*

Created: 13-07-2020
This puzzle on Dzone but it was book and library not laptop
Java Puzzle 15: Improving Encapsulation Of Your Code
If the following code is compiled and run, it writes [David, Emma, Layla, Victoria] to the standard output.

By adding Victoria and removing Mike from the customer's list, it's clear that the class TestCustomer is able to modify the list.

How can we improve the encapsulation of the class Customer to achieve the following goals?

1. Other classes should be allowed to display the customer's list.
2. Other classes shouldn't be allowed to remove or add customers to the list.
-----

Answer explanation

Adding and removing elements from the list can be prevented 
by returning a copy of the list as follows.
Replace the statement return customers; with 
return new ArrayList(customers);
You can also return a clone of the ArrayList as follows.
return (ArrayList<String>) customers.clone();

Note: This Java quiz serrie demonstrate idea's and tricks. They might not be the best solutions in every cases.
Some members also suggested other idea's in the comments and a memeber has shared this puzzle on reddit.
I would recommend for more information to have a look at those discussions. 

*/
