package ch03_language_quick_guide.quiz._01_conditional_if;


public class Item
{
  public static void main(String[] args)
  {
    int age = 18;
    boolean isStudent = true;
    double price = 100;
    double discount = 0;
    
    // block 1
    if(age <= 20)
    {
      discount = price * 0.20;
    }
    
    // block 2
    if(isStudent)
    {
      discount += (price * 0.50);
    }
    // block 3
    else
    {
      discount += (price * 0.10);
    }
    price -= discount;
    System.out.printf("\nPrice is:$%.2f", price);
  }
}
/*
Select the correct answer.
a. The code writes Price is $100.00.
b. The code writes Price is $30.00.
c. The code writes Price is $80.00.
d. The code writes Price is $70.00.
e. The code writes Price is $90.00.

The correct answer is b.
*/
