package ch03_language_quick_guide.quiz._07_basic_for;

public class Oil
{
  public static void main(String[] args)
  {
    double price = 40;
    
    for (int year = 1; year <= 5; year++)
    {
      price += 3;
    }
    System.out.printf("Price is: %.2f", price);
  }
}
/*
Select the correct answer.
a. The output of the code is Price is: 55.00.
b. The output of the code is Price is: 43.00.
c. The output of the code is Price is: 46.00.
d. The output of the code is Price is: 49.00.
e. The output of the code is Price is: 52.00.
f. The output of the code is Price is: 40.00.

The correct answer is a.
*/