package ch03_language_quick_guide.quiz._03_conditional_else_if;

public class Programmer
{
  public static void main(String[] args)
  {
    char level = 'J'; // J(Junior), M(Intermediate), S(Senior)
    double salary = 1500;
    
    // block 1
    if(level == 'J')
    {
      salary += 2000;
    }
    // block 2
    else if(level == 'M')
    {
      salary += 4000;
    }
    // block 3
    else if(level == 'S')
    {
      salary += 6000;
    }
    // block 4
    else
    {
      salary += 300;
    }
    System.out.printf("Salary is: %.2f", salary);
  }
}
/*
Select the correct answer.
a. The code writes Salary is: $1800.00.
b. The code writes Salary is: $3500.00.
c. The code writes Salary is: $5500.00.
d. The code writes Salary is: $7500.00.
e. The code writes Salary is: $1500.00.

The correct answer is b.

*/
