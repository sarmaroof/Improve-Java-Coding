package ch03_language_quick_guide.quiz._05_unary_operators_$;

// Dzone 02 e12 
public class Product
{
  static double price = 20;
  
  public static void main(String[] args)
  {
    if(price == price++)
    {
      price++;
      
      if(price == price++)
      {
        ++price;
      }
    }
    else
    {
      price += 8;
    }
    System.out.print(price);
  }
}
/*
Java Quiz 12: Unary Operators

published on DZone on: 01-03-2018

What is the output of this code?

Select the correct answer.
a. This program writes "20.0" to the standard output.
b. This program writes "21.0" to the standard output.
c. This program writes "28.0" to the standard output.
d. This program writes "22.0" to the standard output.
e. This program writes "24.0" to the standard output.

Correct answer is e.
------------------------

Answer Quiz 12: Unary Operators


1. The statement if(a == a++) returns true, because the value of a is incremented by one after the evaluation.
2. The statement a += 3; increments the value of a by 3.
3. The statement System.out.print(a++ + ++a + a++); prints the sum of a++, ++a and a++ to the standard output.
   a++ = 4, ++a = 6, because the value of a is incremented by one a step before.
   The value of the last a-- remains 6. 
   The statement writes (4 + 6 + 6) 16 to the standard output.

The correct answer is: e.
*/
