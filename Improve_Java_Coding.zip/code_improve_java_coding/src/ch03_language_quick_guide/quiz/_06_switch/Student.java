package ch03_language_quick_guide.quiz._06_switch;  

public class Student 
{
	public static void main(String[] args)
	{
		int grade = 8;
		String gradeText = "";
		switch (grade) 
		{
			case 0: case 1: case 2: case 3: case 4: case 5:
				gradeText = "Insufficient";
				break;
			case 6: case 7:
				gradeText = "Sufficient";
				break;
			case 8: case 9:
				gradeText = "Good";
			case 10:
				gradeText = "Excellent";
				break;
			default: 
				gradeText = "Invalid";
		}
		System.out.println(gradeText);
	}
}
/*
Select the correct answer.
a. This program writes "Sufficient" to the standard output.
b. This program writes "Insufficient" to the standard output.
c. This program writes "Good" to the standard output.
d. This program writes " Good Excellent" to the standard output.
e. This program writes "Excellent" to the standard output.
f. This program writes "Invalid" to the standard output.

answer e because the the case 8 and 9 lacks break statement.

*/

