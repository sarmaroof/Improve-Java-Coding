package ch03_language_quick_guide.exercise._01_;

import java.util.Scanner;

public class MaxSum
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    int sum = 0;
    int i = 0;
    
    while (true)
    {
      i++;
      System.out.print("Enter number " + i + ": ");
      int nr = input.nextInt();
      sum += nr;
      
      if(sum >= 100)
      {
        break;
      }
    }
    System.out.println("Sum = " + sum);
    input.close();
  }
}
