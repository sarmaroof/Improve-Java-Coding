package ch03_language_quick_guide.exercise._02_;

import java.util.Scanner;

public class Triangle
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    
    System.out.print("\nEnter a Symbol: ");
    String sign = input.nextLine();
    String line = "";
    
    for (int i = 0; i < 8; i++)
    {
      line += sign;
      System.out.print(line + "\n");
    }
    input.close();
  }
}
