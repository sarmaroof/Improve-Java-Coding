package ch03_language_quick_guide.example._02_do_while;

public class DoWhileLoop
{
  public static void main(String args[])
  {
    int number = 1;
    do
    {
      number++;
      System.out.print("\nNumber is : " + number);
    }
    while (number < 3);
  }
}
