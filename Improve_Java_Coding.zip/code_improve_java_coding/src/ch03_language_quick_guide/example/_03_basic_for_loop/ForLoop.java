package ch03_language_quick_guide.example._03_basic_for_loop;


public class ForLoop
{
  public static void main(String[] args)
  {
    // basic for loop
    for (int i = 0; i < 5; i++)
    {
      System.out.println("i: " + i);
    }
  }
}
