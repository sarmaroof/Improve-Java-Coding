package ch03_language_quick_guide.example._01_while;

public class WhileLoop
{
  public static void main(String[] args)
  {
    int number = 0;
    System.out.println();
    
    while (number < 4)
    {
      number++;
      System.out.println("Number is: " + number);
    }
  }
}
/*
The number has an initial value of zero. Each time in the while loop is checked whether the number
is smaller than 
*/