package ch03_language_quick_guide.example._04_for_loop_infinite;

public class ForLoopInfinite
{
  public static void main(String[] args)
  {
    // infinite for loop
    for (;;)
    {
      System.out.println("Hi...");
    }
  }
}
