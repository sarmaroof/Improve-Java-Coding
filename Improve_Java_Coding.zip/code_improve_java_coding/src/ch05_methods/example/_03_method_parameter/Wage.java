package ch05_methods.example._03_method_parameter;

public class Wage
{
  // yExperience = years of experience
  public double getWage(int yExperience)
  {
    double wage = 1500;
    
    if(yExperience == 2)
    {
      wage += 1000;
    }
    else if(yExperience == 3)
    {
      wage += 2000;
    }
    else if(yExperience > 3)
    {
      wage += 3000;
    }
    else
    {
      wage = 0;
    }
    return wage;
  }
  public static void main(String[] args)
  {
    Wage wage = new Wage();
    System.out.printf("\nWage is: $%.2f ", wage.getWage(3));
  }
}
