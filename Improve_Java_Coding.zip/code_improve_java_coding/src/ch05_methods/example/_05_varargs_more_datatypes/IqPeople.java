package ch05_methods.example._05_varargs_more_datatypes;

public class IqPeople
{
  // varargs arguments
  void write(int iq, String... names)
  {
    System.out.print("\nIQ " + iq + ":");
    
    //System.out.print("Robin ");
    for (String str : names)
    {
      System.out.print(str);
    }
  }
  public static void main(String[] args)
  {
    IqPeople iqP = new IqPeople();
    // one-argument demo
    iqP.write(150);
    // two-arguments demo
    iqP.write(200, " Emma");
    // three-arguments demo
    iqP.write(220, " David", " Vera");
    // five-argument demo
    iqP.write(300, " Einstein", " Newton", " Darwin", " Tesla");
  }
}
/*
Created: 10-02-2018


Here is a simple array of Strings with the length of 4. 


Java 5: Varargs
Exercise 01: Using varargs demo (Example title)

What is the output of the following code?


------------------------

Answer explanation

By using Verargs invoking the methods with different arguments is possible.
Therefore, the program writes the following to the standard output.

Robin,
Robin Emma,
Robin David Emily Vera,
Robin Einstein Newton Darwin Tesla,


*/
