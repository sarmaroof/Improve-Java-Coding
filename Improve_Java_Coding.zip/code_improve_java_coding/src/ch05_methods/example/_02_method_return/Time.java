package ch05_methods.example._02_method_return;

public class Time
{
  public int getMinutesInDay()
  {
    int HoursInDay = 24; // hours
    int MinutesInHour = 60; //minutes
    int minInDay = HoursInDay * MinutesInHour;
    return minInDay;
  }
  public static void main(String[] args)
  {
    Time t = new Time();
    int mInDay = t.getMinutesInDay();
    System.out.println();
    System.out.printf("Minutes in day: " + mInDay);
  }
}
