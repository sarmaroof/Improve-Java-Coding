package ch05_methods.example._04b_varargs_table;


public class Table
{
  final String SIGN = "*";
  final String SPACE = "   ";
  
  public void display(String... titles)
  {
    String titleText = "";
    String underTitle = "";
    String newLine = "\n";
    
    for (String title : titles)
    {
      titleText += title + SPACE;;
      underTitle += SIGN.repeat(title.length()) + SPACE;
    }
    System.out.print(titleText + SPACE + newLine);
    System.out.print(underTitle);
  }
  public static void main(String[] args)
  {
    Table tb = new Table();
    
    System.out.println("\n.... One Column ....\n");
    tb.display("Product");
    
    System.out.println("\n.... Two Columns ....\n");
    tb.display("Product", "Brand");
    
    System.out.println("\n.... Three Columns ....\n");
    tb.display("Product", "Brand", "Price");
  
    System.out.println("\n.... Four Columns ....\n");
    tb.display("Product", "Brand", "Price", "Category");
    
    System.out.println("\n.... Five Columns ....\n");
    tb.display("Product", "Brand", "Price", "Category", "Type");
  }
}
