package ch05_methods.example._01_method_void;

public class Person
{
  String name;
  int age;
  double salary;
  
  public void setData()
  {
    this.name = "Emma";
    this.age = 21;
    this.salary = 3000.00;
  }
  public static void main(String[] args)
  {
    // before calling the method
    Person p = new Person();
    System.out.println();
    System.out.println(p.name);
    System.out.println(p.age);
    System.out.println(p.salary);
    System.out.println("--------------");
    // calling the method
    p.setData();
    // after calling the method
    System.out.println(p.name);
    System.out.println(p.age);
    System.out.println(p.salary);
  }
}
