package ch05_methods.quiz._02_return_method;


public class Metal
{
  public double getPrice(String metal)
  {
    double price = 15;
    
    if(metal.equals("GD")) //........GD: Gold
    {
      price += 2000;
    }
    else if(metal.equals("SV")) //...SV: Silver
    {
      price += 25;
    }
    else if(metal.equals("CP")) //...CP: Copper
    {
      price += 3;
    }
    else
    {
      price -= 5;
    }
    return price;
  }
  public static void main(String[] args)
  {
    Metal m = new Metal();
    double price = m.getPrice(null);
    System.out.println(price);
  }
}
/*
Select the correct answer. 
a. The code writes 2015.0.
b. The code writes 40.0.
c. The code writes 10.0.
d. The code writes null.
e. The code writes 18.0.
f. The code causes error.

The correct answer is f.

*/