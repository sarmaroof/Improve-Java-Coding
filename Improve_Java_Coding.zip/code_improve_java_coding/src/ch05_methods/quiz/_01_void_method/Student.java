package ch05_methods.quiz._01_void_method;


public class Student
{
  String name;
  int age;
  
  public void updateData(String name, int age)
  {
    this.name = name;
    System.out.print(" 1 ");
  }
  public static void main(String[] args)
  {
    Student st1 = new Student();
    st1.updateData("Jack", 24);
    System.out.println(st1.name + " "+ st1.age);
  }
}
/*
Select the correct answer.
a. The code writes 1 Jack 0
b. The code writes 1 Jack 24
c. The code writes 1 null  0
d. The code writes  Jack 0
e. The code writes  Jack 24
f. The code writes  null 0
The correct answer is a.
*/