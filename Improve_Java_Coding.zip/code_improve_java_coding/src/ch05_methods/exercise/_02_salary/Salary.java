package ch05_methods.exercise._02_salary;


import java.util.Scanner;

public class Salary
{
  public static void main(String[] args) 
  {
    Scanner input = new Scanner(System.in);
    // insert your code here
  }
}

