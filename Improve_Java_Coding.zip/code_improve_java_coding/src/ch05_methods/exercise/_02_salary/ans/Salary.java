package ch05_methods.exercise._02_salary.ans;

import java.util.Scanner;

public class Salary
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    
    System.out.print("\nEnter a gross salary: $");
    double grossSalary = input.nextDouble();
    
    System.out.print("Enter a taxrate %: ");
    double taxrate = input.nextDouble();
    
    double totalTax = grossSalary * (taxrate / 100);
    double netSalary = grossSalary - totalTax;
    System.out.printf("The net salary is:$%.2f", netSalary);
    input.close();
  }
}
