package ch05_methods.exercise._01_secret_number.ans;

import java.util.Scanner;
import java.util.ArrayList;

public class SecretNumber
{
  public static void main(String[] args)
  {
    int secretNumber = 9;
    Scanner input = new Scanner(System.in);
    
    while (true)
    {
      System.out.print("\nEnter a number: ");
      int guessNumber = input.nextInt();
      
      if(guessNumber == secretNumber)
      {
        System.out.println("Guess number is correct");
        break;
      }
      else
      {
        System.out.println("Guess is incorrect, try again");
      }
    }
    input.close();
  }
}
