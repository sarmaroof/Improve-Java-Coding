package ch05_methods.exercise._01_secret_number;

import java.util.Scanner;

public class SecretNumber
{
  public static void main(String[] args)
  {
    int secretNumber = 9;
    Scanner input = new Scanner(System.in);
    
    while (true)
    {
      // insert your code here
    }
  }
}
