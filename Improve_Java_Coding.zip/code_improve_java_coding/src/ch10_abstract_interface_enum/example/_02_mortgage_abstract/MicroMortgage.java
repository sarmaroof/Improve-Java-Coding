package ch10_abstract_interface_enum.example._02_mortgage_abstract;



public class MicroMortgage
{
  private double annualIncome;
  
  public MicroMortgage(double annualIncome)
  {
    this.annualIncome = annualIncome;
  }
  public double calculateMort()
  {
    double mortgage = 4 * annualIncome;
    return mortgage;
  }
}
