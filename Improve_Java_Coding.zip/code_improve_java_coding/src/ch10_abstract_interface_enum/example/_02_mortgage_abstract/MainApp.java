package ch10_abstract_interface_enum.example._02_mortgage_abstract;


public class MainApp
{
  public static void main(String[] args)
  {
    MicroMortgage microM = new MicroMortgage(36000);
    double MicroBank = microM.calculateMort();
    
    System.out.printf("\nMortgage MicroBank: $%.2f", MicroBank);
  }
}
