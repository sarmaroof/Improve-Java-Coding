package ch10_abstract_interface_enum.example._04_mortgage_abstract;


public abstract class Mortgage
{
  protected String bName;
  
  public Mortgage(String bName)
  {
    this.bName = bName;
  }
  public abstract double getMortgage();
}
