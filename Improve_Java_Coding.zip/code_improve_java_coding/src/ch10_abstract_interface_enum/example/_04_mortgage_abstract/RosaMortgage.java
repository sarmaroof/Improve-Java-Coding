package ch10_abstract_interface_enum.example._04_mortgage_abstract;




public class RosaMortgage extends Mortgage
{
  private double annualIncome;
  private double assetValue;
  
  public RosaMortgage(double anIncome, double asValue)
  {
    super("Rosa Bank");
    annualIncome = anIncome;
    assetValue = asValue;
  }
  public double getMortgage()
  {
    double mortgage = 3 * annualIncome;
    double assetPercentage = assetValue * 0.15;
    double result = mortgage + assetPercentage;
    return result;
  }
}

/*
The name RosaBank doesn't exist is fiction by my sar maroof



*/