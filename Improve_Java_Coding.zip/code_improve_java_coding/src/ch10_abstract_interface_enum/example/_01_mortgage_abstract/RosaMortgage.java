package ch10_abstract_interface_enum.example._01_mortgage_abstract;



public class RosaMortgage
{
  private double annualIncome;
  private double assetValue;
  
  public RosaMortgage(double anIncome, double asValue)
  {
    annualIncome = anIncome;
    assetValue = asValue;
  }
  public double getMortgage()
  {
    double mortgage = 3 * annualIncome;
    double assetPercentage = assetValue * 0.15;
    double result = mortgage + assetPercentage;
    return result;
  }
}

/*
The name RosaBank doesn't exist is fiction by my sar maroof



*/