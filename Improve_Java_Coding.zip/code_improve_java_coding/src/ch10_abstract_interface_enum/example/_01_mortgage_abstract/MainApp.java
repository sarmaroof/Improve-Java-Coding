package ch10_abstract_interface_enum.example._01_mortgage_abstract;



public class MainApp
{
  public static void main(String[] args)
  {
    RosaMortgage rosaM = new RosaMortgage(36000, 40000);
    double mortgage = rosaM.getMortgage();
    
    System.out.printf("\nMortgage RosaBank: $%.2f", mortgage);
  }
}

/*





*/