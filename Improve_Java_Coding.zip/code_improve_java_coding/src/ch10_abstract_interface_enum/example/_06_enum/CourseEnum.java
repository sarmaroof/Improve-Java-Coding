package ch10_abstract_interface_enum.example._06_enum;



public enum CourseEnum
{
  PHILOSOPHY(1, "What Is the Meaning of Life?"), 
  BIOLOGY(2, "The Genius Idea of Evolution"),
  PHYSICS(3, "Einstein’s Theory of Relativity"), 
  HISTORY(4, "Egyptian Pyramids"),
  GEOGRAPHY(5, "The Continents"), 
  TECHNOLOGY(6, "Blockchain and Cryptocurrency");
  
  private final int id;
  private final String name;
  
  private CourseEnum(int id, String name)
  {
    this.id = id;
    this.name = name;
  }
  public int getId()
  {
    return id;
  }
  public String getName()
  {
    return name;
  }
  public String toString()
  {
    return id + ": " + name;
  }
}
