package ch10_abstract_interface_enum.example._06_enum;


public class MainApp
{
  public static void main(String[] args)
  {
    System.out.println("\nCourse:  "+CourseEnum.PHYSICS);
    System.out.println("Biology: "+CourseEnum.BIOLOGY.getName());
    System.out.println("Tech id: "+CourseEnum.TECHNOLOGY.getId());
  }
}
