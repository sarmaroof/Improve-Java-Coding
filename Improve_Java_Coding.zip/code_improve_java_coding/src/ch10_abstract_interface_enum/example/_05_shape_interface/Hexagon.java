package ch10_abstract_interface_enum.example._05_shape_interface;

public abstract class Hexagon implements Shape
{
  double side = 5;
  
  public Hexagon(double side)
  {
    this.side = side;
  }
  public double getPerimeter()
  {
    return 6 * side;
  }
}
