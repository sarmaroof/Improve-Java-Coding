package ch10_abstract_interface_enum.example._05_shape_interface;

public class Circle implements Shape
{
  private double radius;
  final double PI = 3.14;
  
  public Circle(double radius)
  {
    this.radius = radius;
  }
  public double getArea()
  {
    return PI * radius * radius;
  }
  public double getPerimeter()
  {
    return 2 * PI * radius;
  }
}
