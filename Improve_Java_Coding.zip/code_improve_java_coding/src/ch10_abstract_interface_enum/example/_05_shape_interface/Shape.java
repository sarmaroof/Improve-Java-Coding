package ch10_abstract_interface_enum.example._05_shape_interface;

public interface Shape
{
  public double getArea();
  public double getPerimeter();
}
