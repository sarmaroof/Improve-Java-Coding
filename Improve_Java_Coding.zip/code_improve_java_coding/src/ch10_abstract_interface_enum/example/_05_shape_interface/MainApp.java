package ch10_abstract_interface_enum.example._05_shape_interface;


public class MainApp
{
  public static void main(String[] args)
  {
    Rectangle rec = new Rectangle(10, 20);
    System.out.println("\n... Rectangle ...");
    System.out.printf("Area:%.2f ", rec.getArea());
    System.out.printf("\nPerimeter:%.2f",rec.getPerimeter());
    
    Circle circle = new Circle(20);
    System.out.println("\n... Circle ...");
    System.out.printf("Area:%.2f ", circle.getArea());
    System.out.printf("\nPerimeter:%.2f ", circle.getPerimeter());
    
    // you cannot instantiate the class Hexagon
  }
}
