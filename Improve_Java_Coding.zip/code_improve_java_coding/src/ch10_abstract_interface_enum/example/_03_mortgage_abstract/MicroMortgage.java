package ch10_abstract_interface_enum.example._03_mortgage_abstract;




public class MicroMortgage extends Mortgage
{
  private double annualIncome;
  
  public MicroMortgage(double annualIncome)
  {
    this.annualIncome = annualIncome;
  }
  public double getMortgage()
  {
    double mortgage = 4 * annualIncome;
    return mortgage;
  }
}
