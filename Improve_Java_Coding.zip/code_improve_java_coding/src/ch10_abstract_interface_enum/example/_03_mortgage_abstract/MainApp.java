package ch10_abstract_interface_enum.example._03_mortgage_abstract;

public class MainApp
{
  public static void main(String[] args)
  {
    RosaMortgage rosaM = new RosaMortgage(36000, 50000);
    MicroMortgage microM = new MicroMortgage(36000);
    
    System.out.printf("\nMortgage RB: $%.2f", rosaM.getMortgage());
    System.out.printf("\nMortgage MB: $%.2f", microM.getMortgage());
  }
}
