package ch10_abstract_interface_enum.example._03_mortgage_abstract;


public abstract class Mortgage
{
  public abstract double getMortgage();
}
