package ch10_abstract_interface_enum.exercise._02_enum;

public class Registration
{
  private int age;
  
  Registration()
  {
  }
  public void setAge(int age)
  {
    if(age > 0)
    {
      if(age < 150)
      {
        this.age = age;
        System.out.println("Age is accepted.");
      }
      else
      {
        System.out.println("Age of 150+ is not allowed.");
      }
    }
    else
    {
      System.out.println("Please enter a positive number.");
    }
  }
 
  public int getAge()
  {
    return age;
  }
}
