package ch10_abstract_interface_enum.exercise._02_enum;

public enum Color {
  RED(255, 0, 0),
  GREEN(0, 255, 0),
  BLUE(0, 0, 255);

  private int red;
  private int green;
  private int blue;

  // Enum constructor
  private Color(int red, int green, int blue) {
      this.red = red;
      this.green = green;
      this.blue = blue;
  }

  // Additional methods or fields can be added
  public String getRGB() {
      return "RGB(" + red + ", " + green + ", " + blue + ")";
  }
}