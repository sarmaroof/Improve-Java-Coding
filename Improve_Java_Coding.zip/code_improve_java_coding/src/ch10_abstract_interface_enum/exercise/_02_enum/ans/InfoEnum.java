package ch10_abstract_interface_enum.exercise._02_enum.ans;


public enum InfoEnum
{
  AGE_ACCEPTED("CODE 1", "Age is accepted."),
  AGE_150_IS_REJECTED("CODE 2", "Age of 150 + is not allowed."),
  ENTER_POSITIVE_AGE("CODE 3", "Please enter a positive number."),
  ENTER_YOUR_AGE("CODE 4", "Please enter your age:  ");

  private final String code;
  private final String message;
  
  private InfoEnum(String code, String message)
  {
    this.code = code;
    this.message = message;
  }
  public String getMessage()
  {
    return message;
  }
  public String getCode()
  {
    return code;
  }
  public String toString()
  {
    return code + ": " + message + "\n";
  }
}
