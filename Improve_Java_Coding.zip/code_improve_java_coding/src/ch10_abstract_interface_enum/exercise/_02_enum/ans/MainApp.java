package ch10_abstract_interface_enum.exercise._02_enum.ans;



import java.util.Scanner;

public class MainApp
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    System.out.print("\n" + InfoEnum.ENTER_YOUR_AGE.getMessage());
    int age = input.nextInt();
    Registration rg = new Registration();
    rg.setAge(age);
    input.close();
  }
}
