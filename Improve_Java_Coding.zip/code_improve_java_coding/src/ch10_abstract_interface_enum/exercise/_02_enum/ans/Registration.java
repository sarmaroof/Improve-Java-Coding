package ch10_abstract_interface_enum.exercise._02_enum.ans;


public class Registration
{
  private int age;
  
  Registration()
  {
  }
  public void setAge(int age)
  {
    if(age > 0)
    {
      if(age < 150)
      {
        this.age = age;
        System.out.println(InfoEnum.AGE_ACCEPTED);
      }
      else
      {
        System.out.println(InfoEnum.AGE_150_IS_REJECTED);
      }
    }
    else
    {
      System.out.println(InfoEnum.ENTER_POSITIVE_AGE);
    }
  }
  public int getAge()
  {
    return age;
  }
}
