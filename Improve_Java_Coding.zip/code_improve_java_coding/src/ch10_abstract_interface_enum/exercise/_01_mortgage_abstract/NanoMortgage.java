package ch10_abstract_interface_enum.exercise._01_mortgage_abstract;

public class NanoMortgage extends Mortgage
{
 private double annualIncome;
  
  public NanoMortgage(double annualIncome)
  {
    super("Nano Bank");
    this.annualIncome = annualIncome;
  }
  public double getMortgage()
  {
    double mortgage = 5 * annualIncome;
    return mortgage;
  }
}
