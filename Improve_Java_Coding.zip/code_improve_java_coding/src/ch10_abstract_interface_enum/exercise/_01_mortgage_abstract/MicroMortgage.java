package ch10_abstract_interface_enum.exercise._01_mortgage_abstract;

public class MicroMortgage extends Mortgage
{
  private double annualIncome;
  
  public MicroMortgage(double annualIncome)
  {
    super("Micro Bank");
    this.annualIncome = annualIncome;
  }
  public double getMortgage()
  {
    double mortgage = 4 * annualIncome;
    return mortgage;
  }
}
