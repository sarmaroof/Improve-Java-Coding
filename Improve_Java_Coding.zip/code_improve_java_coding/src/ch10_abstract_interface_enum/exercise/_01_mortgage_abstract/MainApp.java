package ch10_abstract_interface_enum.exercise._01_mortgage_abstract;



public class MainApp
{
  public static void main(String[] args)
  {
    RosaMortgage rm = new RosaMortgage(36000, 50000);
    MicroMortgage mm = new MicroMortgage(36000);
    NanoMortgage nm = new NanoMortgage(36000);
    
    System.out.printf("\n"+rm.bName+": $%.2f",rm.getMortgage());
    System.out.printf("\n"+mm.bName+": $%.2f",mm.getMortgage());
    System.out.printf("\n"+nm.bName+": $%.2f",nm.getMortgage());
  }
}
