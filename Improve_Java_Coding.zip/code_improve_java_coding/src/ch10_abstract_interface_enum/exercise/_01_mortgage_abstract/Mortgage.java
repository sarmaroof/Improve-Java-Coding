package ch10_abstract_interface_enum.exercise._01_mortgage_abstract;

public abstract class Mortgage
{
  protected String bName;
  
  public Mortgage(String bName)
  {
    this.bName = bName;
  }
  public abstract double getMortgage();
}
