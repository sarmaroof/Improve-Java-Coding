package ch01_classes_objects_constructors.exercise._02_customer_account.ans;

public class Customer
{
  String firstname;
  String lastname;
  Account account;
  
  Customer(String firstname, String lastname)
  {
    this.firstname = firstname;
    this.lastname = lastname;
  }
  Customer(String firstname, String lastname, String email)
  {
    this(firstname, lastname);
    this.account = new Account(email);
  }
}
