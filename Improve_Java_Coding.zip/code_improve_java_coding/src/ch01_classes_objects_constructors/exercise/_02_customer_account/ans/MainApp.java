package ch01_classes_objects_constructors.exercise._02_customer_account.ans;

import java.util.Scanner;

public class MainApp
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    
    System.out.print("\nEnter your firstname: ");
    String firstname = input.nextLine();
    
    System.out.print("Enter your lastname: ");
    String lastname = input.nextLine();
    
    System.out.print("Enter your email or q to quit: ");
    String email = input.nextLine();
    
    Customer customer;
    
    if(!email.equals("q"))
    {
      System.out.println("\n.... Your account ....");
      customer = new Customer(firstname, lastname, email);
    }
    else
    {
      System.out.println("\n.... Your info ....");
      customer = new Customer(firstname, lastname);
    }
    System.out.println("Firstname:    " + customer.firstname);
    System.out.println("Lastname:     " + customer.lastname);
    
    if(customer.account != null)
    {
      System.out.println("Email:      " + customer.account.email);
    }
  }
}
