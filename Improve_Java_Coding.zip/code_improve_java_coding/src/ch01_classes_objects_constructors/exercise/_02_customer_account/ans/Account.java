package ch01_classes_objects_constructors.exercise._02_customer_account.ans;

public class Account
{
  String email;
  
  Account(String email)
  {
    this.email = email;
  }
}
