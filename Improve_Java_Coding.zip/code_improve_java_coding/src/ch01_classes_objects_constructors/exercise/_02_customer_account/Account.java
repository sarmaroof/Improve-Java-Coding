package ch01_classes_objects_constructors.exercise._02_customer_account; 

public class Account
{
	String email;
}
