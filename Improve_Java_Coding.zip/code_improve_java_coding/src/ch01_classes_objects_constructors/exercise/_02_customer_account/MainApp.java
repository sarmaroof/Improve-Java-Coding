package ch01_classes_objects_constructors.exercise._02_customer_account;

import java.util.Scanner;

public class MainApp
{
  public static void main(String[] args)
  {
    /*
     *  the code below allows user input
     */
    Scanner input = new Scanner(System.in);
    
    System.out.print("Enter your firstname: ");
    String firstname = input.nextLine();
    
    System.out.print("Enter your lastname: ");
    String lastname = input.nextLine();
    
    System.out.print("Enter your email or q to quit: ");
    String email = input.nextLine();
  }
}
