package ch01_classes_objects_constructors.exercise._01_box;


public class BoxApp
{
  public static void main(String[] args)
  {
    Box box = new Box(100);
    box.width = 20;
    box.height = 10;
    box.depth = 2;
    System.out.println("Volume:  " + box.getVolume());
  }
}
