package ch01_classes_objects_constructors.exercise._01_box.ans;

public class BoxApp
{
  public static void main(String[] args)
  {
    Box box = new Box(100);
    Box box2 = new Box(5, 101);
    System.out.println("Volume: " + box2.getVolume());
    
    Box box3 = new Box(5, 7, 10, 102);
    System.out.println("Volume: " + box3.getVolume());
  }
}
