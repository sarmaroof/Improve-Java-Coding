package ch01_classes_objects_constructors.exercise._01_box.ans;

public class Box
{
  int boxNr;
  double width, height, depth;
  Box(int boxNr)
  {
    this.boxNr = boxNr;
    System.out.println("\nBox number " + boxNr + " is created!");
  }
  Box(double length, int boxNr)
  {
    this(boxNr);
    width = length;
    height = length;
    depth = length;
  }
  Box(double width, double height, double depth, int boxNr)
  {
    this(boxNr);
    this.width = width;
    this.height = height;
    this.depth = depth;
  }
  // calculate the volume 
  double getVolume()
  {
    return width * height * depth;
  }
}
