package ch01_classes_objects_constructors.exercise._01_box;

public class Box
{
  int boxNr;
  double width, height, depth;
  
  Box(int boxNr)
  {
    this.boxNr = boxNr;
    System.out.println("Box number " + boxNr + " is created!");
  }
  // calculate the volume 
  double getVolume()
  {
    return width * height * depth;
  }
}
