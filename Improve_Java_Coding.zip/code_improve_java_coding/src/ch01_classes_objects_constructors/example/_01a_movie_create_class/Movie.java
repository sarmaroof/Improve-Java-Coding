package ch01_classes_objects_constructors.example._01a_movie_create_class;
// create a class
public class Movie
{
  // the attributes(variables)
  String title;
  int runnigTime; // minutes
  double price;
}
