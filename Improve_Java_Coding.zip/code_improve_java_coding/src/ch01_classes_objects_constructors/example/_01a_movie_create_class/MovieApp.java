package ch01_classes_objects_constructors.example._01a_movie_create_class;

public class MovieApp
{
  //the main method to execute the code
  public static void main(String[] args)
  {
    
  }
}
