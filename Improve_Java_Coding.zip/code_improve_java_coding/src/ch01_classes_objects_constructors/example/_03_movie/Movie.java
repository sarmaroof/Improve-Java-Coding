package ch01_classes_objects_constructors.example._03_movie;

public class Movie
{
  // the attributes(variables)
  String title;
  int runnigTime; // minutes
  double price;
  //no-argument constructor
  public Movie()
  {
    System.out.println("no-argument constructor");
  }
  //a constructor with two arguments 
  public Movie(String title, int runnigTime)
  {
    this.title = title;
    this.runnigTime = runnigTime;
  }
  // a constructor with three arguments 
  public Movie(String title, int runnigTime, double price)
  {
    //calling the two-argument constructor using the "this"
    this(title, runnigTime);
    this.price = price;
  }
}