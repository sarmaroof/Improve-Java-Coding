package ch01_classes_objects_constructors.example._03_movie;

public class MovieApp
{
  public static void main(String[] args)
  {
    // calling the no-argument constructor
    Movie movie1 = new Movie(); //...........................1
    Movie movie2 = new Movie("The Godfather", 177); //.......2
    Movie movie3 = new Movie("The Matrix", 136, 18.35); //...3
    
    // print the attributes movie1
    System.out.println("--------movie 1----------");
    System.out.println("Title:        " + movie1.title);
    System.out.println("Running time: " + movie1.runnigTime);
    System.out.println("Price:        " + movie1.price);
    
    // print the attributes movie2
    System.out.println("--------movie 2----------");
    System.out.println("Title:        " + movie2.title);
    System.out.println("Running time: " + movie2.runnigTime);
    System.out.println("Price:        " + movie2.price);
    
    // print the attributes movie3
    System.out.println("--------movie 3----------");
    System.out.println("Title:        " + movie3.title);
    System.out.println("Running time: " + movie3.runnigTime);
    System.out.println("Price:        " + movie3.price);
  }
}
