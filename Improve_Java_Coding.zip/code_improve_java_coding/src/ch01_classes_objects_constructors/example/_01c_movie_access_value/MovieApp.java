package ch01_classes_objects_constructors.example._01c_movie_access_value;

public class MovieApp
{
  //the main method to execute the code
  public static void main(String[] args)
  {
    // create object movie1
    Movie movie1 = new Movie();
    /*
     *  assign values to the 
     *  attributes of the object movie1
     */
    movie1.title = "The Godfather";
    movie1.runnigTime = 177;
    movie1.price = 22.55;
    // create object movie2
    Movie movie2 = new Movie();
    /*
     *  assign values to the 
     *  variables of the object movie2
     */
    movie2.title = "The Matrix";
    movie2.runnigTime = 136;
    movie2.price = 24.65;
  }
}
