package ch01_classes_objects_constructors.example._02_movie;

public class Movie
{
  // the attributes(variables)
  String title;
  int runnigTime; // minutes
  double price;
}
