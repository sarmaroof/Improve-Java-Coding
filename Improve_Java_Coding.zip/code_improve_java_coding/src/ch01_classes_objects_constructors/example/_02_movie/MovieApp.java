package ch01_classes_objects_constructors.example._02_movie;

public class MovieApp
{
  //the main method to execute the code
  public static void main(String[] args)
  {
    // create object movie1
    Movie movie1 = new Movie();
    movie1.title = "The Godfather";
    /* 
     * create references movie2 and movie3
     * to point to the same object
     */
    Movie movie2 = movie1;
    Movie movie3 = movie2;
    // print movie data;
    System.out.println("Movie1 title: " + movie1.title);
    System.out.println("Movie2 title: " + movie2.title);
    System.out.println("Movie3 title: " + movie3.title);
  }
}
