package ch01_classes_objects_constructors.example._01b_movie_instantiate_objects;

public class Movie
{
  // the attributes(variables)
  String title;
  int runnigTime; // minutes
  double price;
}
