package ch01_classes_objects_constructors.example._01b_movie_instantiate_objects;

public class MovieApp
{
  //the main method to execute the code
  public static void main(String[] args)
  {
    // create object movie1
    Movie movie1 = new Movie();
    // create object movie2
    Movie movie2 = new Movie();
  }
}
