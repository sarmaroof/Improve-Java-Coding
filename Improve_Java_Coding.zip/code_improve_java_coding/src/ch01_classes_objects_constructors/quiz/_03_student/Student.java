package ch01_classes_objects_constructors.quiz._03_student;


public class Student
{
  String name;
  
  public Student()
  {
    this.name = "Marco ";
    System.out.print("Robert ");
  }
  public Student(String name)
  {
    this.name = name;
  }
  public static void main(String[] args)
  {
    Student st1 = new Student("Emma ");
    Student st2 = new Student("Anna ");
    Student st3 = new Student();
    st1 = st2;
    st3 = st1;
    st3 = null;
    System.out.print(st1.name);
  }
}
/*
Quiz 3
What happens when the following program is compiled and run?

Select the correct answer.
a. This code writes "Emma" to the standard output. 
b. This code writes "Anna" to the standard output. 
c. This code writes "Robert, Anna" to the standard output. 
d. This code writes "Marco" to the standard output. 
e. This code writes "null" to the standard output. 
f. The code causes an error.


correct is c

*/