package ch01_classes_objects_constructors.quiz._02_aircraft;

public class Aircraft
{
  String brand;
  int nrSeats;
  
  Aircraft()
  {
    this.nrSeats = 250;
    this.brand = "Airbus";
  }
  Aircraft(String brand)
  {
    this();
    brand = "Hawker";
    nrSeats = 300;
  }
  public static void main(String[] args)
  {
    Aircraft ac = new Aircraft("Boeing");
    System.out.println(ac.brand + ", " + ac.nrSeats);
  }
}
/*
Quiz 2
What happens when the following program is compiled and run?

Select the correct answer.
a. This code writes "Boeing, 250" to the standard output. 
b. This code writes "Boeing, 300" to the standard output. 
c. This code writes "Hawker, 300" to the standard output. 
d. This code writes "Airbus, 300" to the standard output. 
e. This code writes "null, 250" to the standard output. 
f. The code causes an error.

Correct is d


*/
