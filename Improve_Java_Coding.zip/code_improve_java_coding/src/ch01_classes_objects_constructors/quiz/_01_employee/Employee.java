package ch01_classes_objects_constructors.quiz._01_employee;

public class Employee
{
  String name = "Ronald";
  int age;
  
  Employee()
  {
    this.name = "Jack";
  }
  Employee(String name)
  {
    this();
  }
  Employee(String name, int age)
  {
    this("David");
  }
  public static void main(String[] args)
  {
    Employee emp = new Employee("John", 22);
    System.out.println(emp.name);
  }
}
/*
Quiz 1
What happens when the following program is compiled and run?

Select the correct answer.
a. This code writes "John" to the standard output. 
b. This code writes "David" to the standard output. 
c. This code writes "Jack" to the standard output. 
d. This code writes "Ronaldo" to the standard output. 
e. This code writes “null” to the standard output. 
f. This code writes nothing to the standard output. 

c is correct

*/
