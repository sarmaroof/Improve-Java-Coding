package ch04_arrays_collections.exercise._01_english_dictionary.ans;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class EnDictionary
{
  Map<String, String> words = new HashMap<String, String>();
  
  public void addWords()
  {
    words.put("Go", "Walk");
    words.put("Buy", "Purchase");
    words.put("Happy", "Pleased");
    words.put("Translate", "Interpret");
    words.put("End", "Finish");
  }
  public static void main(String[] args)
  {
    EnDictionary enDict = new EnDictionary();
    enDict.addWords();
    Scanner input = new Scanner(System.in);
    System.out.print("\nEnter a word: ");
    String key = input.nextLine();
    
    if(enDict.words.containsKey(key))
    {
      String value = enDict.words.get(key);
      System.out.println("Synonymous is: " + value);
    }
    else
    {
      System.out.println("The word "+key+" is not found!");
    }
    input.close();
  }
}

/*

Create a dictionary of English Spanish by using a Map


*/
