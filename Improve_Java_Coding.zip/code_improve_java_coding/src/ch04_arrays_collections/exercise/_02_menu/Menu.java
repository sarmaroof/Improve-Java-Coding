package ch04_arrays_collections.exercise._02_menu;


import java.util.ArrayList;
import java.util.List;

public class Menu
{
  List<String> dishes = new ArrayList<String>();
  
  public void addDishes()
  {
    dishes.add("Rice");
    dishes.add("Pizza");
    dishes.add("Fish");
    dishes.add("Soup");
    dishes.add("Beef");
  }
  public List<String> display()
  {
    return dishes;
  }
}
