package ch04_arrays_collections.exercise._02_menu;


import java.util.Scanner;

public class MainApp
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    Menu menu = new Menu();
    menu.addDishes();
    System.out.print("\nCurrent Menu: " + menu.display());
    
    System.out.print("\nAdd a dish to the menu: ");
    String dish = input.nextLine();
    
    if(menu.dishes.contains(dish))
    {
      System.out.print(dish + " is already on the menu.");
    }
    else
    {
      menu.dishes.add(dish);
      System.out.print(dish + " is added: " + menu.display());
    }
    input.close();
  }
}
