package ch04_arrays_collections.example._01_basic_for_loop;

import java.util.ArrayList;
import java.util.ArrayList;

public class MainApp
{
  public static void main(String[] args)
  {
    Country country1 = new Country("France", "Paris");
    Country country2 = new Country("United States", "Washington");
    Country country3 = new Country("Russia", "Moscow");
    
    ArrayList<Country> countries = new ArrayList<Country>();
    
    countries.add(country1);
    countries.add(country2);
    countries.add(country3);
    System.out.println();
    
    // basic for loop
    for (int i = 0; i < countries.size(); i++)
    {
      System.out.println(countries.get(i).name + ", " 
                       + countries.get(i).capital);
    }
  }
}
