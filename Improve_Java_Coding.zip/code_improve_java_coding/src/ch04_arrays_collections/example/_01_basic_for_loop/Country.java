package ch04_arrays_collections.example._01_basic_for_loop;

public class Country
{
  String name;
  String capital;
  
  public Country(String name, String capital)
  {
    this.name = name;
    this.capital = capital;
  }
}
