package ch04_arrays_collections.example._08_using_hashmap;


import java.util.HashMap;
import java.util.Map;

public class LanguageMap
{
  static Map<String, String> languageMap = 
                           new HashMap<String, String>();
  public static void addDataDisplay()
  {
    languageMap.put("en", "English");
    languageMap.put("fr", "French");
    languageMap.put("de", "German");
  }
  public static void getDataDisplay()
  {
    addDataDisplay();
    System.out.println();
    for (Map.Entry<String, String> entry : languageMap.entrySet())
    {
      String key = entry.getKey();
      String value = entry.getValue();
      System.out.println(key + "  " + value);
    }
  }
  public static void main(String[] args)
  {
    getDataDisplay();
  }
}

/*
// Lambda for map key and value
dataDisplay.forEach((key, value) -> System.out.println(i +"-"+key + " = " + value));
*/
