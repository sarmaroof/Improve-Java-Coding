package ch04_arrays_collections.example._04_lambda_expression;

import java.util.ArrayList;

public class MainApp
{
  public static void main(String[] args)
  {
    Country country1 = new Country("France", "Paris");
    Country country2 = new Country("United States", "Washington");
    Country country3 = new Country("Russia", "Moscow");
    
    ArrayList<Country> countries = new ArrayList<Country>();
    countries.add(country1);
    countries.add(country2);
    countries.add(country3);
    // for loop using lambda expression
    countries.forEach(country ->
    {
      System.out.println(country.name + " " + country.capital);
    });
  }
}
