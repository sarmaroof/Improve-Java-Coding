package ch04_arrays_collections.example._03_using_iterator; 

public class Country 
{
	String name;
	String capital;
	
	public Country(String name, String capital)
	{
		this.name = name;
		this.capital = capital;
	}
}
