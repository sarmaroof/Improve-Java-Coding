package ch04_arrays_collections.example._03_using_iterator;

import java.util.ArrayList;
import java.util.Iterator;

public class MainApp
{
  public static void main(String[] args)
  {
    Country country1 = new Country("France", "Paris");
    Country country2 = new Country("United States", "Washington");
    Country country3 = new Country("Russia", "Moscow");
    
    ArrayList<Country> countries = new ArrayList<Country>();
    countries.add(country1);
    countries.add(country2);
    countries.add(country3);
    // using Iterator
    Iterator<Country> iterator = countries.iterator();
    
    while (iterator.hasNext())
    {
      Country country = iterator.next();
      System.out.println(country.name + " " + country.capital);
    }
  }
}
