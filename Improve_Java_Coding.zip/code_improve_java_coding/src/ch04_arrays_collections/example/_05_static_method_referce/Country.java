package ch04_arrays_collections.example._05_static_method_referce;

import java.util.Arrays;
import java.util.List;

public class Country
{
  public static void main(String[] args)
  {
    List<String> countries = Arrays.asList("US", "DE", "IN");
    
    System.out.println("\n... Lambda expression...");
    countries.forEach(name -> System.out.println(name));
    
    System.out.println("... Static method reference...");
    countries.forEach(System.out::println);
  }
}