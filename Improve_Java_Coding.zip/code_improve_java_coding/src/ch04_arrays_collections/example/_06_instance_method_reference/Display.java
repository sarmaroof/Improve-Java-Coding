package ch04_arrays_collections.example._06_instance_method_reference;

public class Display
{
  void print(String message)
  {
    System.out.println(message);
  }
}
