package ch04_arrays_collections.example._06_instance_method_reference;


import java.util.Arrays;
import java.util.List;

public class Country
{
  public static void main(String[] args)
  {
    List<String> countries = Arrays.asList("UK", "RU", "FR");
    
    System.out.println("\n... Lambda expression...");
    countries.forEach(message -> new Display().print(message));
    
    System.out.println("... Instance method reference...");
    Display display = new Display();
    countries.forEach(display::print);
  }
}
