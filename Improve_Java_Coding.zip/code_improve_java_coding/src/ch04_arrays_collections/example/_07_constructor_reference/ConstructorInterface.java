package ch04_arrays_collections.example._07_constructor_reference;



public interface ConstructorInterface
{
 // functional single abstract method interface
 Country create(String name);
}
