package ch04_arrays_collections.example._07_constructor_reference;



public class MainApp
{
  public static void main(String[] args)
  {
    // constructor reference with a functional interface
    ConstructorInterface constructorRef = Country::new;
    /*
     *  Creating an instance of a Country class
     *  with a constructor reference
     */
    Country instance = constructorRef.create("Constructor Ref");
    // Displaying the value from the created instance
    System.out.println("\nName: " + instance.getName());
  }
}