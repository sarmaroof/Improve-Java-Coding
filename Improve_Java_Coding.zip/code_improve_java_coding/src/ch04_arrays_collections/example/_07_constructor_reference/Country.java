package ch04_arrays_collections.example._07_constructor_reference;

public class Country
{
  private String name;
  // one-argument constructor
  public Country(String name)
  {
    this.name = name;
  }
  public String getName()
  {
    return name;
  }
}
