package ch04_arrays_collections.quiz._01_array;

public class Brand
{
  public static void main(String[] args)
  {
    String[] brands = new String[3];
    brands[1] = "Dell";
    brands[2] = "HP";
    brands[0] = "IBM";
    
    for (int i = 0; i < brands.length; i++)
    {
      System.out.print(brands[i] + " ");
    }
  }
}
/*
Select the correct answer.
a. The output of the code is IBM Dell HP.
b. The output of the code is Dell HP IBM,.
c. The output of the code is HP Dell IBM.
d. The output of the code is IBM, Dell.
e. The output of the code is IBM.
The correct answer is a.



*/