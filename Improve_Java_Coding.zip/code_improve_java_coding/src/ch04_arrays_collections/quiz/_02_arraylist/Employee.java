package ch04_arrays_collections.quiz._02_arraylist;


import java.util.ArrayList;
import java.util.List;

public class Employee
{
  List<String> employees = new ArrayList<String>();
  
  Employee()
  {
    this.employees = new ArrayList<String>();
    employees.add("Emma ");
  }
  Employee(List<String> employees)
  {
    this.employees = employees;
    this.employees.add("Jack ");
  }
  public static void main(String[] args)
  {
    Employee emp1 = new Employee(); //................line 1
    emp1.employees.add("David "); //..................line 2
    Employee emp2 = new Employee(emp1.employees); //..line 3
    
    for (String emp : emp2.employees) //..............line 4
    { 
      System.out.print(emp);
    }
  }
}
/*
Select the correct answer.
a. The output of the code is Jack.
b. The output of the code is Jack David .
c. The output of the code is Emma Jack.
d. The output of the code is Jack David Emma.
e. The output of the code is Emma David Jack.
f. The output of the code is nothing.

The correct answer is e

*/
