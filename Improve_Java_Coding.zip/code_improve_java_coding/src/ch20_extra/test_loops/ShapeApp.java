package ch20_extra.test_loops;

public class ShapeApp
{
	public static void main(String[] args) {
		Shape2d sh = new Shape2d();
		
	}
}
