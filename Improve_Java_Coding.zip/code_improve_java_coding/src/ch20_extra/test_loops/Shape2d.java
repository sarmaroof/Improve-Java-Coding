package ch20_extra.test_loops;

public class Shape2d {
	int totalSignNumbers = 144;
	double numberRows = Math.sqrt(totalSignNumbers);
	double nrColoms = (numberRows/2);
	//int number 
	final String SIGN = "B";
	final String SPACE = " ";
	int nrSpaces = 5;
	final String nextLine = "\n";
	int nrNextLine = 2;
	final int HEIGHT = 1;
	final int WIDTH = 1;
	
	public void printShape() {
		System.out.println("");
		for (int i = 1; i <= totalSignNumbers; i++) {
			System.out.print(SIGN);
			System.out.print(SPACE);
			if(i % nrColoms == 0) {
				System.out.print(SPACE.repeat(5));
			}
			
			if(i % numberRows == 0) {
				System.out.print(nextLine);
			}
			
		  if(i % (totalSignNumbers/2) == 0) {
				System.out.print(nextLine.repeat(nrNextLine));
			}
		}
	}
	
	public static void main(String[] args) {
		Shape2d sh = new Shape2d();
		sh.printShape();
		// sh.printPiramide(sh.SIGN);
		//sh.printReversedTriangle2(9);
		// sh.printReversedTriangle(9);
	}
	
	public void printIt(String sign) {
		System.out.print(sign);
	}
	
	public void printTriangle(int num) {
		for (int i = 0; i <= num; i++) {
			for (int j = num - i; j > 0; j--) {
				System.out.print(" ");
			}
			for (int z = 0; z < i; z++) {
				if(i != 1) {
					System.out.print(10 * i);
				}
				else {
					System.out.print(i);
				}
				
			}
			System.out.println();
		}
	}
	public void printReversedTriangle2(int num) {
		for (int i = 0; i <= num; i++) {
			for (int j = num - i; j > 0; j--) {
				System.out.print("0");
			}
			for (int z = 0; z < i; z++) {
				System.out.print(i);
			}
			for (int j = num - i; j > 0; j--) {
				System.out.print("@");
			}
			System.out.println();
		}
	}
	public void printReversedTriangle(int num) {
		for (int i = 0; i <= num; i++) {
			for (int j = num - i; j > 0; j--) {
				System.out.print(" ");
			}
			for (int z = 0; z < i; z++) {
				System.out.print(i);
			}
			System.out.println();
		}
	}
}
