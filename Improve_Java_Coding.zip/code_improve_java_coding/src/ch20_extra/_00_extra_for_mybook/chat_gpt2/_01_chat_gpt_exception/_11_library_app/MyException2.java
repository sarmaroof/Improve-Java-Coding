package _00_extra_for_mybook.chat_gpt._01_chat_gpt_exception._11_library_app;

public class MyException2 extends Exception
{
  public MyException2(Throwable t)
  {
    super(t);
  }
}
