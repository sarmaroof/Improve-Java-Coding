package _00_extra_for_mybook.chat_gpt._01_chat_gpt_exception._11_library_app;


class MyException extends Exception
{
  // Parameterless Constructor
  public MyException()
  {
  }
  // Constructor that accepts a message
  public MyException(String message)
  {
    super(message);
  }
}