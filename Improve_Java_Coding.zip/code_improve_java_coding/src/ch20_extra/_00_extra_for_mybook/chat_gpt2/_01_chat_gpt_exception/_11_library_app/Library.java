package _00_extra_for_mybook.chat_gpt._01_chat_gpt_exception._11_library_app;

import java.util.ArrayList;
import java.util.InputMismatchException;





/*
 * Chat GPT suggestion
 * 
 * Your Library class seems to be managing a collection of Book objects. Here are some suggestions for improvement:

    Use Generic Collections:
        When declaring your ArrayList, consider using generics to specify the type of elements it will contain. This makes your code type-safe.
        
        Your Library class seems to be managing a collection of Book objects. Here are some suggestions for improvement:

    Use Generic Collections:
        When declaring your ArrayList, consider using generics to specify the type of elements it will contain. This makes your code type-safe.

    java

private ArrayList<Book> books;

Handle Input Mismatch in a More Robust Way:

    The check (id != (int) id) is not a reliable way to determine if id is an integer. It will always evaluate to false because id is declared as an int. Instead, consider using a try-catch block to handle InputMismatchException more effectively.

java

try {
    // Attempt to parse id as an integer
    int parsedId = Integer.parseInt(id);
    System.out.println("Id: " + parsedId);
} catch (NumberFormatException e) {
    System.out.println("Invalid id: " + id);
}

Use Meaningful Exception Handling:

    Instead of catching a generic Exception, catch more specific exceptions like InputMismatchException and handle them appropriately. Also, create a custom exception (e.g., MyException) with a meaningful error message.

java

public Book getBookById(int id) throws MyException {
    try {
        int parsedId = Integer.parseInt(String.valueOf(id));
        System.out.println("Id: " + parsedId);

        for (Book book : books) {
            if (book.getId() == parsedId) {
                System.out.println("The title of the book id " + parsedId + " is: " + book.getTitle());
                return book;
            }
        }

        throw new MyException("The book with id: " + parsedId + " is not found.");
    } catch (NumberFormatException e) {
        throw new MyException("Invalid id: " + id);
    }
}

Handle Null References:

    Before calling getTitle() in the loop, make sure book is not null to avoid a NullPointerException.

java

for (Book book : books) {
    if (book != null && book.getId() == parsedId) {
        System.out.println("The title of the book id " + parsedId + " is: " + book.getTitle());
        return book;
    }
}

Encapsulate the books List:

    You might consider encapsulating access to the books list by providing methods for adding, removing, and querying books. This way, you can control access to the underlying list.

java

    public class Library {
        private ArrayList<Book> books;

        public Library() {
            this.books = new ArrayList<>();
            populateList();
        }

        // Other methods...

        public void addBook(Book book) {
            books.add(book);
        }

        public Book getBookById(int id) throws MyException {
            // ...
        }
    }

These are just suggestions to enhance the readability, robustness, and maintainability of your code. Adjustments can be made based on the specific requirements and design choices for your application.
 */

/*
 * Sar Original
 * public class Library
{
  private ArrayList<Book> books;
  public Library()
  {
    this.books = new ArrayList<Book>();
  }
  public void populateList()
  {
    books.add(new Book(1, "Learn Java"));
    books.add(new Book(2, "Java advanced"));
    books.add(new Book(3, "Learn Python"));
    books.add(new Book(4, "Advanced C++"));
    books.add(new Book(5, "PHP for beginners"));
    books.add(new Book(6, "Learn HTML"));
    books.add(new Book(7, "Database design and SQL"));
    books.add(new Book(8, "UML"));
    books.add(new Book(9, "Object oriented programming"));
    books.add(new Book(10, "Linux operating system"));
  }
  public void getBookID(int id) throws MyException
  {
    
    if(id != (int) id)
    {
      System.out.println("Id: is letter");
    }
    else
    {
      System.out.println("Id: " + id);
    }
  }
  public Book getBookById(int id) throws Exception
  {
    if(id != (int) id)
      throw new Exception("Mismatch id: " + id + "."); //{
    System.out.println(id + " is not an integer");
    //throw new MyException("Mismatch id: "+ id +".");
    
    for (Book book : books)
    {
      
      if(book.getId() == id)
      {
        //bk = book;
        System.out.println("The title of the book id " + id + " is: " + book.getTitle());
        return book;
      }
    }
    throw new MyException("The book with id: " + id + " is not found.");
  }
}

 * 
 * 
 * 
 */
