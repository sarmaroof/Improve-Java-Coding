package _00_extra_for_mybook.chat_gpt._01_chat_gpt_exception._11_library_app;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MainApp
{
  public static void main(String args[])
  {
    Scanner input = new Scanner(System.in);
    System.out.print("Please enter the book id: ");
    try
    {
      int id = input.nextInt();
      Library lb = new Library();
      lb.populateList();
      lb.getBookById(id);
    }
    catch (InputMismatchException e) {
    	System.out.println("The input is not a number. ");
    }
    catch(Exception me)
    {
      System.out.print(me.getMessage());
    }
    input.close();
  }
}
