package _00_extra_for_mybook.chat_gpt.method_reference._03_constructor_reference.example02;

class Person
{
  private String name;
  private int age;
  public Person(String name, int age)
  {
    this.name = name;
    this.age = age;
  }
  // Getter and setter methods...
}
