package _00_extra_for_mybook.chat_gpt.method_reference._03_constructor_reference.example02;


import java.util.function.Supplier;

class Car
{
  Car()
  {
    System.out.println("Car created");
  }
}
public class MethodReferenceExample
{
  public static void main(String[] args)
  {
    // Using lambda expression
    Supplier<Car> carSupplierLambda = () -> new Car();
    carSupplierLambda.get();
    // Using constructor reference
    Supplier<Car> carSupplierReference = Car::new;
    carSupplierReference.get();
  }
}