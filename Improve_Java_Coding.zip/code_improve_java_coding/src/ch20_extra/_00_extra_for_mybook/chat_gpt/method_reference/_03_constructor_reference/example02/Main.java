package _00_extra_for_mybook.chat_gpt.method_reference._03_constructor_reference.example02;

import java.util.function.Function;

public class Main {
    public static void main(String[] args) {
        // Using constructor reference with Function to create instances of Person
        Function<String, Person> personCreator = Person::new;

        // Creating a Person instance using the Function
        Person person = personCreator.apply("John Doe");

        // Displaying the created person's name
        System.out.println("Person's name: " + person.getName());
    }
}