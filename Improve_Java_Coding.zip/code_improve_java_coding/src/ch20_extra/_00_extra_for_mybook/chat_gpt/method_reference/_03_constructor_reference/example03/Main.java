package _00_extra_for_mybook.chat_gpt.method_reference._03_constructor_reference.example03;

public class Main
{
  public static void main(String[] args)
  {
    // Using a constructor reference with a custom functional interface
    MyConstructorInterface constructorReference = MyClass::new;
    // Creating an instance of MyClass using the constructor reference
    MyClass myInstance = constructorReference.create("Hello, Constructor Reference!");
    // Displaying the value from the created instance
    System.out.println("Value: " + myInstance.getValue());
  }
}
