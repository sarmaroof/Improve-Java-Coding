package _00_extra_for_mybook.chat_gpt.method_reference._03_constructor_reference.example03;

class MyClass
{
  private String value;
  // Constructor with a single parameter
  public MyClass(String value)
  {
    this.value = value;
  }
  public String getValue()
  {
    return value;
  }
}