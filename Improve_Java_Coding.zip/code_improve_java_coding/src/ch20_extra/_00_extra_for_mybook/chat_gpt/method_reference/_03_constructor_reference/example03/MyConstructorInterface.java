package _00_extra_for_mybook.chat_gpt.method_reference._03_constructor_reference.example03;

public interface MyConstructorInterface
{
  // A functional interface with a single abstract method
  MyClass create(String value);
}
