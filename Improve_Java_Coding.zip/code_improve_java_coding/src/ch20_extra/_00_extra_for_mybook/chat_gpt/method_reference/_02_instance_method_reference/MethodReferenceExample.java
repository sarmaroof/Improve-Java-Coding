package _00_extra_for_mybook.chat_gpt.method_reference._02_instance_method_reference;

import java.util.Arrays;
import java.util.List;

class Printer
{
  void print(String message)
  {
    System.out.println(message);
  }
}
public class MethodReferenceExample
{
  public static void main(String[] args)
  {
    List<String> messages = Arrays.asList("Hello", "World", "Java", "Method Reference");
    // Using lambda expression
    // messages.forEach(message -> new Printer().print(message));
    // Using instance method reference
    Printer printer = new Printer();
    messages.forEach(printer::print);
  }
}