package _00_extra_for_mybook.chat_gpt.method_reference._01_static_method_reference;

import java.util.Arrays;
import java.util.List;

public class MethodReferenceExample
{
  public static void main(String[] args)
  {
    List<String> names = Arrays.asList("Alice", "Bob", "Charlie", "David");
    // Using lambda expression
    //names.forEach(name -> System.out.println(name));
    // Using static method reference
    names.forEach(System.out::println);
  }
}