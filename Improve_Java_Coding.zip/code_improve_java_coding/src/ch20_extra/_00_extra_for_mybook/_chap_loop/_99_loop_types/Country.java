package _00_extra_for_mybook._chap_loop._99_loop_types; 

public class Country 
{
	String name;
	String capital;
	
	public Country(String name, String capital)
	{
		this.name = name;
		this.capital = capital;
	}
}
