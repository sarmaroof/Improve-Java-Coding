package _00_extra_for_mybook._chap10_enum.extern_code.chat_gpt;

enum Days
{
SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
}
