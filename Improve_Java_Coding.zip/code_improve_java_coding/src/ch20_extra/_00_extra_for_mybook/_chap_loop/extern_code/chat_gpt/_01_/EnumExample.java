package _00_extra_for_mybook._chap10_enum.extern_code.chat_gpt;

public class EnumExample {
  public static void main(String[] args) {
      // Using an enumeration variable
      Days today = Days.WEDNESDAY;

      // Switch statement with enumeration
      switch (today) {
          case MONDAY:
              System.out.println("It's Monday!");
              break;
          case WEDNESDAY:
              System.out.println("It's Wednesday!");
              break;
          case FRIDAY:
              System.out.println("It's Friday!");
              break;
          default:
              System.out.println("It's not Monday, Wednesday, or Friday.");
      }

      // Iterating over all values of the enumeration
      System.out.println("Days of the week:");
      for (Days day : Days.values()) {
          System.out.println(day);
      }
  }
}