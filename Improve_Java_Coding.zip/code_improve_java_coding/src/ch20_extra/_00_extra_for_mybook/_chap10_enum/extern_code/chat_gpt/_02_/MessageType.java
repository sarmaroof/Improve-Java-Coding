package _00_extra_for_mybook._chap10_enum.extern_code.chat_gpt._02_;

public enum MessageType
{
  INFO, WARNING, ERROR
}
