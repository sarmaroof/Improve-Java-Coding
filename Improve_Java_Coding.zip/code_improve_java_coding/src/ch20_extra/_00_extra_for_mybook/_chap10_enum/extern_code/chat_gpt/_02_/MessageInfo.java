package _00_extra_for_mybook._chap10_enum.extern_code.chat_gpt._02_;

public class MessageInfo
{
  // Class representing a user message
  static class UserMessage
  {
    private String content;
    private MessageType type;
    public UserMessage(String content, MessageType type)
    {
      this.content = content;
      this.type = type;
    }
    public String getContent()
    {
      return content;
    }
    public MessageType getType()
    {
      return type;
    }
  }
  // Method to display a user message
  static void displayMessage(UserMessage message)
  {
    
    switch (message.getType())
    {
    case INFO:
      System.out.println("INFO: " + message.getContent());
      break;
    case WARNING:
      System.out.println("WARNING: " + message.getContent());
      break;
    case ERROR:
      System.out.println("ERROR: " + message.getContent());
      break;
    default:
      System.out.println("Unknown message type: " + message.getContent());
    }
  }
  public static void main(String[] args)
  {
    // Creating user messages using the MessageType enum
    UserMessage infoMessage = new UserMessage("This is an information message.", MessageType.INFO);
    UserMessage warningMessage = new UserMessage("Warning! Something may go wrong.", MessageType.WARNING);
    UserMessage errorMessage = new UserMessage("An error has occurred.", MessageType.ERROR);
    // Displaying user messages
    displayMessage(infoMessage);
    displayMessage(warningMessage);
    displayMessage(errorMessage);
  }
}
