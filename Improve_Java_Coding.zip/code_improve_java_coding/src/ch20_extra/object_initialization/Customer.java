package ch00.object_initialization;

public class Customer 
{
	Account account = new Account();
	//Account account;
	
	public Customer(Account account) 
	{
		System.out.println("account1: "+ this.account);
		this.account = account;
		System.out.println("account2: "+ this.account);
	}
}
