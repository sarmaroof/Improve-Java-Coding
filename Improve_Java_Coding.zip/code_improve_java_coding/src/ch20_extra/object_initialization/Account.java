package ch00.object_initialization;

public class Account 
{
	private String username;
	private String password;
}
