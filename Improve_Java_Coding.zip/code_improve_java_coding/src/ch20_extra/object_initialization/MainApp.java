package ch00.object_initialization;

public class MainApp 
{
	public static void main(String[] args) {
		Account account = new Account();
		Customer customer = new Customer(account); 
	}
}
