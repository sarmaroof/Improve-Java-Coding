package ch00_is_this_book_right_for_you._16_garbage_collection.ans;

public class Computer
{
	String brand;
		  
	Computer(String brand)
	{
		this.brand = brand;
	}
}
