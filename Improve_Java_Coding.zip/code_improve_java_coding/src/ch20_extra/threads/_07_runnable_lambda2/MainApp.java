package ch00.threads._07_runnable_lambda2;

public class MainApp {
	
	// Runnable interface contains one method and that is run
	public static void main(String[] args) {
		
		// You can pass the objects because they implements Runnable
		Thread t1 = new Thread(() ->
		{
			for(int i=0; i<6; i++) {
				System.out.println("Hi....");
				try { Thread.sleep(500);} catch(Exception e) {}
			}
		});
		Thread t2 = new Thread(() ->
		{
			for(int i=0; i<6; i++) {
				System.out.println("Goodby....");
				try { Thread.sleep(500);} catch(Exception e) {}
			}
		});
		
		t1.start();
		// delay
		try { Thread.sleep(10);} catch(Exception e) {}
		t2.start();
		
	}
}
/*
The program writes the following to the standard output:
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....



*/