package ch00.threads._08_alive_join;

public class MainApp  {
	
	// Runnable interface contains one method and that is run
	public static void main(String[] args) throws Exception {
		
		// You can pass the objects because they implements Runnable
		Thread t1 = new Thread(() ->
		{
			for(int i=0; i<6; i++) {
				System.out.println("Hi....");
				try { Thread.sleep(500);} catch(Exception e) {}
			}
		});
		Thread t2 = new Thread(() ->
		{
			for(int i=0; i<6; i++) {
				System.out.println("Goodby....");
				try { Thread.sleep(500);} catch(Exception e) {}
			}
		});
		
		t1.start();
		// delay
		try { Thread.sleep(10);} catch(Exception e) {}
		t2.start();
		
		System.out.println(" t1.isAlive() 1: " +t1.isAlive());
		System.out.println(" t2.isAlive() 1: " +t2.isAlive());
		
		t1.join();
		t2.join();
		
		System.out.println(" t1.isAlive() 2: " +t1.isAlive());
		System.out.println(" t2.isAlive() 2: " +t2.isAlive());
		// the t1.join(); and t2.join(); pushes Now.. to the end
		System.out.println("Now .....");
	}
}
/*
The program writes the following to the standard output:
Hi....
Goodby....
 t1.isAlive() 1: true
 t2.isAlive() 1: true
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
 t1.isAlive() 2: false
 t2.isAlive() 2: false
Now .....




*/