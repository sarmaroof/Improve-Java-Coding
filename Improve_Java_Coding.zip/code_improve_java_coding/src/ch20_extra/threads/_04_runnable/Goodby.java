package ch00.threads._04_runnable;

public class Goodby implements Runnable {
	
	public void run() {
		for(int i=0; i<6; i++) {
			System.out.println("Hallow....");
			try {
				Thread.sleep(500);
			} catch(Exception e) {
					
			}
		}
	}
}
