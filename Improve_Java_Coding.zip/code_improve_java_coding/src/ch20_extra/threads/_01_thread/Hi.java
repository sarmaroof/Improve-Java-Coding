package ch00.threads._01_thread;

public class Hi 
{	
	public void print() 
	{
		for(int i=0; i<6; i++) 
		{
			System.out.println("Hi....");
			try 
			{
				Thread.sleep(500);
			} 
			catch(Exception e) 
			{
					
			}
		}
	}
}
