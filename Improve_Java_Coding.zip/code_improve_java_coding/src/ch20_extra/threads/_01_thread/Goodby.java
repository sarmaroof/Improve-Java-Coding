package ch00.threads._01_thread;

public class Goodby 
{
	public void print() 
	{
		for(int i=0; i<6; i++)
		{
			System.out.println("Goodby ....");
			try 
			{
				Thread.sleep(500);
			} 
			catch(Exception e) 
			{
					
			}
		}
	}
}
