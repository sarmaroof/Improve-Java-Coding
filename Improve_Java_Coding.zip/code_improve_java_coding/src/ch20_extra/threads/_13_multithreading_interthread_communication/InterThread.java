package ch00.threads._13_multithreading_interthread_communication;

public class InterThread {
	
	public static void main(String[] args)  {
		Q q = new Q();
		new Producer(q);
		new Consumer(q);
	}
}

/*
The program writes the following to the standard output:
and it goes on .......

put: 0
get: 0
get: 0
put: 1
put: 2
get: 1
put: 3
get: 3
put: 4
get: 4
put: 5
get: 4
put: 6
get: 5
put: 7
get: 7
put: 8
get: 8
put: 9
get: 9
put: 10
get: 10
put: 11
get: 10
get: 11
put: 12
get: 12
put: 13
put: 14
get: 13
put: 15
get: 14


*/