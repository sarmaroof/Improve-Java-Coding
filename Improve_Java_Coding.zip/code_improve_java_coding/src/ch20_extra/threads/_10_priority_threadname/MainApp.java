package ch00.threads._10_priority_threadname;

public class MainApp  {
	
	// Runnable interface contains one method and that is run
	public static void main(String[] args) throws Exception {
		
		// You can pass the objects because they implements Runnable
		Thread t1 = new Thread(() ->
		{
			for(int i=0; i<6; i++) {
				System.out.println("Hi....");
				try { Thread.sleep(500);} catch(Exception e) {}
			}
		});
		Thread t2 = new Thread(() ->
		{
			for(int i=0; i<6; i++) {
				System.out.println("Goodby....");
				try { Thread.sleep(500);} catch(Exception e) {}
			}
		});
		
		// by default both t1 and t2 have priority of 5
		// the range of priority is from 1 least priority to higher priority of 10
		System.out.println(" t1.getPriority(): " +t1.getPriority());
		System.out.println(" t2.getPriority(): " +t2.getPriority());
		
		t1.setName("Sar thread 1");
		t2.setName("Sar thread 2");
		System.out.println(" t1.getName(): " +t1.getName());
		System.out.println(" t2.getName(): " +t2.getName());
		
		t1.start();
		// delay
		try { Thread.sleep(10);} catch(Exception e) {}
		t2.start();
		
		t1.join();
		t2.join();
		
		// the t1.join(); and t2.join(); pushes Now.. to the end
		System.out.println("Now .....");
	}
}
/*
The program writes the following to the standard output:
t1.getPriority(): 5
 t2.getPriority(): 5
 t1.getName(): Sar thread 1
 t2.getName(): Sar thread 2
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Now .....





*/