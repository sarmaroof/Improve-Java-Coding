package ch00.threads._02_thread;

public class Goodby extends Thread{
	
	public void run() {
		for(int i=0; i<6; i++) {
			System.out.println("Hallow....");
			try {
				Thread.sleep(500);
			} catch(Exception e) {
					
			}
		}
	}
}
