package ch00.threads._12_multithread_synchronized;

public class SyncDemo {
	
	public static void main(String[] args) throws Exception {
		
		Counter c = new Counter();
		
		Thread t1 = new Thread(new Runnable() {
					public void run() {
						for(int i=1; i<=1000; i++) {
							c.increment();
						}
					}
				});
		
		Thread t2 = new Thread(new Runnable() {
			public void run() {
				for(int i=1; i<=1000; i++) {
					c.increment();
				}
			}
		});
		
		t1.start();
		t2.start();
		// ask the main method to wait for t1
		t1.join();
		t2.join();
		
		System.out.println("Count: " + c.count);
	}
}

/*
The program writes the following to the standard output:
Accordign to expectation it should be 2000, but because 
the t1 and t2 some times interferer each others work. Therefore
the result would be less like: 1421 or 1942 ... etc.

To make the result safe you should add the keyword synchronized to the method
increment.
The issue is because both threads at the same time accessing the same method.

By synchronizing the method increment you make it thread safe and only one thread at a time can access the method.
after that the value always will be 2000

*/