package ch00.threads._12_multithread_synchronized;

public class Counter {
	
	int count;
	
	public synchronized void increment() {
		count ++; // count = count + 1 increment and assignment
	}
}

