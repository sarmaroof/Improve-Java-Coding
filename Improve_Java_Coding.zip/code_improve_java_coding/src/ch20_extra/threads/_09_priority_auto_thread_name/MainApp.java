package ch00.threads._09_priority_auto_thread_name;

public class MainApp  {
	
	// Runnable interface contains one method and that is run
	public static void main(String[] args) throws Exception {
		
		// You can pass the objects because they implements Runnable
		Thread t1 = new Thread(() ->
		{
			for(int i=0; i<6; i++) {
				System.out.println("Hi....");
				try { Thread.sleep(500);} catch(Exception e) {}
			}
		});
		Thread t2 = new Thread(() ->
		{
			for(int i=0; i<6; i++) {
				System.out.println("Goodby....");
				try { Thread.sleep(500);} catch(Exception e) {}
			}
		});
		
		System.out.println(" t1.getName(): " +t1.getName());
		System.out.println(" t2.getName(): " +t2.getName());
		
		t1.start();
		// delay
		try { Thread.sleep(10);} catch(Exception e) {}
		t2.start();
		
		t1.join();
		t2.join();
		
		// the t1.join(); and t2.join(); pushes Now.. to the end
		System.out.println("Now .....");
	}
}
/*
The program writes the following to the standard output:
t1.getName(): Thread-0
 t2.getName(): Thread-1
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Now .....




*/