package ch00.threads._06_runnable_lambda;

public class MainApp {
	
	// Runnable interface contains one method and that is run
	public static void main(String[] args) {
		// Using annonymous classes
		Runnable obj1 = () ->
		{
			for(int i=0; i<6; i++) {
				System.out.println("Hi....");
				try { Thread.sleep(500);} catch(Exception e) {}
			}
		};
		
		// Using annonymous classes
		Runnable obj2 = () ->
		{
			for(int i=0; i<6; i++) {
				System.out.println("Goodby....");
				try { Thread.sleep(500);} catch(Exception e) {}
			}
		};
		
		// You can pass the objects because they implements Runnable
		Thread t1 = new Thread(obj1);
		Thread t2 = new Thread(obj2);
		
		t1.start();
		// delay
		try { Thread.sleep(10);} catch(Exception e) {}
		t2.start();
		
	}
}
/*
The program writes the following to the standard output:
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....
Hi....
Goodby....

*/