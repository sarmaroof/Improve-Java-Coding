package ch00.threads._03_thread;

public class Hi extends Thread{
	
	public void run() {
		for(int i=0; i<6; i++) {
			System.out.println("Hi....");
			try {
				Thread.sleep(500);
			} catch(Exception e) {
					
			}
		}
	}
}
