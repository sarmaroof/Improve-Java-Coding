package ch20_extra.ch15_object_references._01_soft_reference;

import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.List;

public class MainApp
{
  SoftReference<List<String>> listReference = new SoftReference<List<String>>(new ArrayList<String>());
  List<String> list = listReference.get();
  /*if (list == null) {
      // object was already cleared
  }*/
}
