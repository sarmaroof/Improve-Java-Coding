package ch05_methods.example._24_method;  

public class Student 
{
	String getGrade(int grade)
	{
		String gradeText = "";
		switch (grade) 
		{
			case 0: case 1: case 2: case 3: case 4: case 5:
				gradeText = "Insufficient";
				break;
			case 6: case 7:
				gradeText = "Sufficient";
			case 8: case 9:
				gradeText = "Good";
				break;
			case 10:
				gradeText = "Excellent";
				break;
			default: 
				gradeText = "Invalid";
		}
		return gradeText;
	}
	public static void main(String[] args)
	{
		Student student = new Student();
		//System.out.print(student.getGrade());
	}
}
