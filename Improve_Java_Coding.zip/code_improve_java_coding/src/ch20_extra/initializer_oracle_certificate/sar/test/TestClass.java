package ch00.initializer_oracle_certificate.sar.test;

public class TestClass
{
  public static void main(String[] args)
  {
    // Dog dog = new Dog();
    Animal animal = new Dog();
  }
}
class Dog extends Animal
{
  int x = getValue2();
  
  Dog()
  {
    System.out.println("dog constructor");
  }
  int getValue2()
  {
    System.out.println("dog method");
    return 20;
  }
}
class Animal
{
  int x = getValue();
  
  Animal()
  {
    System.out.println("animal constructor");
  }
  int getValue()
  {
    System.out.println("animal method");
    return 10;
  }
}
