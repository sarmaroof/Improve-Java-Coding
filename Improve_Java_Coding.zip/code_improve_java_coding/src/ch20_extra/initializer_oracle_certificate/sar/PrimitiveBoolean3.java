package ch00.initializer_oracle_certificate.sar;

public class PrimitiveBoolean3
{
  public static void main(String args[])
  {
    int i = 0;
    boolean bool1 = true;
    boolean bool2 = false;
    boolean bool = false;
    bool = (bool2 & method1("1")); // 1
    bool = (bool2 && method1("2")); // 2
    bool = (bool1 | method1("3")); // 3
    bool = (bool1 || method1("4")); // 4
  }
  public static boolean method1(String str)
  {
    System.out.println(str);
    return true;
  }
}
/*
t03_23
Which statements about the output of the following programs are true?
1 will be the part of the output.
   & (unlike &&), when used as a logical operator, does not short circuit the expression, 
   which means it always evaluates both the operands even if the result of the whole expression 
   can be known by just evaluating the left operand.
2 will be the part of the output.
3 will be the part of the output.
   & and | (unlike && and ||), when used as logical operators, do not short circuit the expression, 
   which means they always evaluate both the operands even if the result of the whole expression 
   can be known by just evaluating the left operand.
4 will be the part of the output.
None of the above
& and | do not short circuit the expression. The value of all the expressions ( 1 through 4) 
can be determined just by looking at the first part. && and || do not evaluate the rest of 
the expression if the result of the whole expression can be known by just evaluating the 
left operand, so method1() is not called for 2 and 4.
*/
