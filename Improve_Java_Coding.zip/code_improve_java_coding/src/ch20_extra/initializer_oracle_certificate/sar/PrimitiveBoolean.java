package ch00.initializer_oracle_certificate.sar;

public class PrimitiveBoolean
{
  public static void main(String[] args)
  {
    boolean b1 = false;
    boolean b2 = false;
    boolean b3 = true;
    // if(b2 != b1 = !b2) // invalid
    // if(b2 = b3 = !b2) // returns true .............this means if(!b2) is true
    // if(b2 = b1 = !b2) // returns true .............this means if(!b2) is true
    // if(b2 = b1 = b2) // returns false .............this means if(b2) is false
    // if(b2 = b1 = b3) // returns true .............this means if(b3) is true
    // if(b2 = b1 = !b3) // returns false .............this means if(!b3) is false
    // if(b2 = b3) // returns true .............this means if(b1) is false
    // if(b2 = b1) // returns false
    // if(b2) // returns false .............this means if(b2) is false
    // if(b2 == b1 == b2) // is b2 equal to b1 == b2? false
    // if(b3 == b1 == b2) // is b3 equal to b1 == b2? true
    if(b3 == b3 == b2) // is b3 equal to b3 == b2? false
    {
      System.out.println("true");
    }
    else
    {
      System.out.println("false");
    }
  }
}
/*
t01_e31;

Note that  boolean operators have more precedence than =. (In fact, = has least precedence of all operators.)
so, in (b2 != b1 = !b2)  first b2 != b1 is evaluated which returns a value 'false'. 
So the expression becomes 

false = !b2. And this is illegal because false is a value and not a variable!
 
Had it been something like 
(b2 = b1 != b2) then it is valid because it will boil down to : 
b2 = false.
Because all an if() needs is a boolean, now b1 != b2 returns false which is a boolean and as b2 =  false 
is an expression and every expression has a return value (which is actually the Left Hand Side of the expression). 
Here, it returns false, which is again a boolean.

Note that return value of expression :  i = 10 , where i is an int, is 10 (an int).
*/
