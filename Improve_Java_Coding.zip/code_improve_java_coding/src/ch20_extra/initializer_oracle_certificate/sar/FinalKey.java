package ch00.initializer_oracle_certificate.sar;

public class FinalKey
{
  int value = 1;
  FinalKey link;
  
  public FinalKey(int val)
  {
    this.value = val;
  }
  public static void main(String[] args)
  {
    final FinalKey a = new FinalKey(5);
    FinalKey b = new FinalKey(10);
    a.link = b;
    b.link = setIt(a, b);
    System.out.println(a.link.value + " " + b.link.value);
    // System.out.println(a.value + " " + b.value);
  }
  public static FinalKey setIt(final FinalKey x, final FinalKey y)
  {
    x.link = y.link;
    return x;
  }
}
/*
It will not compile because 'a' is final.
    'a' is final is true, but that only means that a will keep pointing to the same object for 
    the entire life of the program. The object's internal fields, however, can change.
It will not compile because method setIt() cannot change x.link.
    Since x and y are final, the method cannot change x and y to point to some other object but it can 
    change the objects' internal fields.
It will print 5, 10.
    It will print 10, 10.
It will throw an exception when run.
   When method setIt() executes, x.link = y.link, x.link becomes null because y.link is null so 
   a.link.value throws NullPointerException.
    
   

*/
