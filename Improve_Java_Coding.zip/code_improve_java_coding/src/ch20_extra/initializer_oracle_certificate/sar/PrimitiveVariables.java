package ch00.initializer_oracle_certificate.sar;

public class PrimitiveVariables
{
  public static void main(String args[])
  {
    char c;
    int i;
    c = 'a';// 1
    i = c; // 2
    i++; // 3
   // c = i; // 4
    c++; // 5
  }
}
/*
t01_e02;

1. A char value can ALWAYS be assigned to an int variable, since the int type is wider than the char type. So line 2 is valid.

2. Line 4 will not compile because it is trying to assign an int to a char. 
   Although the value of i can be held by the char but since  'i' is not a constant but a variable, 
   implicit narrowing will not occur.

Here is the rule given in JLS regarding assigment of constant values to primitive variables without explicit cast:

A narrowing primitive conversion may be used if all of the following conditions are satisfied:

1. The expression is a compile time constant expression of type byte, char, short, or int.
2. The type of the variable is byte, short, or char.
3. The value of the expression (which is known at compile time, because it is a constant expression) is 
   representable in the type of the variable.

Note that implict narrowing conversion (i.e. conversion without an explicit cast) does not apply to float, long, or double.
For example, char ch = 30L; will fail to compile although 30 is small enough to fit into a char.

public class SarTest
{
  public static void main(String args[])
  {
    boolean bl = false; // 1 bit
    byte b = 127; // 8 bits
    short s = 300; // 16 bits -128 till 127
    char c; // 16 bits
    int i = 400; // 32 bits
    long l = 500; // 64 bits
    float f = 450; // 32 bits
    double d = 550; // 64 bits;
    d = l;
    l = (long) d;
    c = 'a';// 1
    i = c; // 2
    i++; // 3
    // c = i; // 4
    c++; // 5
    System.out.println(i = s);
    System.out.println(l = i);
    // System.out.println(c);
  }
}


*/
