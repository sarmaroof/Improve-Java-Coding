package ch00.initializer_oracle_certificate.sar;

public class DeclarePrimitive
{
  public static void mian(String[] args)
  {
    byte b10 = 'c';
    short s10 = 'd';
    int i10 = 'H';
    long l10 = 'N';
    double d10 = 'D';
    float f10 = 'F';
    System.out.print(b10);
    System.out.print(s10);
  }
  
  // t04_01
  // Chaining to use a value of a variable at the time of declaration is not allowed.
  // int a = b = c = 100;
  // nt a= 100 = b = c;
  int b = 4, c = 2;
  int a4 = 100, b4, c4;
  int a3, b3, c3 = 100;
  int a2, b2, c2;
  // a2=b2=c2=100;
  
  // int a2, b2, c2;a2=b2=c2=100;
  // t02_34
  // public DeclarePrimitive(String s); // wrong constructor
  // This constructor allowed. The compiler ignores the semicolon
  public DeclarePrimitive(String s1, String s2)
  {
  }; // 5
  void myMethod()
  {
    DeclarePrimitive mc = new DeclarePrimitive("x", "s");
  }
  
  short s = 12;
  long g = 012;
  // int i = (int) false;
  float f = -123;
  float fl = 423434;
  // float d = 0 * 1.5; // mismatch cannot convert from double to float
  // float f3 = 3.33; // mismatch cannot convert from double to float
  float f2 = 2.005f;
  float d = 0 * (float) 1.5;
  // byte b = 128; // the byte range is from -128 to 127
  // t04_42
  // A field cannot be abstract
  // abstract int t;
  // The position of private is allowed
  final static private double PI = 3.14159265358979323846;
}
/*
t02_e33;

Note that float d = 0 * 1.5f; and float d = 0 * (float)1.5 ; are OK  An implicit 
narrowing primitive conversion may be used if all of the following conditions are satisfied:  
1. The expression is a compile time constant expression of type byte, char, short, or int.  
2. The type of the variable is byte, short, or char.  
3. The value of the expression (which is known at compile time, because it is a constant expression) 
is representable in the type of the variable.  Note that implicit narrowing conversion does not 
apply to long or double. So, char ch = 30L; will fail even though 30 is representable in char.


*/
