package ch00.initializer_oracle_certificate.sar;

public class CastTest
{
  public static void main(String args[])
  {
    // b = i
    byte b = -128;
    int i = b;
    b = (byte) i;
    // i = l
    System.out.println(i + " " + b);
    long l = 43434;
    int i2 = (int) l;
    short s = (short) l;
    System.out.println(l + " " + i2);
    // f = d
    double d = 444.99;
    float f = (float) d;
    System.out.println(d + " " + f);
    // i = d
    double d2 = 44.99;
    d2 = i;
    int i3 = (int) d2;
    System.out.println(i3 + " " + d2);
  }
}
/*
t01_e61;


*/
