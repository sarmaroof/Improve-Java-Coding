package ch00.initializer_oracle_certificate.sar;

public class FloatInfo
{
  float f1 = -1;
  float f2 = 0x0123;
  float f3 = 4;
  float f4 = 1.0f;
  float f5 = 43e1f;
  // float f4 = 1.0; // incorrect
  // float f8 = 43e1; // incorrect
  float f6 = (float) 1.0;
  float f7 = (float) 43e1f;
}
/*
t02_e64
Although the values in the option 1 and 2 are compile time constants and the values i.e. 1.0 
and 43e1 can fit into a float, implicit narrowing does not happen because implicit 
narrowing is permitted only among byte, char, short, and int.
*/
