package ch00.initializer_oracle_certificate.t01_e68;

public class MyClass
{
  public static void main(String[] args)
  {
    // -------- Only false false is false -------------
    boolean b1 = true | true;
    boolean b2 = false | false;
    boolean b3 = true | false;
    boolean b4 = false | true;
    // -------- Only false false is false -------------
    boolean b9 = true || true;
    boolean b10 = false || false;
    boolean b11 = true || false;
    boolean b12 = false || true;
    // -------- Only true true is true -------------
    boolean b5 = true & true;
    boolean b6 = false & false;
    boolean b7 = true & false;
    boolean b8 = false & true;
    // -------- Only true true is true -------------
    boolean b13 = true && true;
    boolean b14 = false && false;
    boolean b15 = true && false;
    boolean b16 = false && true;
    /*boolean b3 = (12 < 11);
    boolean b4 = (12 > 11);
    boolean b5 = false || true;
    boolean b6 = true || false;
    boolean b6 = true || false;
    boolean b7 = true && false;
    boolean b8 = false && true;*/
    // System.out.println("b, b, b , b " + b + ", " + b + ", " + b + ", " + b);
    // System.out.println("b1, b2, b3 , b4 " + b1 + ", " + b2 + ", " + b3 + ", " + b4);
    System.out.println("b9, b10, b11 , b12 " + b9 + ", " + b10 + ", " + b11 + ", " + b12);
    System.out.println("b5, b6, b7 , b8 " + b5 + ", " + b6 + ", " + b7 + ", " + b8);
    System.out.println("b13, b14, b15 , b16 " + b13 + ", " + b14 + ", " + b15 + ", " + b16);
    // boolean b1 = null; not correct
    // boolean b2 = 1; not correct
  }
}
/*
t01_e68;

Which of the following declarations is/are valid:


1.  bool b = null;

2. boolean b = 1;

3. boolean b = true|false;

4 bool b = (10<11);

5. boolean b = true||false;


*/
