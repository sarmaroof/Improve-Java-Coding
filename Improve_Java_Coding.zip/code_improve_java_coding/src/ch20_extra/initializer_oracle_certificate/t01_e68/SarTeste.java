package ch00.initializer_oracle_certificate.t01_e68;

public class SarTeste
{
  public static void main(String[] args)
  {
    boolean b1 = true | true;
    boolean b2 = false | false;
    boolean b3 = true | false;
    boolean b4 = false | true;
    /*boolean b3 = (12 < 11);
    boolean b4 = (12 > 11);
    boolean b5 = false || true;
    boolean b6 = true || false;
    boolean b6 = true || false;
    boolean b7 = true && false;
    boolean b8 = false && true;*/
    // System.out.println("b, b, b , b " + b + ", " + b + ", " + b + ", " + b);
    System.out.println("b1, b2, b3 , b4 " + b1 + ", " + b2 + ", " + b3 + ", " + b4);
    // boolean b1 = null; not correct
    // boolean b2 = 1; not correct
  }
}
