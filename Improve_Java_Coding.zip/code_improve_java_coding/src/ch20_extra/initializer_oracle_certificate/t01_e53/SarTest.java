package ch00.initializer_oracle_certificate.t01_e53;

public class SarTest
{
  public static void main(String[] args)
  {
    char c = 10; // valid 16 bits 0 to 65,535
    char c2 = 44;
    byte b = 22; // from -128 to 127
    Runnable r = new Thread();
    Runnable r2 = new Runnable()
    {
      public void run()
      {
      }
    };
  }
}
