package ch00.initializer_oracle_certificate.t01_e53;

public class MyClass
{
  public static void main(String[] args)
  {
    char c = 10; // valid 16 bits 0 to 65,535
    char c2 = 22323;
    byte b = 22; // from -128 to 127
  }
}
