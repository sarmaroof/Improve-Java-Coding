package ch00.initializer_oracle_certificate.t02_e33;

public class MyClass
{
  // t02_34
  // public MyClass(String s); // wrong constructor
  // This constructor allowed. The compiler ignores the semicolon
  public MyClass(String s1, String s2)
  {
  }; // 5
  void myMethod()
  {
    MyClass mc = new MyClass("x", "s");
  }
  
  short s = 12;
  long g = 012;
  // int i = (int) false;
  float f = -123;
  // float d = 0 * 1.5; // mismatch cannot convert from double to float
  // float f3 = 3.33; // mismatch cannot convert from double to float
  float f2 = 2.005f;
  float d = 0 * (float) 1.5;
  // byte b = 128; // the byte range is from -128 to 127
}
/*
t02_e33;

Note that float d = 0 * 1.5f; and float d = 0 * (float)1.5 ; are OK  An implicit 
narrowing primitive conversion may be used if all of the following conditions are satisfied:  
1. The expression is a compile time constant expression of type byte, char, short, or int.  
2. The type of the variable is byte, short, or char.  
3. The value of the expression (which is known at compile time, because it is a constant expression) 
is representable in the type of the variable.  Note that implicit narrowing conversion does not 
apply to long or double. So, char ch = 30L; will fail even though 30 is representable in char.


*/
