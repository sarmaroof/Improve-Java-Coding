package ch00.initializer_oracle_certificate.t01_e61;

public class SarTest
{
  public static void main(String args[])
  {
    // byte b = -128;
    int i = 874;
    byte b = (byte) i;
    System.out.println(i + " " + b);
  }
}
