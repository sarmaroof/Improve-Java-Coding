package ch00.initializer_oracle_certificate.t01_e61;

public class CastTest
{
  public static void main(String args[])
  {
    byte b = -128;
    int i = b;
    b = (byte) i;
    System.out.println(i + " " + b);
  }
}
/*
t01_e61;


*/
