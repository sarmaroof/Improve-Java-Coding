package ch00.initializer_oracle_certificate.run_priority_sar._01;

public class Laptop {
	public String brand = "HP";
	public int ram = 8;
	
	public Laptop() {
		System.out.println("Brand: " + brand);
		System.out.println("RAM:   " + ram);
	}
}