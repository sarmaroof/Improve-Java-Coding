package ch00.initializer_oracle_certificate.run_priority_sar._01;

public class InitializeWithinClass {
	
	Laptop laptop = new Laptop();
	
	public InitializeWithinClass() {
		System.out.println();
	}
	  
	public static void main(String[] args){
		//InitializeWithinClass iwc = new InitializeWithinClass();
	}
}

