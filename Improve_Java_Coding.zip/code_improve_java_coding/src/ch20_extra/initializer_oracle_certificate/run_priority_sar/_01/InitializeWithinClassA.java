package ch00.initializer_oracle_certificate.run_priority_sar._01;

public class InitializeWithinClassA {

	
	
	public InitializeWithinClassA() {
		Laptop laptop = new Laptop();
	}
	
	public Laptop getLaptop() {
		return new Laptop();
	}
	  
	public static void main(String[] args){
		InitializeWithinClassA iwc = new InitializeWithinClassA();
	}
}

