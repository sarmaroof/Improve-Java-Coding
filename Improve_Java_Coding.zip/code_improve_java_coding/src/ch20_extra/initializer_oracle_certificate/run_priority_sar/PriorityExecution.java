package ch00.initializer_oracle_certificate.run_priority_sar;

public class PriorityExecution {
	
	private static int loop = 15;
	static final int INTERVAL = 10;
	boolean flag;
	// line 1
	static
	{
		System.out.println("Static 1");
	}
	static
	{
		System.out.println("Static 2");
	}
	{
		System.out.println("Static 4");
	}
	static
	{
		System.out.println("Static 3");
	}
	
	  
	public static void main(String[] args)
	{
		PriorityExecution pe = new PriorityExecution();
	}
}
