package ch00.initializer_oracle_certificate.run_priority_sar;

// This is from oracle original

public class MyClass
{
	int i4 = getAge("4");
	int i5 = getAge("5");
	final int i19 = getAge("a");
	
	{
		int i6 = getAge("6");
	}
	
	MyClass() {
		int i9 = getAge("9");
	}
	
	int i7 = getAge("7");
	
	static {
		int i1 = getAge("1");
	}
	
	static int i2 = getAge("2");
	
	{
		int i8 = getAge("8");
	}
	
	static {
		int i3 = getAge("3");
	} 
	  
	public static int getAge(String str) {
		System.out.print(str);
		return 20;
	}
	  
	public static void main(String[] args){
		MyClass mc = new MyClass();
	}
}
/*
First, static statements/blocks are called IN THE ORDER they are defined. 
Next, instance initializer statements/blocks are called IN THE ORDER they are defined. 
Finally, the constructor is called. So, it prints a b c 2 3 4 1.
*/
