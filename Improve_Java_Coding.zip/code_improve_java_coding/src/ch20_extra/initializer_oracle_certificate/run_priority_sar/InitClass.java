package ch00.initializer_oracle_certificate.run_priority_sar;

public class InitClass
{
  private static int loop = 15;
  static final int INTERVAL = 10;
  boolean flag;
  // line 1
  static
  {
    System.out.println("Static");
  }
  static
  {
    loop = 1;
    System.out.println(loop);
  }
  static
  {
    loop += INTERVAL;
    System.out.println(loop);
  }
  {
    flag = true;
    loop = 0;
    System.out.println(loop);
  }
  
  public static void main(String[] args)
  {
    InitClass ic = new InitClass();
  }
}
/*
t01_e32;

Given the following class, which of the given blocks can be inserted at line 1 without errors?
 Select 4 options
 
 static {System.out.println("Static"); }  
 static { loop = 1; }
 static { loop += INTERVAL; }
 { flag = true; loop = 0; }
         flag is not static and so it can be accessed only from a non-static block. 
         loop is static so can be accessed from any block.
 static { INTERVAL = 10; } 
INTERVAL is final and so it can never be changed after it is given a value.
*/
