package ch00.initializer_oracle_certificate.t01_e66;

public class TestClass
{
  public static void main(String[] args)
  {
    int x = 1;
    int y = 0;
    /*if(x / y)
      System.out.println("Good");
    else System.out.println("Bad");*/
  }
}
/*
You need a boolean in the 'if' condition. 
Here, compiler sees that there is no way x/y can produce a boolean so 
it generates an error at compile time.

*/
