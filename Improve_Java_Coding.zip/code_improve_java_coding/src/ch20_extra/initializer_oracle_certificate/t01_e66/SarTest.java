package ch00.initializer_oracle_certificate.t01_e66;

public class SarTest
{
  public static void main(String[] args)
  {
    int x = 1;
    int y = 0;
    int z = 5;
    // if(z == x / y)
    if(z == z++)
      System.out.println("Good");
    else System.out.println("Bad");
  }
}
