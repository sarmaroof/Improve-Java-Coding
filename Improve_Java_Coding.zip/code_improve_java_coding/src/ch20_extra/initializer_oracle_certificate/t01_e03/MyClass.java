package ch00.initializer_oracle_certificate.t01_e03;

public class MyClass
{
  MyClass()
  {
    int i4 = getAge("f");
  }
  
  static
  {
    int i3 = getAge("b");
  }
  int i5 = getAge("d");
  {
    int i6 = getAge("e");
  }
  int i6 = getAge("z");
  int i = getAge("c");
  static int i2 = getAge("a");
  
  public static int getAge(String str)
  {
    System.out.print(str);
    return 20;
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
  }
}
/*
First, static statements/blocks are called IN THE ORDER they are defined. 
Next, instance initializer statements/blocks are called IN THE ORDER they are defined. 
Finally, the constructor is called. So, it prints a b c 2 3 4 1.
*/
