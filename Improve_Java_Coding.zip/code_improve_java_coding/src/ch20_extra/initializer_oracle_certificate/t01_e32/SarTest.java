package ch00.initializer_oracle_certificate.t01_e32;

public class SarTest
{
  private static int loop = 15;
  static final int INTERVAL = 10;
  boolean flag;
  
  // line 1
  public static void main(String[] args)
  {
    InitClass ic = new InitClass();
  }
}
