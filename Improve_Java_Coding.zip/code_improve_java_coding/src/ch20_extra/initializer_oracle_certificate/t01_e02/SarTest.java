package ch00.initializer_oracle_certificate.t01_e02;

public class SarTest
{
  public static void main(String args[])
  {
    boolean bl = false; // 1 bit
    byte b = 127; // 8 bits
    short s = 300; // 16 bits -128 till 127
    char c; // 16 bits
    int i = 400; // 32 bits
    long l = 500; // 64 bits
    float f = 450; // 32 bits
    double d = 550; // 64 bits;
    d = l;
    l = (long) d;
    c = 'a';// 1
    i = c; // 2
    i++; // 3
    // c = i; // 4
    c++; // 5
    System.out.println(i = s);
    System.out.println(l = i);
    // System.out.println(c);
  }
}
