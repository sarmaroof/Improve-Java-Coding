package ch00.initializer_oracle_certificate.t01_e06;

public class SarTest
{
  public static void main(String args[])
  {
    int i, j, k;
    i = j = k = 9;
    // System.out.println(i);
    boolean b2 = true;
    if(b2 = false)
    {
      System.out.println("x");
    }
    else
    {
      System.out.println("y");
    }
    System.out.println(b2);
  }
}
