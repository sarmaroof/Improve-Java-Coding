package ch00.initializer_oracle_certificate.t01_e31;

public class SarTest
{
  public static void main(String[] args)
  {
    boolean b1 = false;
    boolean b2 = true;
    // if(b2 != b1 = !b2) // invalid
    if(b2 = b1 = !b2) // valid
    {
      System.out.println("true");
    }
    else
    {
      System.out.println("false");
    }
  }
}
