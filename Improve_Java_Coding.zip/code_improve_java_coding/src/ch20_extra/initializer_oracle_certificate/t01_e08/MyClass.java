package ch00.initializer_oracle_certificate.t01_e08;

public class MyClass
{
  // long y = 123_456_L;
  // long z = _123_456L;
  // float f1 = 123_.345_667F;
  int hex = 0xCAFE_BABE;
  float f = 9898_7878.333_333f;
  int bin = 0b1111_0000_1100_1100;
  float f2 = 123_345_667F;
  
  public static void main(String[] args)
  {
  }
}
/*
t01_e08;
Identify the valid code fragments when occurring by themselves within a method

long y = 123_456_L
    An underscore can only occur in between two digits. So the _ before L is invalid.
long z = _123_456L;
    An underscore can only occur in between two digits. So the _ before 1 is invalid. _123_456L is a valid 
    variable name though. So the following code is valid: int _123_456L = 10; 
    long z = _123_456L; An exception to this rule is that multiple continuous underscores 
    can appear between two digits. For example, 2____3 is as good as 2_3 and is same as 23.
float f1 = 123_.345_667F;
    An underscore can only occur in between two digits. So the _ before . is invalid.
float f2 = 123_345_667F
None of the above declarations are valid.

You may use underscore for all kinds of numbers including long, double, float, binary, 
as well as hex.  For example, the following are all valid numbers - int hex = 0xCAFE_BABE; 
float f = 9898_7878.333_333f; int bin = 0b1111_0000_1100_1100;

*/
