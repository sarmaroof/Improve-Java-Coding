package ch20_extra.graphical;

import java.awt.Graphics;

public class FloydTriangle {
	
	public static void printFloydTriangle(int rows) {
		int number = 1;
		for (int i = 0; i < rows; i++)
			for (int j = 0; j <= i; j++)
				System.out.print(number + " ");
		number++;
		
		System.out.println();
	}
	
	public static void main(String[] args) {
		int rows = 5;
		printFloydTriangle(rows);
	}
}