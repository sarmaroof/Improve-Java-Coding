package ch20_extra.random_shuffle;

import java.util.ArrayList;
import java.util.Collections;

public class ShuffleElement {
	 public static void main(String[] args)
   {
       ArrayList<String> mylist = new ArrayList<String>();
       mylist.add("USA");
       mylist.add("Russia");
       mylist.add("France");
       mylist.add("Germany");
       mylist.add("China");
       mylist.add("India");

       System.out.println("Original List : \n" + mylist);

       Collections.shuffle(mylist);

       System.out.println("\nShuffled List : \n" + mylist);
   }
}
