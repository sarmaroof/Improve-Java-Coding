package ch20_extra.scanner;

import java.util.Scanner;

public class Question4 {
  
  public static void main(String[] args) { // begin the main method
    
    Scanner input = new Scanner(System.in); //create a new Scanner object to use
    int counter = 0, number = 0, largest = 0; // initialize variables
    for (counter = 0; counter < 10; counter++) { // loop ten times from 0 to 9
      System.out.printf("Enter Number [%d]: ", counter + 1);
      number = input.nextInt(); // store next integer in number
      largest = largest > number ? largest : number; // check if new number is larger, if so assign it to larger
    }
    System.out.printf("Largest = %d", largest); // display the largest value
  }
}
