package ch03_language_quick_guide.quiz._16_switch_java_12;


public class MyClass {
	
	void getGrade()
	{
		final int integer = 7;  
		System.out.println("Multiple Case Labels:");  
		final String numericString =  	
		switch (integer)  
		{  
         case 0 -> "zero";  
         case 1, 3, 5, 7, 9 -> "odd";  
         case 2, 4, 6, 8, 10 -> "even";  
         default -> "N/A";  
		};  
    System.out.println("\t" + integer + " ==> " + numericString);  
	}
	public static void main(String[] args)
	{
		MyClass mc = new MyClass();
		mc.getGrade();
	}

}
/*


*/