package ch03_language_quick_guide.exercise._99_loop_types; 

public class Country 
{
	String name;
	String capital;
	
	public Country(String name, String capital)
	{
		this.name = name;
		this.capital = capital;
	}
}
