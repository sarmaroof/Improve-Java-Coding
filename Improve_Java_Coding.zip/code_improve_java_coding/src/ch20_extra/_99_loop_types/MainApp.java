package ch03_language_quick_guide.exercise._99_loop_types;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MainApp 
{
	public static void main(String[] args)
	{
		
		List<String> animals = new ArrayList<String>();
		animals.add("Lion");
		animals.add("Tiger");
		animals.add("Cheetah");

		for(int i = animals.size()-1; i >= 0; i--)
		{
			//System.out.println(i);
			System.out.print(animals.get(i)+" ");
		}
		for(String country: animals)
		{
			System.out.println(animals);
		}
		/*Iterator<Country> iterator = countries.iterator();
		while(iterator.hasNext())
		{
			Country country = iterator.next();
			System.out.println(country.name+" " + country.capital);
		}*/
		// block 4 for loop using lambda expression in JAVA
    //System.out.println("\nPrinting all customers over the age of 25");
		animals.forEach(country -> {
            System.out.println(country);
    });
	}
}
