package ch07_encapsulation.zdiverse.best_money_datatype;
// class MonetaryDemo
// https://www.linqz.io/2019/02/choosing-data-type-for-monetary-calculation-in-java-float-double-or-bigdecimal.html
public class MoneyDatatype
{
	public static void main(String[] args)
	 {
	  double total = 0.2;
	  for (int i = 0; i < 100; i++)
	  {
	   total += 0.2;
	  }
	  System.out.println("------------------------------------------");
	  System.out.println("double total = " + total);
	  float floatTotal = 0.2f;
	  for (int i = 0; i < 100; i++)
	  {
	   floatTotal += 0.2f;
	  }
	  System.out.println("------------------------------------------");
	  System.out.println("float Total = " + floatTotal);

	  System.out.println("------------------------------------------");
	  System.out
	    .println("Sum of 10 (0.1f) = " + (0.1f + 0.1f + 0.1f + 0.1f + 0.1f + 0.1f + 0.1f + 0.1f + 0.1f + 0.1f));
	  System.out.println("------------------------------------------");
	  System.out.println("Precision of float 2.9876543218f : " + 2.9876543218f);
	  System.out.println("Precision of double 2.9876543218d : " + 2.9876543218d);
	  System.out.println("------------------------------------------");
	  System.out.println("0.0175 * 100000 = " + 0.0175 * 100000);
	  System.out.println("0.0175f * 100000 = " + 0.0175f * 100000);
	  System.out.println("------------------------------------------");
	 }

}
