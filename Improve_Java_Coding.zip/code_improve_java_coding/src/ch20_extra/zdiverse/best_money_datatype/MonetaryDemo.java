package ch07_encapsulation.zdiverse.best_money_datatype;

import java.math.BigDecimal;

public class MonetaryDemo
{
	 public static void main(String args[])
	 {
	  double amount1 = 1.15;
	  double amount2 = 1.10;
	  System.out.println("Diff between 1.15 and 1.10 using double is: " + (amount1 - amount2));BigDecimal amount3 = new BigDecimal("1.15");
	  BigDecimal amount4 = new BigDecimal("1.10");
	  System.out.println("Diff between 1.15 and 1.10 using BigDecimal is: " + (amount3.subtract(amount4)));final long iterations = 10000000;
	  
	  long t = System.currentTimeMillis();
	  double d = 789.0123456;
	  for (int i = 0; i < iterations; i++)
	  {
	   final double b = d * ((double) System.currentTimeMillis() + (double) System.currentTimeMillis());
	  }
	  System.out.println("Execution time for 10M iterations double: " + (System.currentTimeMillis() - t));t = System.currentTimeMillis();
	  BigDecimal bd = new BigDecimal("789.0123456");
	  for (int i = 0; i < iterations; i++)
	  {
	   final BigDecimal b = bd.multiply(
	     BigDecimal.valueOf(System.currentTimeMillis()).add(BigDecimal.valueOf(System.currentTimeMillis())));
	  }
	  System.out.println("Execution time for 10M iterations BigDecimal: " + (System.currentTimeMillis() - t));
	 }
}
