package ch20_extra.map_study_code;

import java.util.HashMap;
import java.util.Map;

public class MapForMyBook {
	
	static Map<String, String> dataDisplay = new HashMap<String, String>();
	
	public static void addDataDisplay() {
		dataDisplay.put("Brand", "BMW");
		dataDisplay.put("Color", "Brown");
		dataDisplay.put("Fuel", "Benzine");
	}
	
	public static void getDataDisplay() {
		addDataDisplay();
		
		for (Map.Entry<String, String> entry : dataDisplay.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			System.out.println(key +"  "+ value);
		}
	
		/*
		 // Lambda for map key and value
		 dataDisplay.forEach((key, value) -> System.out.println(i +"-"+key + " = " + value));
		 */
	}
	
	public static void main(String[] args) {
		getDataDisplay();
	}
	
}
