package ch20_extra.map_study_code;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import javax.swing.text.html.HTMLDocument.Iterator;

public class MyHashMap {
	
	static Map<String, String> dataDisplay = new HashMap<String, String>();
	
	/*
	 * public static void addDataDisplay(String key, String value) {
	 * dataDisplay.put(key, value); }
	 */
	
	public static void addDataStyleMap() {
		dataDisplay.put("Brand", "BMW");
		dataDisplay.put("Color", "Brown");
		dataDisplay.put("Fuel", "Benzine");
	}
	
	public static void getDataDisplay() {
		addDataStyleMap();
		dataDisplay.forEach((key, value) -> System.out.println(key + " = " + value));
		
	}
	
	public static void getDataStyle() {
		Map<String, String> charType = new HashMap<String, String>();
		
		// Inserting data in the hash map.
		charType.put("J", "Java");
		charType.put("H", "Hibernate");
		charType.put("P", "Python");
		charType.put("A", "Angular");
		
		// Iterating HashMap through forEach and
		// Printing all. elements in a Map
		charType.forEach((key, value) -> System.out.println(key + " = " + value));
	}
	
	public static void getDataStyle2() {
		getDataStyle();
		// 4 keySet() method returns all the keys in HashMap
		//Set<String> columns = dataStyle.keySet();
		// 5 values() method return all the values in HashMap
		//Collection<String> values = dataStyle.values();
		
		//System.out.println(columns + "" + values);
		
	}
	
	// Main driver method
	public static void main(String[] args) {
		getDataDisplay();
	}
	
	public static void processHashMap3() {
		// 1 Creation of HashMap
		HashMap<String, String> Geeks = new HashMap<>();
		
		// 2 Adding values to HashMap as ("keys", "values")
		Geeks.put("Language", "Java");
		Geeks.put("Platform", "Geeks For geeks");
		Geeks.put("Code", "HashMap");
		Geeks.put("Learn", "More");
		
		// 3 containsKey() method is to check the presence
		// of a particluar key
		// Since 'Code' key present here, the condition is true
		if(Geeks.containsKey("Code"))
			System.out.println("Testing .containsKey : " + Geeks.get("Code"));
		
		// 4 keySet() method returns all the keys in HashMap
		Set<String> Geekskeys = Geeks.keySet();
		System.out.println("Initial keys  : " + Geekskeys);
		
		// 5 values() method return all the values in HashMap
		Collection<String> Geeksvalues = Geeks.values();
		System.out.println("Initial values : " + Geeksvalues);
		
		// Adding new set of key-value
		Geeks.put("Search", "JavaArticle");
		
		// Again using .keySet() and .values() methods
		System.out.println("New Keys : " + Geekskeys);
		System.out.println("New Values: " + Geeksvalues);
		
	}
	
	public static void processHashMap2() {
		// 1 Creation of HashMap
		HashMap<String, String> Geeks = new HashMap<>();
		
		// 2 Adding values to HashMap as ("keys", "values")
		Geeks.put("Language", "Java");
		Geeks.put("Platform", "Geeks For geeks");
		Geeks.put("Code", "HashMap");
		Geeks.put("Learn", "More");
		
		// 3 containsKey() method is to check the presence
		// of a particluar key
		// Since 'Code' key present here, the condition is true
		if(Geeks.containsKey("Code"))
			System.out.println("Testing .containsKey : " + Geeks.get("Code"));
		
		// 4 keySet() method returns all the keys in HashMap
		Set<String> Geekskeys = Geeks.keySet();
		System.out.println("Initial keys  : " + Geekskeys);
		
		// 5 values() method return all the values in HashMap
		Collection<String> Geeksvalues = Geeks.values();
		System.out.println("Initial values : " + Geeksvalues);
		
		// Adding new set of key-value
		Geeks.put("Search", "JavaArticle");
		
		// Again using .keySet() and .values() methods
		System.out.println("New Keys : " + Geekskeys);
		System.out.println("New Values: " + Geeksvalues);
		
	}
	
	public static void processHashMap() {
		
		// Create an empty hash map by declaring object
		// of string and integer type
		HashMap<String, Integer> map = new HashMap<>();
		
		// Adding elements to the Map
		// using standard put() method
		map.put("vishal", 10);
		map.put("sachin", 30);
		map.put("vaibhav", 20);
		
		// Print size and content of the Map
		System.out.println("Size of map is:- " + map.size());
		
		// Printing elements in object of Map
		System.out.println(map);
		
		// Checking if a key is present and if
		// present, print value by passing
		// random element
		if(map.containsKey("vishal")) {
			
			// Mapping
			Integer a = map.get("vishal");
			
			// Printing value for the corresponding key
			System.out.println("value for key" + " \"vishal\" is:- " + a);
		}
	}
	
}
