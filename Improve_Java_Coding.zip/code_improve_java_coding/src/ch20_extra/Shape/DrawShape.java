package ch20_extra.Shape;

public class DrawShape {
  
  String sign = "*";
  String spaceSign = " ";
  String spaceSide = "";
  
  public static void main(String[] args) {
    DrawShape ds = new DrawShape();
    ds.printShap4();
  }
  
  
  public void printShap4() {
    
    System.out.println();
    
    for (int count = 1; count <= 10; count++) {
      System.out.print((spaceSign).repeat(10-count));
      //System.out.println(sign);
      System.out.print((sign).repeat(count+ count));
      System.out.println();
    }
  }
public void printShap3() {
    
    System.out.println("         *");
    System.out.println("        **");
    System.out.println("       ***");
    System.out.println("      ****");
    System.out.println("     *****");
    System.out.println("    ******");
    System.out.println("   *******");
    System.out.println("  ********");
    System.out.println(" *********");
    System.out.println("**********");
    
  }
  public void printShap() {
   
    System.out.println();
    
    for (int count = 1; count <= 10; count++) {
      
      System.out.print((spaceSide + spaceSign + sign).repeat(count));
      System.out.println();
    }
  }
  
  public void printShap2() {
    
    System.out.println();
    for (int count = 10; count >= 0; count--) {
      
      System.out.print((spaceSide + spaceSign + sign).repeat(count));
      System.out.println();
    }
  }
  
  
  

  
    /*
     * String strNumber = "4"; String strName = "@"; int intNumber = 10; for (int
     * row = 0; row < intNumber; row++) {
     * 
     * for (int col = 0; col < intNumber; col++) System.out.print(strName + " ");
     * System.out.println(""); }
     */
    /*
     * for (int count = 0; count < 10; count++) { for (int j = 0; j < count + 1;
     * j++) System.out.print("*"); System.out.println(); }
     * 
     * for (int count = 11; count >= 0; count--) { for (int j = 0; j < count - 1;
     * j++) System.out.print("*"); System.out.println(); }
     * 
     * for (int count = 0; count < 10; count++) { for (int index = 1; index < count
     * + 1; index++) System.out.print(" "); for (int star = 10; star > count;
     * star--) System.out.print("*"); System.out.println(); }
     * 
     * for (int count = 10; count > 0; count--) { for (int index = 0; index < count
     * - 1; index++) System.out.print(" "); for (int star = 10; star > count - 1;
     * star--) System.out.print("="); System.out.println(); }
     */
  //}
}
