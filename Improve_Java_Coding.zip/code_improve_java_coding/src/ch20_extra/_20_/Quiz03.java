package ch05_methods.quiz._20_;

import java.util.Scanner;

public class Quiz03
{
  public String getColor(String color)
  {
    //color = "";
    if(color == "rd") {
      color = "Red";
    }
    else if(color == "gr") {
      color = "Green";
    }
    else {
      //color = null;
    }
    //color = "Blue";
    return color;
  }
  public static void main(String[] args)
  {
    System.out.println("\n------Input------");
    Scanner input = new Scanner(System.in);
    System.out.print("Enter a color code: ");
    String name = input.nextLine();
    Quiz03 q3= new Quiz03();
    System.out.println(name);
    System.out.println(q3.getColor(name));
  }
}
