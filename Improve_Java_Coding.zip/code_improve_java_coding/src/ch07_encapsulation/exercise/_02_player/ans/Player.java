package ch07_encapsulation.exercise._02_player.ans;

public class Player
{
  private String name;
  private int age;
  private double height; // in cm
  private int yEx; // years of experience
  
  public Player(String name, int age, double height, int yEx)
  {
    this.name = name;
    this.age = age;
    this.height = height;
    this.yEx = yEx;
  }
  public void printAll()
  {
    System.out.println("Name: " + name);
    System.out.println("Age: " + age);
    System.out.println("Height: " + height);
    System.out.println("Experience: " + yEx);
  }
}
