package ch07_encapsulation.exercise._02_player.ans;

import java.util.Scanner;

public class PlayerApp
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    
    System.out.print("\nEnter the name: ");
    String name = input.nextLine();
    
    System.out.print("Enter the age: ");
    int age = input.nextInt();
    
    System.out.print("Enter the height in cm: ");
    double height = input.nextDouble();
    
    System.out.print("Enter years of experience: ");
    int yEx = input.nextInt();
    
    Player player = new Player(name, age, height, yEx);
    System.out.println("\n---Player Info ---");
    // access through public method
    player.printAll();
    System.out.println("\n---Result ---");
    
    if(age >= 18 && age <= 25 && height >= 185 && yEx >= 2)
    {
      System.out.println(name + " is accepted.");
    }
    else
    {
      System.out.println(name + " is rejected.");
    }
    input.close();
  }
}
