package ch07_encapsulation.exercise._02_player;

public class Player
{
	String name;
	int age;
	double height;
	int experience;
}
