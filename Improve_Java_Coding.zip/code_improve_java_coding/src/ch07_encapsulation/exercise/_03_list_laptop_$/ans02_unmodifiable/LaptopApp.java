package ch07_encapsulation.exercise._03_list_laptop_$.ans02_unmodifiable;

public class LaptopApp
{
  public static void main(String[] args)
  {
    Laptop laptop = new Laptop();
    try
    {
      // trying to add Acer to the list
      laptop.getListLaptops().add("Acer");
      // trying to remove HP from the list
      laptop.getListLaptops().remove(2);
    }
    catch(UnsupportedOperationException e)
    {
      System.out.println("\nThe list is read-only.");
    }
    // display the list after trying to change it
    System.out.print(laptop.getListLaptops());
  }
}
