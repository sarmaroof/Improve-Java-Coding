package ch07_encapsulation.exercise._03_list_laptop_$.ans04_interface;

public interface ReadOnlyInterface
{
  public abstract String getBrand();
}
