package ch07_encapsulation.exercise._03_list_laptop_$.ans04_interface;

import java.util.ArrayList;
import java.util.List;

public class Shop
{
  private List<Laptop> laptops;
  
  public Shop() {
    this.laptops = new ArrayList<Laptop>();
    this.laptops.add(new Laptop("Dell", 1400));
    this.laptops.add(new Laptop("IBM", 1300)); 
    this.laptops.add(new Laptop("HP", 1350));
    this.laptops.add(new Laptop("Lenovo", 1200));
  }
   
  public ArrayList<Laptop> getListLaptops()
  {
    return (ArrayList<Laptop>)laptops;
  }
  
  public ReadOnlyInterface getLaptopByBrand(String brand) {
    return this.laptops.get(0);
  }
}
