package ch07_encapsulation.exercise._03_list_laptop_$.ans04_interface;

public class Laptop implements ReadOnlyInterface 
{
  private String brand;
  private double price;
  public Laptop(String brand, double price)
  {
    this.brand = brand;
    this.price = price;
  }
  public String getBrand()
  {
    return brand;
  }
  public void setBrand(String brand)
  {
    this.brand = brand;
  }
  public double getPrice()
  {
    return price;
  }
  public void setPrice(double price)
  {
    this.price = price;
  }
}
/*
public ArrayList<String> getListLaptops()
{
  return new ArrayList<String>(laptops);
}
*/
