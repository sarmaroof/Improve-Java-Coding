package ch07_encapsulation.exercise._03_list_laptop_$.z_ans_not_finished;

public class Laptop
{
  private String brand;
  private double price;
  
  public Laptop(String brand, double price)
  {
    this.brand = brand;
    this.price = price;
  }
  
  public String getBrand()
  {
    return brand;
  }
  
  public void setBrand(String brand)
  {
    this.brand = brand;
  }
  
  public double getPrice()
  {
    return price;
  }
  
  public void setPrice(double price)
  {
    this.price = price;
  }
}
/*
public ArrayList<String> getListLaptops()
{
  return new ArrayList<String>(laptops);
}
*/
