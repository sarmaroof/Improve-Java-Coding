package ch07_encapsulation.exercise._03_list_laptop_$.z_ans_not_finished;

public class LaptopApp
{
  public static void main(String[] args)
  {
    Shop shop = new Shop();
    shop.getListLaptops().add(new Laptop("Acer", 1250));
    shop.getListLaptops().remove(2);
    //System.out.print(shop.getListLaptops());
    
    for (Laptop laptop : shop.getListLaptops())
    {
      System.out.println(laptop.getBrand() + ", " + laptop.getPrice());
    }
  }
}