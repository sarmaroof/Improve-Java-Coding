package ch07_encapsulation.exercise._03_list_laptop_$.z_ans_not_finished;

import java.util.ArrayList;
import java.util.List;

public class Shop
{
  private List<Laptop> laptops;
  
  public Shop()
  {
    this.laptops = new ArrayList<Laptop>();
    this.laptops.add(new Laptop("Dell", 1400));
    this.laptops.add(new Laptop("IBM", 1300));
    this.laptops.add(new Laptop("HP", 1350));
    this.laptops.add(new Laptop("Lenovo", 1200));
  }
  
  public ArrayList<Laptop> getListLaptops()
  {
    return new ArrayList<Laptop>(laptops);
  }
}
