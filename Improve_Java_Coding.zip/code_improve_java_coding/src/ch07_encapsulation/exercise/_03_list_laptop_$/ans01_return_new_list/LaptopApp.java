package ch07_encapsulation.exercise._03_list_laptop_$.ans01_return_new_list;


public class LaptopApp
{
  public static void main(String[] args)
  {
    Laptop laptop = new Laptop();
    // trying to add Acer to the list
    laptop.getListLaptops().add("Acer");
    // trying to remove HP from the list
    laptop.getListLaptops().remove(2);
    System.out.println("\nThe list is read-only.");
    System.out.print(laptop.getListLaptops());
  }
}
