package ch07_encapsulation.exercise._01_bankaccount_$;

public class BankAccount
{
  double balance = 3500.00;
}
