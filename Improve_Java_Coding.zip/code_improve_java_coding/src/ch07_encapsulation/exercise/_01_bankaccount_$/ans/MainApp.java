package ch07_encapsulation.exercise._01_bankaccount_$.ans;

import java.util.Scanner;

public class MainApp
{
  public static void main(String[] args)
  {
    BankAccount ba = new BankAccount();
    System.out.printf("\nBalance is: $%.2f ", ba.getBalance());
    
    Scanner scanner = new Scanner(System.in);
    System.out.print("\nEnter a positive amount: $");
    double amount = scanner.nextDouble();
    
    ba.withdraw(amount);
    scanner.close();
  }
}
/*
https://gamethapcam.github.io/2019-09-12-Clean-code-with-Method/#what-(not)-to-return
When we read above code, we see that -1 is a magic number with a magic meaning understandable. It makes other people confused.

In this case, consider throwing an exception.

 void withDraw(int amount) throws InsufficientFundsException {
     if (amount > balance) {
         throw new InsufficientFundsException();
     }

     balance -= amount;
 }




*/