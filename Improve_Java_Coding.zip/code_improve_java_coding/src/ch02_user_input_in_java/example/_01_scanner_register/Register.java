package ch02_user_input_in_java.example._01_scanner_register;

import java.util.Scanner;

public class Register
{
  public static void main(String[] args)
  {
    System.out.println("\n------Input------");
    Scanner input = new Scanner(System.in);
    
    System.out.print("Enter your name: ");
    String name = input.nextLine();
    
    System.out.print("Enter your age: ");
    int age = input.nextInt();
    
    System.out.print("Enter your gender: ");
    char gender = input.next().charAt(0);
    
    System.out.print("Enter your wage: $");
    double wage = input.nextDouble();
    String formattedString = String.format("%.02f", wage);
    
    System.out.print("Are you married? true/false: ");
    boolean isMarried = input.nextBoolean();
    
    System.out.println("------Output------");
    // print the data
    System.out.println("Name:      " + name);
    System.out.println("Age:       " + age);
    System.out.println("Gender:    " + gender);
    System.out.println("Wage:     $" + formattedString);
    System.out.println("Married:   " + isMarried);
    input.close();
  }
}
