package ch02_user_input_in_java.example._02_bufferedreader_register;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Register
{
  // Main Method
  public static void main(String[] args) throws IOException
  {
    // Creating BufferedReader Object
    BufferedReader input = new BufferedReader
                            (new InputStreamReader(System.in));
    // String reading internally
    System.out.print("Enter your name: ");
    String name = input.readLine();
    
    // Integer reading internally
    System.out.print("Enter your age: ");
    int age = Integer.parseInt(input.readLine());
    
    // Printing String
    System.out.println("Your name is: " + name);
    // Printing Integer
    System.out.println("Your age is: " + age);
  }
}
