package ch02_user_input_in_java.exercise._02_sum_of_two_numbers;

import java.util.Scanner;

public class Sum
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    
    System.out.println("\n.... Input ....");
    System.out.print("Enter the first number: ");
    int nr1 = input.nextInt();
    
    System.out.print("Enter the second number: ");
    int nr2 = input.nextInt();
    int sum = nr1 + nr2;
    
    System.out.println("\n.... Output ....");
    System.out.println(nr1 + " + " + nr2 + " = " + sum);
  }
}
