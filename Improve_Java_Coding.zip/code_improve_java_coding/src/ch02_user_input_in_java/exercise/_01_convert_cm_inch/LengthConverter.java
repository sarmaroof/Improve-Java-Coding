package ch02_user_input_in_java.exercise._01_convert_cm_inch;


import java.util.Scanner;

public class LengthConverter
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    
    System.out.println("\n.... Input ....");
    
    System.out.print("Enter a length in cm: ");
    double lCm = input.nextDouble();
    
    double lInch = lCm * 0.3937;
    System.out.println("\n.... Output ....");
    System.out.println(lCm + " cm"+ " = "+lInch+" Inches");
  }
}
