package ch02_user_input_in_java.exercise._03_convert_fahrenheit_to_celsius;

import java.util.Scanner;

public class TempConverter
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    
    System.out.println("\n.... Input ....");
    System.out.print("Enter a degree in Fahrenheit: ");
    double tf  = input.nextDouble();
    double tc = (tf - 32) * 5/9;
    
    System.out.println("\n.... Output ....");
    System.out.println(tf + " Fahrenheit = " +tc+ " Celsius");
  }
}
