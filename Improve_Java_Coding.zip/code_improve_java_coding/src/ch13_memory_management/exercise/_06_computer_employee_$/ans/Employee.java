package ch13_memory_management.exercise._06_computer_employee_$.ans;

public class Employee
{
  private Computer computer;
  
  void setComputer(Computer computer)
  {
     this.computer = computer;
  }
  public static void main(String[] args)
  {
    Computer c1 = new Computer("Dell"); //........ 1
    System.out.println("C1 "+ c1.brand);
    Employee emp = new Employee(); //............. 2
    emp.setComputer(c1); //....................... 3
    c1 = new Computer("HP"); //................... 4
    c1 = null; //................................. 5
    System.out.println("C1 "+ emp.computer.brand);
    emp = new Employee(); //...................... 6
    System.out.println("C1 "+ emp.computer);
  }
}

