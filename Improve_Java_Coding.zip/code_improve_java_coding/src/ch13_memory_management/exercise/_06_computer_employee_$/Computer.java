package ch13_memory_management.exercise._06_computer_employee_$;

public class Computer
{
	String brand;
		  
	Computer(String brand)
	{
		this.brand = brand;
	}
}
