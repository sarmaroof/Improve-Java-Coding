package ch13_memory_management.exercise._01_object_initialization_$.ans2;

public class Customer
{
  Account account; // remove = new Account();
  
  public Customer()
  {
    this.account = new Account();
    System.out.println("Object A: " + account);
  }
  public Customer(Account account)
  {
    System.out.println("Account attribute: " + this.account);
    System.out.println("Account argument:  " + account);
    this.account = account;
  }
}
