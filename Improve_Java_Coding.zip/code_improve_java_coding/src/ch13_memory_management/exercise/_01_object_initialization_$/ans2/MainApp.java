package ch13_memory_management.exercise._01_object_initialization_$.ans2;

public class MainApp
{
  public static void main(String[] args)
  {
    Customer customer = new Customer();
    System.out.println("Object B: " + customer.account);
  }
}
