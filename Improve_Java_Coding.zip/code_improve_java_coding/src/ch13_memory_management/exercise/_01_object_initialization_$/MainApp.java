package ch13_memory_management.exercise._01_object_initialization_$;

public class MainApp 
{
	public static void main(String[] args) {
		Account account = new Account();
		Customer customer = new Customer(account); 
	}
}
