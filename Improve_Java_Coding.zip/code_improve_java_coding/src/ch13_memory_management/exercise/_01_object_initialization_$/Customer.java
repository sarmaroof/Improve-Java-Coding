package ch13_memory_management.exercise._01_object_initialization_$;

public class Customer
{
  Account account = new Account();
  
  public Customer(Account account)
  {
    System.out.println("\nAccount attribute: " + this.account);
    System.out.println("Account argument:  " + account);
    this.account = account;
  }
}
