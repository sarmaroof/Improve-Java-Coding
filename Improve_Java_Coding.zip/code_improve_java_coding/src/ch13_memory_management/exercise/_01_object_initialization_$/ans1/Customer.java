package ch13_memory_management.exercise._01_object_initialization_$.ans1;

public class Customer
{
  Account account; // remove = new Account();
  
  public Customer(Account account)
  {
    System.out.println("Account attribute: " + this.account);
    System.out.println("Account argument:  " + account);
    this.account = account;
  }
}
