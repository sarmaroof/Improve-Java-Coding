package ch13_memory_management.exercise._01_object_initialization_$.ans1;

public class Account
{
  private String username;
  private String password;
  
  public Account()
  {
    System.out.println("Account is created!");
  }
}
