package ch13_memory_management.exercise._01_object_initialization_$;

public class Account 
{
	private String username;
	private String password;
}
