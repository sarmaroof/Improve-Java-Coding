package ch13_memory_management.example._01_stack.original_from_video;

public class MainApp
{
  public static void main(String[] args)
  {
    int value = 7;
    value = calculate(value);
  }
  public static int calculate(int data)
  {
    int tempValue = data + 3;
    int newValue = tempValue * 2;
    return newValue;
  }
}
