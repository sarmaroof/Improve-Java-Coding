package ch13_memory_management.example._01_stack;


public class Item  
{
  public static void main(String[] args) //........1
  {
    double initialPrice = 50; //...................2
    initialPrice = getPrice(initialPrice); //......6
  }
  public static double getPrice(double price) //...3
  {
    double discount = price * 0.20; //.............4
    double lastPrice = price - discount; 
    return lastPrice; //...........................5  
  }
}