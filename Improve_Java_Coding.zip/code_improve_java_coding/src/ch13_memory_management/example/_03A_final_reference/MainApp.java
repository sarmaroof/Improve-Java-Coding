package ch13_memory_management.example._03A_final_reference;



public class MainApp
{
  public static void main(String[] args)
  {
    final Car myCar = new Car("Cadillac");
    // reassign a new value to the final myChar
    //myCar = new Car("BMW");
    System.out.println("Brand: " + myCar.getBrand());
    myCar.setBrand("BMW");
    System.out.println("Brand: " + myCar.getBrand());
  }
}
