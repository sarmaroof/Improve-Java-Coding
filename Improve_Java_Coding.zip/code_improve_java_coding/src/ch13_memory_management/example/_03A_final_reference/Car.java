package ch13_memory_management.example._03A_final_reference;

public class Car
{
  private String brand;
  
  public Car(String brand)
  {
    this.brand = brand;
  }
  public String getBrand()
  {
    return brand;
  }
  public void setBrand(String brand)
  {
    this.brand = brand;
  }
}
