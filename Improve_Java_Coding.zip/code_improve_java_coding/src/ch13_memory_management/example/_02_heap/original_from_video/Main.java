package ch13_memory_management.example._02_heap.original_from_video;

import java.util.ArrayList;
import java.util.List;

public class Main
{
  public static void main(String[] args) {
    List<String> myList = new ArrayList<String>();
    myList.add("One");
    myList.add("Two");
    myList.add("Three");
    printList(myList);
  }
  public static void printList(List<String> data)
  {
    System.out.println(data);
  }
}
