package ch13_memory_management.example._02_heap;

import java.util.ArrayList;
import java.util.List;

public class MainApp
{
  public static void main(String[] args)
  {
    List<String> countries = new ArrayList<String>(); //...1
    countries.add("Germany"); //...........................2
    countries.add("Canada"); //............................3
    countries.add("Japan"); //.............................4
    
    String myCountry = countries.get(0);
  }
}