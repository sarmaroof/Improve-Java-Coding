package ch13_memory_management.example._03B_final_reference;

public class MainApp
{
  public static void main(String[] args)
  {
    final Car myCar = new Car("Cadillac");
    System.out.println("\nBrand: " + myCar.getBrand());
    
    myCar.setBrand("BMW");
    System.out.println("Brand: " + myCar.getBrand());
  }
}
