package ch13_memory_management.example._03B_final_reference.original_from_video02;

public class Customer
{
  String name;
  
  Customer(String name) {
    this.name = name;
  }

  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name;
  } 
}
/*
This code is from the video part2 of Java memory management which I downloaded.


*/
