package ch13_memory_management.example._03B_final_reference.original_from_video02;

public class FinalChange
{
  public static void main(String[] args)
  {
    final Customer c;
    c = new Customer("John");
    //c = new Customer("Susan");
    System.out.println("Name: "+c.getName());
    
    c.setName("Susan");
    System.out.println("Name: "+c.getName());
  }
}
