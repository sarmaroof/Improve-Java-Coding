package ch13_memory_management.quiz._02_garbage_collection.ans;


public class Employee
{
  String name = "Emma";
  
  public static void main(String args[])
  {
    Employee emp = new Employee();
    emp.createEmployee();
  }
  void createEmployee()
  {
    Employee employee = new Employee();//..........line 1
    System.out.println(employee.name);//...........checkpoint 1
    Employee[] employees = new Employee[7];//..... line 2
    employees[5] = employee; //....................line 3
    employee = null; //............................line 4
    System.out.println(employees[5].name); //......checkpoint 2
  }
}
