package ch13_memory_management.quiz._02_garbage_collection;

public class Employee
{
  String name = "Emma";
  
  public static void main(String args[])
  {
    Employee emp = new Employee();
    emp.createEmployee();
  }
  void createEmployee()
  {
    Employee employee = new Employee(); //......line 1
    Employee[] employees = new Employee[7]; //..line 2
    employees[5] = employee; //.................line 3
    employee = null; //.........................line 4
  }
}
/*
Which is the earliest line in the following code after which the object created employee on 
line 1 can be garbage collected, assuming no compiler optimizations are done?
The correct answer is line 6. Before this line the object is being pointed to by at least one variable.

The official exam objectives now explicitly mention Garbage collection. All you need to know is:  
1. An object can be made eligible for garbage collection by making 
   sure there are no references pointing to that object. 
2. You cannot directly invoke the garbage collector. You can suggest the JVM to perform garbage 
   collection by calling System.gc();
   
   
Select the correct answer.
a. After line 1.
b. After line 2.
c. After line 3.
d. After line 4.
e. It is impossible to determine that.
   
correct answer is e. 
   
   
   
*/