package ch13_memory_management.quiz._01b_initializer;

public class Bird
{
  int age1 = getAge(2);
  
  Bird()
  {
    int age2 = getAge(4);
  }
  static
  {
    int age3 = getAge(6);
  }
  
  static int age4 = getAge(8);
  int age5 = getAge(9);
  
  public static int getAge(int age)
  {
    System.out.print(age);
    return age;
  }
  public static void main(String[] args)
  {
    Bird bird = new Bird();
  }
}
/*
First, static statements/blocks are executed in the order in which they are defined. 
Next, instance initializer statements/blocks are executed in the order they are defined. 
Finally, the constructor is executed. As a result, it prints '6' to the standard output."

Select the correct answer.
a. This code writes "668" to the standard output. 
 b. This code writes "68" to the standard output. 
 c. This code writes "684" to the standard output. 
 d. This code writes "68294" to the standard output. 
 e. This code writes "null" to the standard output. 
 f. This code writes nothing to the standard output.
 
 correct is d.

*/