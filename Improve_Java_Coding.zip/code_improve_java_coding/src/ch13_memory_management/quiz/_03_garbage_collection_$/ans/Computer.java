package ch13_memory_management.quiz._03_garbage_collection_$.ans;

public class Computer
{
  String brand = "DELL";
}
