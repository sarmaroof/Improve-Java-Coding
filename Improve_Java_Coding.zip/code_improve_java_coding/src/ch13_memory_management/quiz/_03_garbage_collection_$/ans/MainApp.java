package ch13_memory_management.quiz._03_garbage_collection_$.ans;


public class MainApp
{
  private Computer computer;
  
  void setComputer(Computer computer)
  {
    this.computer = computer;
  }
  public static void main(String[] args)
  {
    System.out.println("-----line 1-----");
    Computer computer = new Computer(); //...1
    System.out.println("computer: " + computer.brand);
    System.out.println("-----line 2-----");
    MainApp ma = new MainApp(); //...........2
    System.out.println("computer: " + computer.brand);
    System.out.println("ma.computer: " + ma.computer);
    System.out.println("-----line 3-----");
    ma.setComputer(computer); //.............3
    System.out.println("computer: " + computer);
    System.out.println("ma.computer: " + ma.computer);
    System.out.println("-----line 4-----");
    computer = new Computer(); //............4
    System.out.println("computer: " + computer);
    System.out.println("ma.computer: " + ma.computer.brand);
    System.out.println("-----line 5-----");
    computer = null; //......................5
    System.out.println("computer: " + computer);
    System.out.println("ma.computer: " + ma.computer.brand);
    ma = new MainApp(); //...................6
    System.out.println("-----line 6-----");
    System.out.println("computer: " + computer);
    System.out.println("ma.computer: " + ma.computer);
  }
}
