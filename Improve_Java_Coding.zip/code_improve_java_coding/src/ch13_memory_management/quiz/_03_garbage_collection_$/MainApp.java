package ch13_memory_management.quiz._03_garbage_collection_$;

public class MainApp
{
  private Computer computer;
  
  void setComputer(Computer computer)
  {
     this.computer = computer;
  }
  public static void main(String[] args)
  {
    Computer computer = new Computer(); //..1
    MainApp ma = new MainApp();  //.........2
    ma.setComputer(computer); //............3
    computer = new Computer(); //...........4
    computer = null; //.....................5
    ma = new MainApp(); //..................6
  }
}

/*
Select the correct answer.
a. After line 1.
b. After line 2.
c. After line 3.
d. After line 4.
e. After line 5.
f. After line 6.
g. It is impossible to determine that.


public class NewClass
{
  private Object o;
  
  void doSomething(Object s)
  {
    o = s;
  }
  public static void main(String args[])
  {
    Object obj = new Object(); // 1
    System.out.println(obj);
    NewClass tc = new NewClass(); // 2
    tc.doSomething(obj); // 3
    obj = new Object(); // 4
    obj = null; // 5
    System.out.println(tc.o);
    tc.doSomething(obj); // 6 Before this line the object is being pointed to by at least one variable.
    System.out.println(tc.o);
  }
}*/
/*


Which is the earliest line in the following code after which the object created on 
line // 1 can be garbage collected, assuming no compiler optimizations are done?
The correct answer is line 6. Before this line the object is being pointed to by at least one variable.

The official exam objectives now explicitly mention Garbage collection.  All you need to know is:  
1. An object can be made eligible for garbage collection by making 
   sure there are no references pointing to that object. 
2. You cannot directly invoke the garbage collector. You can suggest the JVM to perform garbage 
   collection by calling System.gc();
*/
