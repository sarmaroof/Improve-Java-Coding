package ch13_memory_management.quiz._03_garbage_collection_$;

public class Computer
{
  String brand = "DELL";
}
