package ch08_inheritance.exercise._06;

public class Car extends Vehicle
{
	private int numberPassengers = 4;
	
	public void getCarInfo() 
	{
		//super.getCarInfo();
		System.out.println("Passengers: "+ numberPassengers);
	}
}
