package ch08_inheritance.exercise._06; 

public class Vehicle
{
	private String brand = "Volvo";
	
	Vehicle() 
	{
		getCarInfo();
	}
	
	public void getCarInfo() 
	{
		System.out.println("brand:      " + brand);
	}
}
