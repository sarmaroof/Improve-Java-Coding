package ch08_inheritance.exercise._06;

public class MainApp
{
	public static void main(String[] args)
  {
		Car car = new Car();
  }
}
