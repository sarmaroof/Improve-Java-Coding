package ch08_inheritance.exercise._02_multi_level;


public class Manager extends Employee
{
  private String team;
  
  Manager(String name,String email,int age,double salary,String team)
  {
    // calls the employee's constructor
    super(name, email, age, salary);
    this.team = team;
  }
  public void printData()
  {
    System.out.println("\n----------Manager-------------");
    // overrides the method printData of the superclass
    super.printData();
    System.out.println("\nManages:   " + team);
    System.out.println("-----------------------");
  }
}
