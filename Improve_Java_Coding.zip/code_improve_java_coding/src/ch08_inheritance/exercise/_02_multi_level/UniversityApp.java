package ch08_inheritance.exercise._02_multi_level;



public class UniversityApp
{
  public static void main(String[] args)
  {
    Student st = new Student("Bruce", "bruce@mail.com", 21, "2A");
    Professor pr = new Professor("Ben", "ben@mail.com", 44, 4500);
    pr.insertCourses();
    Manager mg = new Manager("Emma", "emma@mail.com", 
                              52, 5200, "Team ICT");
    st.printData();
    pr.printData();
    mg.printData();
  }
}
