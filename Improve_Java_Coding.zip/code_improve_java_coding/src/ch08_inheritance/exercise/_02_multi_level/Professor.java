package ch08_inheritance.exercise._02_multi_level;

import java.util.ArrayList;

public class Professor extends Employee
{
  private ArrayList<String> courses;
  
  Professor(String name, String email, int age, double salary)
  {
    // calls the employee's constructor
    super(name, email, age, salary);
    this.courses = new ArrayList<String>();
  }
  public void addCourse(String course)
  {
    courses.add(course);
  }
  public void insertCourses()
  {
    courses.add("Java");
    courses.add("Python");
    courses.add("C++");
  }
  public void printCourses()
  {
    int i = 0;
    
    for (String course : courses)
    {
      i++;
      System.out.println(" " + i + ": " + course);
    }
  }
  public void printData()
  {
    System.out.println("\n---------Professor-----------");
    // overrides the method printData of the superclass
    super.printData();
    System.out.println("\n\nProvides courses.....");
    printCourses();
  }
}
