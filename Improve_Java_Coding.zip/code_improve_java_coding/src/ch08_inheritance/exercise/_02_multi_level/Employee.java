package ch08_inheritance.exercise._02_multi_level;


public class Employee extends Person
{
  protected double salary;
  
  Employee(String name, String email, int age, double salary)
  {
    // calls the person's constructor
    super(name, email, age);
    this.salary = salary;
  }
  public void printData()
  {
    // overrides the method printData of the superclass
    super.printData();
    System.out.printf("Salary:    $%.2f", salary);
  }
}
