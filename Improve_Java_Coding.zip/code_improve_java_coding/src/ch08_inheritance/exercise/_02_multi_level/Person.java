package ch08_inheritance.exercise._02_multi_level;

public class Person
{
  protected String name;
  protected String email;
  protected int age;
  
  Person(String name, String email, int age)
  {
    this.name = name;
    this.email = email;
    this.age = age;
  }
  public void printData()
  {
    System.out.println("Name:      " + name);
    System.out.println("email:     " + email);
    System.out.println("Age:       " + age);
  }
}