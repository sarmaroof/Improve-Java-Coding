package ch08_inheritance.exercise._01_add_more_attributes;

import java.util.ArrayList;

public class Professor extends Person
{
  private double salary;
  private ArrayList<String> courses;
  
  Professor(String name, String email, int age, double salary)
  {
    // calls the person's constructor
    super(name, email, age);
    this.salary = salary;
    this.courses = new ArrayList<String>();
  }
  public void addCourse(String course)
  {
    courses.add(course);
  }
  public void insertCourses()
  {
    courses.add("Java");
    courses.add("Python");
    courses.add("C++");
  }
  public void printCourses()
  {
    int i = 0;
    
    for (String course : courses)
    {
      i++;
      System.out.println(" " + i + ": " + course);
    }
  }
  public void printData()
  {
    System.out.println("\n........ Professor ........");
    // overrides the method printData of the superclass
    super.printData();
    System.out.printf("Salary:      $%.2f", salary);
    System.out.println("\n\nCourses.....");
    printCourses();
  }
}
