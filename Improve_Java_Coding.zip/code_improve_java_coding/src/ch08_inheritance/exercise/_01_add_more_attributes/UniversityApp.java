package ch08_inheritance.exercise._01_add_more_attributes;

public class UniversityApp
{
  public static void main(String[] args)
  {
    Student st = new Student("Bruce", "bruce@mail.com", 21, "2A");
    Professor pr = new Professor("Ben", "ben@mail.com", 47, 4500);
    // add courses
    pr.insertCourses();
    st.printData();
    pr.printData();
  }
}
