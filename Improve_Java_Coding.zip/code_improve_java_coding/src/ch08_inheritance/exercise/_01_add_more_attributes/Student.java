package ch08_inheritance.exercise._01_add_more_attributes;

public class Student extends Person
{
  private String group;
  
  Student(String name, String email, int age, String group)
  {
    // calls the person's constructor
    super(name, email, age);
    this.group = group;
  }
  public void printData()
  {
    System.out.println("\n........ Student ........");
    // overrides the method printData of the superclass
    super.printData();
    System.out.println("Group:       " + group);
  }
}
