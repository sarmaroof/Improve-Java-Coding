package ch08_inheritance.exercise._08;

public class MySub extends MySuper
{
  int e = getNrSub();    // 4
  
  public MySub()
  {
    System.out.print("f "); // 5
  }
  int getNrSub() {
  	System.out.print("e ");
  	return 6;
  }
  static int getNrStSub() {
  	System.out.print("b ");
  	return 6;
  }
  static int b = getNrStSub(); // 2
  
  public static void main(String[] args)
  {
    MySub mySub = new MySub();
  }
  static int getNrFinalSub() {
  	System.out.print("z ");
  	return 6;
  }
  final int z = getNrFinalSub();
 
}