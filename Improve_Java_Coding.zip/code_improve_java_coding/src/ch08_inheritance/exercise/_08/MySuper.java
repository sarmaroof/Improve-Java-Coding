package ch08_inheritance.exercise._08;

public class MySuper
{
  int c = getNrSuper(); // 3
 
 
  public MySuper()
  {
    System.out.print("d "); // 4
  }
  int getNrSuper() {
  	System.out.print("c ");
  	return 1;
  }
  static int getNrStSuper() {
  	System.out.print("a ");
  	return 6;
  }
  static int a = getNrStSuper(); // 1
}