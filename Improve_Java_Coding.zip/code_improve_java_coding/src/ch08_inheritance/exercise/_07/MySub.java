package ch08_inheritance.exercise._07;

public class MySub extends MySuper
{
  int z = getNrSub();    // 4
 
  void myMethod()
  {
    System.out.print(" d" + z);  // 2
  }
  public static void main(String[] args)
  {
    MySub mySub = new MySub();
  }
  int getNrSub() {
  	System.out.print("z ");
  	return 7;
  }
}