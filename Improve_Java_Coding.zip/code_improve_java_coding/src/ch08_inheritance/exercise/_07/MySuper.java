package ch08_inheritance.exercise._07;

public class MySuper
{
  int a = getNrSuper(); 
 
  public MySuper()
  {
    myMethod();            
    System.out.print("b "); 
  }
  void myMethod()
  {
    System.out.print("c ");
  }
  int getNrSuper() {
  	System.out.print("a ");
  	return 1;
  }
}