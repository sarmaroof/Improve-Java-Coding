package ch08_inheritance.example._03_inheritance_overriding;

public class Professor extends Person
{
  private double salary;
  
  Professor(String name, String email, double salary)
  {
    // calls the person's constructor
    super(name, email);
    this.salary = salary;
  }
  public void printData()
  {
    System.out.println("\n........ Professor ........");
    // overrides the method printData of the superclass
    super.printData();
    System.out.printf("Salary:      $%.2f", salary);
  }
}
