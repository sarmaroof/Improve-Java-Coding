package ch08_inheritance.example._03_inheritance_overriding;

public class Person
{
  protected String name;
  protected String email;
  
  Person(String name, String email)
  {
    this.name = name;
    this.email = email;
  }
  public void printData()
  {
    System.out.println("Name:        " + name);
    System.out.println("email:       " + email);
  }
}
