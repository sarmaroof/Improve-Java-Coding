package ch08_inheritance.example._03_inheritance_overriding;

public class Student extends Person
{
  private String group;
  
  Student(String name, String email, String group)
  {
    // calls the person's constructor
    super(name, email);
    this.group = group;
  }
  public void printData()
  {
    System.out.println("\n........ Student ........");
    // overrides the method printData of the superclass
    super.printData();
    System.out.println("Group:       " + group);
  }
}
