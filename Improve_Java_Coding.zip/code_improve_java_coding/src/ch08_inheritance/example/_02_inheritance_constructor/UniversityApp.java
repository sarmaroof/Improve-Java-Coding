package ch08_inheritance.example._02_inheritance_constructor;

public class UniversityApp
{
  public static void main(String[] args)
  {
    Student st = new Student("Bruce", "bruce@mail.com", "2A");
    Professor pr = new Professor("Ben", "ben@mail.com", 4500);
    st.printData();
    pr.printData();
  }
}
