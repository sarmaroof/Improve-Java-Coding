package ch08_inheritance.example._02_inheritance_constructor;

public class Student extends Person
{
  private String group;
  
  Student(String name, String email, String group)
  {
    // calls the person's constructor
    super(name, email);
    this.group = group;
  }
  public void printData()
  {
    System.out.println("\n........ Student ........");
    System.out.println("Name:        " + name);
    System.out.println("email:       " + email);
    System.out.println("Group:       " + group);
  }
}
