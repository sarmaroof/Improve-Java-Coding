package ch08_inheritance.example._02_inheritance_constructor;

public class Professor extends Person
{
  private double salary;
  
  Professor(String name, String email, double salary)
  {
    // calls the person's constructor
    super(name, email);
    this.salary = salary;
  }
  public void printData()
  {
    System.out.println("\n........ Professor ........");
    System.out.println("Name:        " + name);
    System.out.println("email:       " + email);
    System.out.printf("Salary:      $%.2f", salary);
  }
}
