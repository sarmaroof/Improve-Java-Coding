package ch08_inheritance.example._02_inheritance_constructor;


public class Person
{
  protected String name;
  protected String email;
  
  Person(String name, String email)
  {
    this.name = name;
    this.email = email;
  }
}
