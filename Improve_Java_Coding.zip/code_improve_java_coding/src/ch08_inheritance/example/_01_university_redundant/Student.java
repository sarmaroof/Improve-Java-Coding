package ch08_inheritance.example._01_university_redundant;

public class Student
{
  private String name;
  private String email;
  private String group;
  
  public Student(String name, String email, String group)
  {
    this.name = name;
    this.email = email;
    this.group = group;
  }
  public void printData()
  {
    System.out.println("\n........ Student ........");
    System.out.println("Name:        " + name);
    System.out.println("email:       " + email);
    System.out.println("Group:       " + group);
  }
}
