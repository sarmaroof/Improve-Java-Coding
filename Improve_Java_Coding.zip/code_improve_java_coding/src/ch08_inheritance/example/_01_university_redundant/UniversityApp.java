package ch08_inheritance.example._01_university_redundant;

public class UniversityApp
{
  public static void main(String[] args)
  {
    Student st = new Student("Emma", "emma@mail.com", "A3");
    Professor pf = new Professor("Tim", "tim@mail.com", 5600);
    st.printData();
    pf.printData();
  }
}
