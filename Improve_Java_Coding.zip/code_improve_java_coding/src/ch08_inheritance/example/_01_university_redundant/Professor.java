package ch08_inheritance.example._01_university_redundant;

public class Professor
{
  private String name;
  private String email;
  private double salary;
  
  public Professor(String name, String email, double salary)
  {
    this.name = name;
    this.email = email;
    this.salary = salary;
  }
  public void printData()
  {
    System.out.println("\n........ Professor ........");
    System.out.println("Name:        " + name);
    System.out.println("email:       " + email);
    System.out.printf("Salary:      $%.2f", salary);
  }
}
