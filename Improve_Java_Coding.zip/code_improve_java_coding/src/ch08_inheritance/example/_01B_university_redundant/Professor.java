package ch08_inheritance.example._01B_university_redundant;

public class Professor
{
  private double salary;
  
  public Professor(double salary)
  {
    this.salary = salary;
  }
}
