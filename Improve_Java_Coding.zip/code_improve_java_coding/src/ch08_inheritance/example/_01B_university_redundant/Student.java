package ch08_inheritance.example._01B_university_redundant;

public class Student
{
  private String group;
  
  public Student(String group)
  {
    this.group = group;
  }
}
