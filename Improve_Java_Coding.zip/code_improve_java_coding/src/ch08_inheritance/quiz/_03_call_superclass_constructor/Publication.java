package ch08_inheritance.quiz._03_call_superclass_constructor;

public class Publication
{
  protected String title;
  
  Publication(String myTitle)
  {
    System.out.print(title);
    System.out.print(" Python ");
  }
}
