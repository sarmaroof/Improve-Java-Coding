package ch08_inheritance.quiz._03_call_superclass_constructor;

public class Book extends Publication
{
  String author;
  
  Book(String author)
  {
    //super(""); // calling the no-arg superclass constructor
    super("Learn Java"); // calling the one-arg superclass constructor
    this.author = author;
    System.out.println(author);
  }
  public static void main(String[] args)
  {
    Book book = new Book("George");
  }
}
/*

In the book the statement super("") should be removed, because the code must cause error._
Quiz 3
What happens when the following program is compiled and run?

Select the correct answer.
a. This code writes "null Python George" to the standard output. 
b. This code writes "George" to the standard output. 
c. This code writes "Python George" to the standard output. 
d. This code writes nothing to the standard output. 
e. The code of the subclass causes error. 

the correct answer is e.


Explanation 


*/