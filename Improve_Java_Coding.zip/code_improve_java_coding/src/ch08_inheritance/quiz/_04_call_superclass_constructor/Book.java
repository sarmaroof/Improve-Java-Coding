package ch08_inheritance.quiz._04_call_superclass_constructor;

public class Book extends Publication
{
	String author;
	
	Book(String author) 
	{
		super("C++");
		this.author = author;
		System.out.println(author);
	}
	public static void main(String[] args)
	{
		Book book = new Book("George");
	}
}

/*
Quiz 2
What happens when the following program is compiled and run?

Select the correct answer.
a. This code writes "null Python George" to the standard output. 
b. This code writes "Java C++ George" to the standard output. 
c. This code writes "C++ George" to the standard output. 
d. This code writes "C++ Python George" to the standard output. 
e. The code of the subclass causes error. 
The correct answer is a.

Explanation 


*/