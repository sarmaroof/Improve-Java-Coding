package ch08_inheritance.quiz._04_call_superclass_constructor; 

public class Publication
{
	protected String title;
	
	Publication()
	{
		System.out.print("Java ");
	}
	Publication(String myTitle)
	{
		System.out.print(title);
		System.out.print(" Python ");
	}
}
