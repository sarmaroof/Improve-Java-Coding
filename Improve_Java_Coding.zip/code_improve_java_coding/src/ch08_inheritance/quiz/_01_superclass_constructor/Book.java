package ch08_inheritance.quiz._01_superclass_constructor;

public class Book extends Publication
{
  String author;
  
  Book(String author)
  {
    super("Python");
    this.author = author;
  }
  public static void main(String[] args)
  {
    Book book = new Book("David ");
    System.out.print(book.title + " ");
  }
}
/*
Quiz 1
What happens when the following program is compiled and run?

Select the correct answer.
a. This code writes "David Python" to the standard output. 
b. This code writes "David Java" to the standard output. 
c. This code writes "David" to the standard output. 
d. This code writes "Java Python" to the standard output. 
e. This code writes nothing to the standard output. 
The correct answer is d.

Explanation 


*/