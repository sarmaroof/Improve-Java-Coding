package ch08_inheritance.quiz._01_superclass_constructor;

public class Publication
{
  protected String title;
  
  Publication(String title)
  {
    this.title = title;
    System.out.print("Java ");
  }
}
