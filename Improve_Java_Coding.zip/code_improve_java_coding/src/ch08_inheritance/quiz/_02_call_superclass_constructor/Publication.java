package ch08_inheritance.quiz._02_call_superclass_constructor;

public class Publication
{
  protected String title;
  
  Publication()
  {
    System.out.print("PHP ");
  }
  Publication(String title)
  {
    this.title = title;
    System.out.println("SQL ");
  }
}
