package ch08_inheritance.quiz._02_call_superclass_constructor;

public class Book extends Publication
{
  String author;
  
  Book(String author)
  {
    this.author = author;
    System.out.print(author);
    System.out.print("HTML ");
  }
  public static void main(String[] args)
  {
    Book book = new Book("David ");
  }
}
/*
Quiz 2
What happens when the following program is compiled and run?

Select the correct answer.
a. This code writes "David HTML " to the standard output. 
b. This code writes "PHP David HTML" to the standard output. 
c. This code writes "David" to the standard output. 
d. This code writes "SQL David HTML" to the standard output. 
e. This code writes "HTML" to the standard output. 
f. The code of the subclass causes error. 

The correct answer is b.


Explanation 


*/