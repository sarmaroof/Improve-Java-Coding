package ch12_exceptions.exercise.chat_gpt_advice;

import java.util.ArrayList;
import java.util.List;

public class Library
{
  private List<Book> books;
  
  public Library()
  {
    this.books = new ArrayList<>();
    populateList();
  }
  private void addBook(int id, String title)
  {
    books.add(new Book(id, title));
  }
  private void populateList()
  {
    addBook(1, "Learn Java");
    addBook(2, "Java Advanced");
    addBook(3, "Learn Python");
    addBook(4, "Advanced C++");
    addBook(5, "PHP for Beginners");
    addBook(6, "Learn HTML");
    addBook(7, "Database Design and SQL");
    addBook(8, "UML");
    addBook(9, "Object Oriented Programming");
    addBook(10, "Linux Operating System");
  }
  public Book getBookById(int id) throws MyException
  {
    for (Book book : books)
    {
      if(book.getId() == id)
      {
        System.out.println("The title of the book with id " + id + " is: " + book.getTitle());
        return book;
      }
    }
    throw new MyException("The book with id: " + id + " is not found.");
  }
}