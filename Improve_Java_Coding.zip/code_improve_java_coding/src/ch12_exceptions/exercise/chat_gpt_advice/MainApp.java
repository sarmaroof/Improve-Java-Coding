package ch12_exceptions.exercise.chat_gpt_advice;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MainApp
{
  public static void main(String args[])
  {
    try (Scanner input = new Scanner(System.in))
    {
      System.out.print("Please enter the book id: ");
      int id = input.nextInt();
      Library lb = new Library();
           
      try
      {
        lb.getBookById(id);
      }
      catch(MyException me)
      {
        System.out.println(me.getMessage());
      }
    }
    catch(InputMismatchException e)
    {
      System.out.println("The input is not a number.");
    }
  }
}