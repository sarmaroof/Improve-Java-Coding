package ch12_exceptions.exercise.chat_gpt_advice;

import java.util.List;

public class BookService {

  private List<Book> books;

  public BookService(List<Book> books) {
      this.books = books;
  }

  public Book getBookById(int id) throws MyException {
      if (id < 0) {
          throw new IllegalArgumentException("Invalid id: " + id);
      }

      if (books == null) {
          throw new IllegalStateException("The books list is not initialized.");
      }

      for (Book book : books) {
          if (book != null && book.getId() == id) {
              System.out.println("The title of the book id " + id + " is: " + book.getTitle());
              return book;
          }
      }

      throw new MyException("The book with id: " + id + " is not found.");
  }
}