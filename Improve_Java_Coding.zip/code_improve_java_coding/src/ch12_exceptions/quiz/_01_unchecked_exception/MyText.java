package ch12_exceptions.quiz._01_unchecked_exception;

public class MyText
{
  public void method()
  {
    try
    {
      System.out.print("N");
      Integer.parseInt("$4");
      System.out.print("T");
    }
    catch(NumberFormatException e)
    {
      System.out.print("W");
    }
  }
  public static void main(String[] args)
  {
    MyText mt = new MyText();
    mt.method();
  }
}

/*
Select the correct answer: 
 a. This program writes "N$4T" to the standard output. 
 b. This program writes "N" to the standard output. 
 c. This program writes "NW" to the standard output. 
 d. This program writes "W" to the standard output. 
 e. This program writes nothing to the standard output. 
 
 correct is c

*/