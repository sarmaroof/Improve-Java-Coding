package ch12_exceptions.quiz._04_text_and_divide_zero;

public class MyClass
{
  StringBuffer sb;
  int Z;
  
  public void myMethod()
  {
    try
    {
      int G = 5 / Z; //.....1
      sb.append("S"); //....2
    }
    catch(NullPointerException e)
    {
      System.out.print("N");
    }
    catch(ArithmeticException ae)
    {
      System.out.print("A");
    }
    catch(Exception e)
    {
      System.out.print("T");
    }
  }
  public static void main(String[] args)
  {
    MyClass mc = new MyClass();
    mc.myMethod();
  }
}

/*
Select the correct answer: 
a. This code writes N to the standard output. 
b. This code writes AN to the standard output. 
c. This code writes A to the standard output. 
d. This code writes NA to the standard output. 
e. This code writes nothing to the standard output.

correct is c.
*/