package ch12_exceptions.quiz._05_throw;

public class MyClass
{
  static String text = "";
  
  static void calculate(int x, int y)
  {
    text += "G";
    
    if(y == 0)
    {
      throw new ArithmeticException(); //..1
    }
    int z = x / y;
    text += "H";
  }
  public static void main(String[] args)
  {
    try
    {
      text += "I";
      calculate(10, 0);
      text += "K";
    }
    catch(ArithmeticException ae)
    {
      text += "L";
    }
    catch(NullPointerException ne)
    {
      text += "M";
    }
    System.out.println(text);
  }
}
/*
Select the correct answer: 
a. This code writes GHL to the standard output. 
b. This code writes IGM to the standard output. 
c. This code writes IGL to the standard output. 
d. This code writes GHIK to the standard output. 
e. This code writes GLM to the standard output. 

correct answer is c.
*/