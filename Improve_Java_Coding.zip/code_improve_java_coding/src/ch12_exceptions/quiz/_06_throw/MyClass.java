package ch12_exceptions.quiz._06_throw;

public class MyClass
{
  public static void myMethod(String str)
  {
    if(str == null)
    {
      throw new NullPointerException();
    }
    else
    {
      throw new RuntimeException();
    }
  }
  public static void main(String[] args)
  {
    try
    {
      System.out.print("G");
      myMethod("");
    }
    catch(NullPointerException e)
    {
      System.out.print("H");
    }
    catch(Exception e)
    {
      System.out.print("K");
    }
    finally
    {
      System.out.print("N");
    }
  }
}
/*
Select the correct answer: 
a. This code writes G to the standard output. 
b. This code writes GH to the standard output. 
c. This code writes GKN to the standard output. 
d. This code writes GHN to the standard output. 
e. This code writes GK to the standard output. 

correct is c.
*/