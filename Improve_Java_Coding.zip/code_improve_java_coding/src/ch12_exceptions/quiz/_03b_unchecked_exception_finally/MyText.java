package ch12_exceptions.quiz._03b_unchecked_exception_finally;

public class MyText
{
  String str = "DAVID"; //................1
  
  public void method()
  {
    try
    {
      String R = str.substring(2, 3); //..2
      System.out.print(R);
    }
    catch(NullPointerException e)
    {
      System.out.print("S");
    }
    catch(Exception e)
    {
      System.out.print("T");
    }
    finally
    {
      System.out.print("W");
    }
  }
  public static void main(String[] args)
  {
    MyText mt = new MyText();
    mt.method();
  }
}
/*
Select the correct answer: 
 a. This program writes "SW" to the standard output. 
 b. This program writes "VW" to the standard output. 
 c. This program writes "TW" to the standard output. 
 d. This program writes "W" to the standard output. 
 e. This program writes "AVW" to the standard output. 
 
 correct b.
*/