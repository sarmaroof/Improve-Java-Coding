package ch12_exceptions.quiz._02b_finally_block;

public class MyList
{
  public void method()
  {
    try
    {
      int[] listNr = new int[7];
      int L = listNr[5]; //.....1
      System.out.print(L);
    }
    catch(ArithmeticException e)
    {
      System.out.print("V");
    }
    catch(ArrayIndexOutOfBoundsException e)
    {
      System.out.print("W");
    }
    finally
    {
      System.out.print("N");
    }
  }
  public static void main(String[] args)
  {
    MyList ml = new MyList();
    ml.method();
  }
}
/*
Select the correct answer: 
 a. This program writes "LN" to the standard output. 
 b. This program writes "LWN" to the standard output. 
 c. This program writes "0WN" to the standard output. 
 d. This program writes "0N" to the standard output. 
 e. This program writes nothing to the standard output. 
 
 correct is d.
*/