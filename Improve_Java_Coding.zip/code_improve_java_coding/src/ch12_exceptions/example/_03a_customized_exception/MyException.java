package ch12_exceptions.example._03a_customized_exception;

public class MyException extends Exception
{
  public MyException(String message)
  {
    super(message);
  }
}