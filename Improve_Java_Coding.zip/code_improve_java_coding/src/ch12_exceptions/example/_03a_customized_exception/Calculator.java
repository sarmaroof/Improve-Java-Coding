package ch12_exceptions.example._03a_customized_exception;

public class Calculator
{
  public static double division(double numerator, double denominator) throws MyException
  {
    if(denominator == 0)
    {
      throw new MyException("Division by zero");
    }
    return numerator / denominator;
  }
  public static void main(String[] args)
  {
    try
    {
      double result = division(20, 0); //...1
      System.out.println(result);
    }
    catch(MyException me)
    {
      System.out.println("\nException: " + me.getMessage());
    }
  }
}
