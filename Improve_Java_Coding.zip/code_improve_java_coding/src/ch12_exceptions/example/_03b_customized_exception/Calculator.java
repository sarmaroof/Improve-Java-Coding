package ch12_exceptions.example._03b_customized_exception;

public class Calculator
{
  public static double division(double numerator, double denominator) throws MyException
  {
    if(denominator == 0)
    {
      throw new MyException("Division by zero");
    }
    return numerator / denominator;
  }
  public static void main(String[] args)
  {
    try
    {
      double average = division(20, 2); //...1
      System.out.println("\n"+average);
    }
    catch(MyException me)
    {
      System.out.println("Exception: " + me.getMessage());
    }
  }
}
