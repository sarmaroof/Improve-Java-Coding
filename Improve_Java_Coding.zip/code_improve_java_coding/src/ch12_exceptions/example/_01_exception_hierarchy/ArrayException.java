package ch12_exceptions.example._01_exception_hierarchy;

public class ArrayException
{
  public static void main(String[] args)
  {
    try
    {
      // A code which may cause an exception
    }
    catch(ArrayIndexOutOfBoundsException ae)
    {
      // catch the exception ArrayIndexOutOfBoundsException
    }
    catch(IndexOutOfBoundsException ae)
    {
      // catch the exception IndexOutOfBoundsException
    }
    catch(Exception e)
    {
      // catch all other possible exceptions
    }
  }
}
