package ch12_exceptions.example._02a_divide_zero;


public class Calculator
{
  public static void divide(int numerator, int denominator)
  {
    int result = numerator / denominator;
    System.out.println("\nResult: " + result);
  }
  public static void main(String[] args)
  {
    divide(20, 0);
  }
}
