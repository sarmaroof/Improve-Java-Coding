package ch12_exceptions.example._02c_divide_zero_finally;

public class Calculator
{
  public static void divide(int numerator, int denominator)
  {
    try
    {
      int result = numerator / denominator;
      System.out.println("Result: " + result);
    }
    catch(ArithmeticException ae)
    {
      System.out.println("\nError: " + ae.getMessage());
    }
    finally
    {
      System.out.println("The finally-block");
    }
  }
  public static void main(String[] args)
  {
    divide(20, 0); //.... 1
  }
}
