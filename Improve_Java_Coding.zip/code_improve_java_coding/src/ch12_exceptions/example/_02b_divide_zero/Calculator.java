package ch12_exceptions.example._02b_divide_zero;

public class Calculator
{
  public static void divide(int numerator, int denominator)
  {
    try
    {
      int result = numerator / denominator;
      System.out.println("Result: " + result);
    }
    catch(ArithmeticException e)
    {
      System.out.println("\nError: " + e.getMessage());
    }
  }
  public static void main(String[] args)
  {
    divide(20, 0);
  }
}