package ch12_exceptions.example._02f_divide_zero_throw;


public class Calculator
{
  public static double divide(double x, double n) throws IllegalArgumentException
  {
    if(n == 0)
    {
      throw new IllegalArgumentException("Division by zero");
    }
    return x / n;
  }
  public static void main(String[] args)
  {
    double result = 0;
    
    try
    {
      result = divide(20, 2); //....1
    }
    catch(IllegalArgumentException iae)
    {
      System.out.println("Exception: " + iae.getMessage());
    }
    System.out.println("\nResult: " + result);
  }
}