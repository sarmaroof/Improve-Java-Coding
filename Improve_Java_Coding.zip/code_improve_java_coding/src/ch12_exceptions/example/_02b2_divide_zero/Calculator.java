package ch12_exceptions.example._02b2_divide_zero;

public class Calculator
{
  public static void divide(double numerator, double denominator)
  {
    double result = numerator / denominator;
    System.out.println("Result: " + result);
  }
  public static void main(String[] args)
  {
    divide(20, 0);
  }
}