package ch09_polymorphism.example._01_overriding;

public class Computer
{
  String brand;
  double price;
  
  public Computer(String brand, double price)
  {
    this.brand = brand;
    this.price = price;
  }
  public void getSpecification()
  {
    System.out.println("Brand: " + brand);
    System.out.println("Price: $" + price);
  }
}
