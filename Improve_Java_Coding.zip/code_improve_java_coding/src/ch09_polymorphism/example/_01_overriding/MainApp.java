package ch09_polymorphism.example._01_overriding;

public class MainApp
{
  public static void main(String[] args)
  {
    Laptop laptop = new Laptop("HP", 680.35, 17);
    laptop.getSpecification();
  }
}
