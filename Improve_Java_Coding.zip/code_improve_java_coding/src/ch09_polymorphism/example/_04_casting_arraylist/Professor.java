package ch09_polymorphism.example._04_casting_arraylist;

public class Professor extends Person
{
  public Professor(String name)
  {
    super(name, "Admin access"); 
  }
  public void getAccess()
  {
    System.out.println(name + ", professor: " + access);
  }
}
