package ch09_polymorphism.example._04_casting_arraylist;



import java.util.ArrayList;
import java.util.List;

public class MainApp
{
  public static void main(String[] args)
  {
    List<Person> persons = new ArrayList<Person>();
    
    Student student = new Student("Boris");
    Professor professor = new Professor("David");
    
    persons.add(student);
    persons.add(professor); 
    
    for (Person person : persons)
    {
      person.getAccess();
    }
  }
}
