package ch09_polymorphism.example._04_casting_arraylist;

public class Student extends Person
{
  public Student(String name)
  {
    super(name, "Basic access"); 
  }
  public void getAccess()
  {
    System.out.println("\n"+name + ", student:   " + access);
  }
}
