package ch09_polymorphism.example._03a_casting_objects;

public class Sub extends Super
{
  int age = 50;
  
  public String display()
  {
    return "Sub method ";
  }
  public static void main(String[] args)
  {
    Super mySuper = new Sub();
    System.out.println("\nmySuper.display(): " + mySuper.display());
    System.out.print("mySuper.age:       " + mySuper.age);
  }
}
