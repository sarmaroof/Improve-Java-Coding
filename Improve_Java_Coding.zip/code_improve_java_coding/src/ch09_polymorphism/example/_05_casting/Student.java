package ch09_polymorphism.example._05_casting;


public class Student extends Person
{
  private String group = "ICT 2A";
  
  public void printData()
  {
    System.out.println("\n.. printData student ..");
    System.out.println("Name:    " + "Emma");
    System.out.println("Mobile:  " + "099-9999");
    System.out.println("Group:   " + group);
  }
  public static void main(String[] args)
  {
    Person person = new Student();
    Student student = (Student) person;
    // calling the method printData
    person.printData();
    student.printData();
  }
}
