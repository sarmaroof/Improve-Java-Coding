package ch09_polymorphism.example._05_casting;


public class Person
{
  protected String name = "Brian";
  protected String mobile = "088-8888";
  
  public void printData()
  {
    System.out.println("\n.. printData person ..");
    System.out.println("Name:    " + name);
    System.out.println("Mobile:  " + mobile);
  }
}
