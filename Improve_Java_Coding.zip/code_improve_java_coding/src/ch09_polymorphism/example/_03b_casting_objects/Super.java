package ch09_polymorphism.example._03b_casting_objects;

public class Super
{
  int age = 100;
  
  public String display()
  {
    return "Super method ";
  }
}
