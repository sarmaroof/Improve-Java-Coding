package ch09_polymorphism.quiz._02_overriding_$.ans;

public class Person
{
  String name = "Robert ";
  
  public Person()
  {
    printName();
  }
  void printName()
  {
    System.out.print(name);
  }
}
