package ch09_polymorphism.quiz._02_overriding_$;



public class Freelancer extends Person
{
  String name = "Emma ";
  
  void printName()
  {
    System.out.print("\n"+name);
  }
  public static void main(String[] args)
  {
    Freelancer freelancer = new Freelancer();
  }
}
/*
Quiz 1: Overriding methods

published on DZone on: 28-09-2017

What happens when you try to compile and run the following program?
 
Select the correct answer.
a. This code writes "Robert" to the standard output.
b. This code writes "Emma" to the standard output.
c. This code writes "Emma Robert" to the standard output.
d. This code writes "Robert Emma" to the standard output.
e. This code writes nothing to the standard output.
f. This code writes "null" to the standard output.

The right answer is: e. the code writes "null" to the standard output.

-------------------------

*/