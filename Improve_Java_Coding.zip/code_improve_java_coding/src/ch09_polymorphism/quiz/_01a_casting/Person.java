package ch09_polymorphism.quiz._01a_casting;

public class Person
{
  protected String name = "Brian";
  
  public String getName()
  {
    return "Vera";
  }
}
