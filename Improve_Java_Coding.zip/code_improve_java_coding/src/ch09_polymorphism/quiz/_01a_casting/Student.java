package ch09_polymorphism.quiz._01a_casting;

public class Student extends Person
{
  String name = "Emma";
  
  public String getName()
  {
    return "Olivia";
  }
  public static void main(String[] args)
  {
    Person person = new Student();
    System.out.println(person.name + " " + person.getName());
  }
}

/*
Select the correct answer.
a. This code writes "Brian Vera" to the standard output. 
b. This code writes "Brian Olivia" to the standard output. 
c. This code writes "Brian null" to the standard output. 
d. This code writes "Emma Olivia" to the standard output. 
e. This code writes “Emma Vera” to the standard output. 
f. This code writes nothing to the standard output. 

The correct answer is b.


*/