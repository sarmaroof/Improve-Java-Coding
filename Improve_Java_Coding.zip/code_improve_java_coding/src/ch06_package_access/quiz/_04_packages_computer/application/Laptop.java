package ch06_package_access.quiz._04_packages_computer.application;

import ch06_package_access.quiz._04_packages_computer.device.Computer;

public class Laptop extends Computer
{
  public String getBrand()
  {
    return brand;
  }
  public void printInfo()
  {
    /*
    Computer computer = new Computer(); //....1
    Laptop laptop = new Laptop(); //..........2
    System.out.println(computer.brand); //....3
    System.out.println(computer.price); //....4
    System.out.println(brand); //.............5
    System.out.println(laptop.brand); //......6
    System.out.println(laptop.price); //......7
    */
  }
}

/*
Select all the correct answers.
a. The statement 1.
b. The statement 2.
c. The statement 3.
d. The statement 4. 
e. The statement 5. 
f.  The statement 6. 
g. The statement 7.

*/