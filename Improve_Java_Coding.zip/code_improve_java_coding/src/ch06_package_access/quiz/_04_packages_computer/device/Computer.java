package ch06_package_access.quiz._04_packages_computer.device;

// package device
public class Computer
{
  protected String brand;
  double price;
}
