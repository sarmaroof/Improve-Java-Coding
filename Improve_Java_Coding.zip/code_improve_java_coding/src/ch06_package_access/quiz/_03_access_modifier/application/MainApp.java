package ch06_package_access.quiz._03_access_modifier.application;

import ch06_package_access.quiz._03_access_modifier.device.Computer;

// package application
public class MainApp
{
  public static void main(String[] args)
  {
    Computer computer = new Computer(); //....1
    System.out.println(computer.brand); //....2
    //System.out.println(computer.price); //....3
    //System.out.println(computer.memory); //...4
  }
}

/*
I commented the statements because they cause errors.
By copying this code uncomment all of them first.


*/
