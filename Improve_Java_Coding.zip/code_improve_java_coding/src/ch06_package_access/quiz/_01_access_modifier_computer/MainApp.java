package ch06_package_access.quiz._01_access_modifier_computer;


public class MainApp
{
  public static void main(String[] args)
  {
    Computer computer = new Computer(); //......1
    System.out.println(computer.brand); //......2
    System.out.println(computer.price); //......3
    //System.out.println(computer.memory); //.....4
  }
}

/*
By copying the code uncomment the line 4.
I commented that because I want to get rid of the error.

Select the correct answer.
a. The statement 1. 
b. The statement 2. 
c. The statement 3. 
d. The statement 4. 
e. The statements 3 and 4. 
f. All the statements. 

*/