package ch06_package_access.quiz._02_access_modifier.application;

// package application
public class MainApp
{
  public static void main(String[] args)
  {
    /*Computer computer = new Computer(); //....1
    System.out.println(computer.brand); //....2
    System.out.println(computer.price); //....3
    System.out.println(computer.memory); //...4*/
  }
}

/*
I commented the statements because they cause errors.
By copying this code uncomment all of them first.

Select the correct answer.
a. The statement 1. 
b. The statement 2. 
c. The statement 3. 
d. The statement 4. 
e. The statements 3 and 4. 
f. All the statements. 


*/