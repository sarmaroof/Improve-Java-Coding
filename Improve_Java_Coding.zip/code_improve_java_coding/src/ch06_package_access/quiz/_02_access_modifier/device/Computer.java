package ch06_package_access.quiz._02_access_modifier.device;

// package device
public class Computer
{
  public String brand = "IBM"; //...public access
  double price; //..................default access
  private int memory = 16; //.......private access
}
