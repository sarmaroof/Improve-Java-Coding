package ch06_package_access.example._01_packages_animal.animal;

// package animal;
public class Dog
{
  public String type = "Husky";
}
