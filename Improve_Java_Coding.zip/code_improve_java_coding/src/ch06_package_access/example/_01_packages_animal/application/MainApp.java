package ch06_package_access.example._01_packages_animal.application;

import ch06_package_access.example._01_packages_animal.animal.Dog;

// package application
public class MainApp
{
  public static void main(String[] args)
  {
    Dog dog = new Dog();
    System.out.println("\n"+dog.type);
  }
}
