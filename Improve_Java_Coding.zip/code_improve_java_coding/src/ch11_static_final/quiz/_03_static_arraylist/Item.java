package ch11_static_final.quiz._03_static_arraylist;

public class Item
{
	String name;
	double price;
	
	public Item(String name, double price) 
	{
		this.name = name;
		this.price = price;
	}
}