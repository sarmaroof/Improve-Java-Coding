package ch11_static_final.quiz._03_static_arraylist;

import java.util.ArrayList;

public class Store
{
  static ArrayList<Item> products = new ArrayList<Item>();
  
  void addProducts()
  {
    products.add(new Item("Cheese", 3.35));
    products.add(new Item("Milk", 2.25));
    products.add(new Item("Bread", 2.25));
  }
  public static void main(String[] args)
  {
    Store storeA = new Store();
    Store storeB = new Store();
    storeA.addProducts();
    storeB.products.add(new Item("Candy", 2.55));
    storeB.products.add(new Item("Sugar", 2.55));
    int i = 0;
    
    for (Item item : storeB.products)
    {
      if(i == 3)
      {
        System.out.println(item.name);
      }
      i++;
    }
  }
}

/*
Select the correct answer.
a. The output of the code is "Candy".
b. The output of the code is "Bread".
c. The output of the code is "Sugar".
d. The output of the code is nothing.
e. This program produced an error.

The correct answer is a.


*/






