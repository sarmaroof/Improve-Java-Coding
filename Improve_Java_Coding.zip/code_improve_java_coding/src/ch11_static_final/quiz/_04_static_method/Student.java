package ch11_static_final.quiz._04_static_method;

public class Student
{
  String name;
  static double math;
  static double java;
  static double python;
  
  Student(String name, double math2, double java2, double python2)
  {
    this.name = name;
    math = math2;
    java = java2;
    python = python2;
  }
  public static double getAverage()
  {
    double average = (math + java + python) / 3;
    return average;
  }
  public static void main(String[] args)
  {
  
    Student st1 = new Student("Jack", 8, 10, 9);
    Student st2 = new Student("Salma", 7, 9, 5);
    Student st3 = new Student("Layla", 9, 7, 8);
  
    double average1 = st1.getAverage();
    double average2 = st2.getAverage();
    double average3 = st3.getAverage();
    
    System.out.print("\nStudent name:\t" + st1.name);
    System.out.printf(" Average grade %.1f \t", average1);
    System.out.print("\nStudent name: \t" + st2.name);
    System.out.printf(" Average grade %.1f", average2);
    System.out.print("\nStudent name: \t" + st3.name);
    System.out.printf(" Average grade %.1f", average3);
  }
}

/*
Select all the correct answers.
a. The average grade of Jack is "8.0".
b. The average grade of Salma is "8.0".
c. The average grade of Layla is 8.0".
d. The average grade of Jack is "9.0".
e. The average grade of Salma is "7.0".

The correct answers are a, b and c.
*/

