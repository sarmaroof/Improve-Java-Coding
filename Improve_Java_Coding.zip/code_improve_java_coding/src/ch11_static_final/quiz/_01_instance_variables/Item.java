package ch11_static_final.quiz._01_instance_variables;

public class Item
{
  String name = "";
  double price;
  
  public Item(String name, double price)
  {
    this.name += name;
    this.price += price;
  }
  public static void main(String[] args)
  {
    Item item1 = new Item("Milk", 2.65);
    Item item2 = new Item("Bread", 1.85);
    Item item3 = new Item("Cheese", 2.35);
    Item item4 = new Item("Chips", 1.75);
    
    System.out.println(item1.name + ", " + item3.price);
  }
}
/*
The name RosaBank doesn't exist is fiction by my sar maroof
Select the correct answer.
a. The output of the code is “Milk, 2.65”.
b. The output of the code is “Cheese, 2.35”.
c. The output of the code is “Cheese, 1.75”.
d. The output of the code is “Milk, 2.35”.
e. The output of the code is nothing.

The correct answer is d.
*/