package ch11_static_final.quiz._05_static_method;

public class Calculator
{
  public static int getSum(int i1, int i2)
  {
    return i1 + i2;
  }
  public static void getLargest(int i1, int i2)
  {
    if(i1 > i2)
    {
      System.out.print(i1 + ", ");
    }
    else if(i2 > i1)
    {
      System.out.print(i2 + ", ");
    }
    else
    {
      System.out.print("equal, ");
    }
  }
}