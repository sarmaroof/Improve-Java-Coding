package ch11_static_final.quiz._05_static_method;

public class MainApp
{
  public static void main(String[] args)
  {
    int sum = Calculator.getSum(44, -33); //...1
    System.out.print("\n"+sum + ", "); //......2
    Calculator.getLargest(24, 24); //..........3
    Calculator.getLargest(39, 41); //..........4
  }
}

/*

Select the correct answer.
a. The output of the code is "11, equal, 41, ".
b. The output of the code is "44, 24, 41".
c. The output of the code is "24, 41".
d. The output of the code is "equal, 41".
e. This program produced an error.

The correct answer is a.


*/