package ch11_static_final.example._01_sum;

public class MainApp
{
  public static void main(String[] args)
  {
    int x = Calculation.sum(5, 4, 6);
    System.out.print("\nSum is: " + x);
  }
}
