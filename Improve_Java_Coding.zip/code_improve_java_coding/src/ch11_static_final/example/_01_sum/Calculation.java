package ch11_static_final.example._01_sum;

public class Calculation
{
  public static int sum(int i, int i2, int i3)
  {
    return i + i2 + i3;
  }
}
