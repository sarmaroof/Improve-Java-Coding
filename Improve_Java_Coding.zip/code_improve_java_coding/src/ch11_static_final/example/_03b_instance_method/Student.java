package ch11_static_final.example._03b_instance_method;

public class Student
{
  private String name;
  private double gr1; // gr = grade
  private double gr2;
  private double gr3;
  
  public Student(String name, double gr1, double gr2, double gr3)
  {
    this.name = name;
    this.gr1 = gr1;
    this.gr2 = gr2;
    this.gr3 = gr3;
  }
  double getAverage()
  {
    double average = (gr1 + gr2 + gr3) / 3;
    return average;
  }
  public static void main(String[] args)
  {
    // instance method
    Student st1 = new Student("Emma", 7, 6, 8);
    Student st2 = new Student("David", 9, 8, 7);
    Student st3 = new Student("Jack", 10, 9, 8);
    
    double avg1 = st1.getAverage();
    double avg2 = st2.getAverage();
    double avg3 = st3.getAverage();
    
    System.out.println("\nName: " +st1.name+"\tAverage: " + avg1);
    System.out.println("Name: " +st2.name+"\tAverage: " + avg2);
    System.out.println("Name: " +st3.name+"\tAverage: " + avg3);
  }
}
