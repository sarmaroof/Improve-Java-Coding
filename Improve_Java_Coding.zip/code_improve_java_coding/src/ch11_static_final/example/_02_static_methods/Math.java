package ch11_static_final.example._02_static_methods;
  
public class Math
{
  public static double getAverage(int nr1, int nr2, int nr3)
  {
    double average = (nr1 + nr2 + nr3) / 3;
    return average;
  }
  public static void main(String[] args)
  {
    Math m1 = new Math();
    Math m2 = new Math();
    
    System.out.println("\nAvg1: " + m1.getAverage(10, 20, 30));
    System.out.println("Avg2: " + m2.getAverage(40, 60, 80));
    System.out.println("Avg3: " + Math.getAverage(45, 90, 135));
  }
}
