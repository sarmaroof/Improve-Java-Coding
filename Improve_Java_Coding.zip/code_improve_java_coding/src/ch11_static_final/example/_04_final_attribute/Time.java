package ch11_static_final.example._04_final_attribute;

public class Time
{
  final int HOUR = 60; // minutes
  
  public void converHoursToMinutes(int nrHours)
  {
    //HOUR ++;
    System.out.print("\n"+nrHours * HOUR);
  }
  public static void main(String[] args)
  {
    Time time = new Time();
    // calculate number minuts in 4 hours
    time.converHoursToMinutes(4);
  }
}
// the result should be 60 * 4 = 240