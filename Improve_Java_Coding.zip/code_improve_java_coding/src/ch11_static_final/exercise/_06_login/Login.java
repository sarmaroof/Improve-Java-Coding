package ch11_static_final.exercise._06_login;

public class Login
{
  final int NUMBER_HOURES_IN_DAY = 24;
  int numberAttempts;
  
  static boolean inloggen(String username, String password) 
  {
    if(username.equals("Jack") && password.equals("JacPassword")) 
    {
        System.out.print("You are logged in!");
        return true;
    } 
    else 
    {
        System.out.print("Your data is not correct!");
        return false;
    }
  }
 
  public static void main(String[] args) 
  {
    Login login = new Login();
    while(login.numberAttempts < 3) 
    {
      login.numberAttempts ++;
      // code
    }
  }
}
